/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { VersionDispatchingCodecBuilder, type CodecWriteOptions, type VersionDispatchingCodec } from "../../codec/index.js";
import type { FieldKey, ITreeCursorSynchronous } from "../../core/index.js";
import { type FieldBatchDecodingContext, type FieldBatchEncodingContext } from "../chunked-forest/index.js";
import { ForestFormatVersion } from "./formatCommon.js";
/**
 * Uses field cursors
 */
export type FieldSet = ReadonlyMap<FieldKey, ITreeCursorSynchronous>;
export type ForestCodec = VersionDispatchingCodec<FieldSet, FieldBatchEncodingContext, ForestFormatVersion, FieldBatchDecodingContext>;
/**
 * {@link VersionDispatchingCodecBuilder} for forest summarizer codecs.
 */
export declare const forestCodecBuilder: VersionDispatchingCodecBuilder<CodecWriteOptions, FieldSet, FieldBatchEncodingContext, import("../../util/brand.js").Brand<1, "ForestFormatVersion"> | import("../../util/brand.js").Brand<2, "ForestFormatVersion">, "Forest", FieldBatchDecodingContext>;
//# sourceMappingURL=codec.d.ts.map