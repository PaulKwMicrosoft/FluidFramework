/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IChannelStorageService } from "@fluidframework/datastore-definitions/internal";
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { IExperimentalIncrementalSummaryContext, ITelemetryContext } from "@fluidframework/runtime-definitions/internal";
import type { SummaryTreeBuilder } from "@fluidframework/runtime-utils/internal";
import type { CodecWriteOptions } from "../../codec/index.js";
import { type IEditableForest, type RevisionTagCodec } from "../../core/index.js";
import { VersionedSummarizer, type Summarizable, type SummaryElementParser, type SummaryElementStringifier } from "../../shared-tree-core/index.js";
import { type FieldBatchDecodingContext, type FieldBatchEncodingContext, type IncrementalEncodingPolicy } from "../chunked-forest/index.js";
import { ForestSummaryFormatVersion } from "./summaryFormatCommon.js";
/**
 * Provides methods for summarizing and loading a forest.
 */
export declare class ForestSummarizer extends VersionedSummarizer<ForestSummaryFormatVersion> implements Summarizable {
    private readonly forest;
    private readonly revisionTagCodec;
    private readonly encoderContext;
    private readonly decoderContext;
    private readonly idCompressor;
    private readonly codec;
    private readonly incrementalSummaryBuilder;
    private readonly forestRootSummaryContentKey;
    /**
     * @param encoderContext - The schema if provided here must be mutated by the caller to keep it up to date.
     */
    constructor(forest: IEditableForest, revisionTagCodec: RevisionTagCodec, encoderContext: FieldBatchEncodingContext, decoderContext: FieldBatchDecodingContext, options: CodecWriteOptions, idCompressor: IIdCompressor, initialSequenceNumber: number, shouldEncodeIncrementally?: IncrementalEncodingPolicy);
    /**
     * Summarization of the forest's tree content.
     * @returns a summary tree containing the forest's tree content.
     * @remarks
     * If incremental summary is disabled, all the content will be added to a single summary blob.
     * If incremental summary is enabled, the summary will be a tree.
     * See {@link ForestIncrementalSummaryBuilder} for details of what this tree looks like.
     *
     * TODO: when perf matters, this should be replaced with a chunked async version using a binary format.
     */
    protected summarizeInternal(props: {
        stringify: SummaryElementStringifier;
        fullTree?: boolean;
        trackState?: boolean;
        telemetryContext?: ITelemetryContext;
        incrementalSummaryContext?: IExperimentalIncrementalSummaryContext;
        builder: SummaryTreeBuilder;
    }): void;
    protected loadInternal(services: IChannelStorageService, parse: SummaryElementParser, version: ForestSummaryFormatVersion | undefined): Promise<void>;
}
//# sourceMappingURL=forestSummarizer.d.ts.map