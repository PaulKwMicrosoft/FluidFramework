/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { schemaFormatV1 } from "../../core/index.js";
import { type Values } from "../../util/index.js";
/**
 * The format version for the forest.
 */
export declare const ForestFormatVersion: {
    readonly v1: import("../../util/brand.js").Brand<1, "ForestFormatVersion">;
    readonly v2: import("../../util/brand.js").Brand<2, "ForestFormatVersion">;
};
export type ForestFormatVersion = Values<typeof ForestFormatVersion>;
/**
 * Format used by {@link ForestFormatVersion.v1} and {@link ForestFormatVersion.v2}.
 */
export declare const FormatCommon: Type.TObject<{
    keys: Type.TArray<Type.TUnsafe<schemaFormatV1.FieldKey>>;
    fields: Type.TUnsafe<import("../../util/utils.js").JsonCompatibleReadOnly>;
    version: Type.TUnion<[Type.TNumber, Type.TString]>;
}>;
export type FormatCommon = Static<typeof FormatCommon>;
//# sourceMappingURL=formatCommon.d.ts.map