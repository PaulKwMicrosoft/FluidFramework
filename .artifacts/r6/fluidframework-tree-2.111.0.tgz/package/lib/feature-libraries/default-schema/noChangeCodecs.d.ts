/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ICodecFamily } from "../../codec/index.js";
import type { FieldChangeEncodingContext } from "../modular-schema/index.js";
export declare const noChangeCodecFamily: ICodecFamily<0, FieldChangeEncodingContext>;
//# sourceMappingURL=noChangeCodecs.d.ts.map