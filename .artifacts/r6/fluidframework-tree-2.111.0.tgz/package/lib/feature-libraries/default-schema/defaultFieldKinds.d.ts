/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { CodecTree } from "../../codec/index.js";
import { type FieldKindIdentifier, forbiddenFieldKindIdentifier, Multiplicity } from "../../core/index.js";
import { identifierFieldIdentifier } from "../fieldKindIdentifiers.js";
import { type FieldChangeHandler, type FieldEditor, type FieldKindConfiguration, FlexFieldKind, type FullSchemaPolicy, ModularChangeFormatVersion } from "../modular-schema/index.js";
import { optional, required } from "../optional-field/index.js";
import { sequence } from "../sequence-field/index.js";
/**
 * ChangeHandler that only handles no-op / identity changes.
 */
export declare const noChangeHandler: FieldChangeHandler<0>;
/**
 * Exactly one identifier.
 */
export declare const identifier: Identifier;
/**
 * Exactly 0 items.
 *
 * Using Forbidden makes what types are listed for allowed in a field irrelevant
 * since the field will never have values in it.
 *
 * Using Forbidden is equivalent to picking a kind that permits empty (like sequence or optional)
 * and having no allowed types (or only never types).
 * Because of this, its possible to express everything constraint wise without Forbidden,
 * but using Forbidden can be more semantically clear than optional with no allowed types.
 *
 * For view schema, this can be useful if you need to:
 * - run a specific out of schema handler when a field is present,
 * but otherwise are ignoring or tolerating (ex: via extra fields) unmentioned fields.
 * - prevent a specific field from being used as an extra field
 * (perhaps for some past of future compatibility reason)
 * - keep a field in a schema for metadata purposes
 * (ex: for improved error messaging, error handling or documentation)
 * that is not used in this specific version of the schema (ex: to document what it was or will be used for).
 *
 * For stored schema, this can be useful if you need to:
 * - have a field which can have its schema updated to Optional or Sequence of any type.
 * - to exclude a field from extra fields
 * - for the schema system to use as a default for fields which aren't declared
 * (ex: when updating a field that did not exist into one that does)
 *
 * See {@link emptyField} for a constant, reusable field using Forbidden.
 */
export declare const forbidden: Forbidden;
export declare const fieldKindConfigurations: ReadonlyMap<ModularChangeFormatVersion, FieldKindConfiguration>;
export declare function getCodecTreeForModularChangeFormat(version: ModularChangeFormatVersion): CodecTree;
/**
 * All supported field kinds.
 *
 * @privateRemarks
 * Before making a SharedTree format change which impacts which set of field kinds are allowed,
 * code which uses this should be audited for compatibility considerations.
 */
export declare const fieldKinds: ReadonlyMap<FieldKindIdentifier, FlexFieldKind>;
export interface Identifier extends FlexFieldKind<FieldEditor<0>, typeof identifierFieldIdentifier, Multiplicity.Single> {
}
export interface Forbidden extends FlexFieldKind<FieldEditor<0>, typeof forbiddenFieldKindIdentifier, Multiplicity.Forbidden> {
}
/**
 * Default FieldKinds with their editor types erased.
 */
export declare const FieldKinds: {
    readonly required: typeof required;
    readonly optional: typeof optional;
    readonly sequence: typeof sequence;
    readonly identifier: Identifier;
    readonly forbidden: Forbidden;
};
/**
 * FullSchemaPolicy with the default field kinds.
 */
export declare const defaultSchemaPolicy: FullSchemaPolicy;
//# sourceMappingURL=defaultFieldKinds.d.ts.map