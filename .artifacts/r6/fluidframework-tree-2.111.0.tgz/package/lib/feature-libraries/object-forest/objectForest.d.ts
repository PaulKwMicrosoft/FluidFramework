/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Listenable } from "@fluidframework/core-interfaces";
import { type Anchor, AnchorSet, type AnnouncedVisitor, type CursorLocationType, type DeltaVisitor, type DetachedField, type FieldAnchor, type FieldKey, type FieldUpPath, type ForestEvents, type IEditableForest, type ITreeCursorSynchronous, type ITreeSubscriptionCursor, ITreeSubscriptionCursorState, type MapTree, type PathRootPrefix, type TreeChunk, TreeNavigationResult, type TreeNodeSchemaIdentifier, type TreeStoredSchemaSubscription, type UpPath, type Value } from "../../core/index.js";
import { type Breakable, type WithBreakable } from "../../util/index.js";
import { type CursorWithNode, SynchronousCursor } from "../treeCursorUtils.js";
/** A `MapTree` with mutable fields */
interface MutableMapTree extends MapTree {
    readonly fields: Map<FieldKey, MutableMapTree[]>;
}
/**
 * Reference implementation of IEditableForest.
 *
 * This implementation focuses on correctness and simplicity, not performance.
 * It does not use compressed chunks: instead nodes are implemented using objects.
 */
export declare class ObjectForest implements IEditableForest, WithBreakable {
    #private;
    readonly breaker: Breakable;
    /**
     * If provided, may be used for validation, but otherwise unused.
     */
    readonly schema: TreeStoredSchemaSubscription | undefined;
    readonly anchors: AnchorSet;
    readonly additionalAsserts: boolean;
    private activeVisitor?;
    readonly currentCursors: Set<Cursor>;
    private readonly deltaVisitors;
    readonly events: Listenable<ForestEvents>;
    get roots(): MapTree;
    constructor(breaker: Breakable, 
    /**
     * If provided, may be used for validation, but otherwise unused.
     */
    schema: TreeStoredSchemaSubscription | undefined, anchors?: AnchorSet, additionalAsserts?: boolean, roots?: MapTree);
    get isEmpty(): boolean;
    clone(schema: TreeStoredSchemaSubscription, breaker?: Breakable): ObjectForest;
    chunkField(cursor: ITreeCursorSynchronous): TreeChunk[];
    forgetAnchor(anchor: Anchor): void;
    /**
     * Throw (and break) if content does not match schema.
     */
    checkSchema(): void;
    acquireVisitor(): DeltaVisitor;
    registerAnnouncedVisitor(visitor: () => AnnouncedVisitor): void;
    deregisterAnnouncedVisitor(visitor: () => AnnouncedVisitor): void;
    private nextRange;
    newDetachedField(): DetachedField;
    private add;
    private addFieldAsDetached;
    private delete;
    allocateCursor(source?: string): Cursor;
    tryMoveCursorToNode(destination: Anchor, cursorToMove: ITreeSubscriptionCursor): TreeNavigationResult;
    tryMoveCursorToField(destination: FieldAnchor, cursorToMove: ITreeSubscriptionCursor): TreeNavigationResult;
    moveCursorToPath(destination: UpPath | undefined, cursorToMove: ITreeSubscriptionCursor): void;
    getCursorAboveDetachedFields(): ITreeCursorSynchronous;
}
/**
 * Cursor implementation for ObjectForest.
 */
declare class Cursor extends SynchronousCursor implements ITreeSubscriptionCursor {
    readonly forest: ObjectForest;
    readonly source: string | undefined;
    private innerCursor?;
    state: ITreeSubscriptionCursorState;
    /**
     * @param forest - forest this cursor navigates
     * @param innerCursor - underlying cursor implementation this wraps. `undefined` when state is not `Current`
     */
    constructor(forest: ObjectForest, source: string | undefined, innerCursor?: CursorWithNode<MutableMapTree> | undefined);
    buildFieldAnchor(): FieldAnchor;
    getFieldPath(prefix?: PathRootPrefix): FieldUpPath;
    get mode(): CursorLocationType;
    nextField(): boolean;
    exitField(): void;
    skipPendingFields(): boolean;
    getFieldKey(): FieldKey;
    getFieldLength(): number;
    firstNode(): boolean;
    enterNode(childIndex: number): void;
    getPath(prefix?: PathRootPrefix): UpPath;
    get fieldIndex(): number;
    get chunkStart(): number;
    get chunkLength(): number;
    seekNodes(offset: number): boolean;
    nextNode(): boolean;
    exitNode(): void;
    firstField(): boolean;
    enterField(key: FieldKey): void;
    get type(): TreeNodeSchemaIdentifier;
    get value(): Value;
    clear(): void;
    /**
     * Move this cursor to the special dummy node above the detached sequences.
     * Can be used when cleared (but not freed).
     */
    setToAboveDetachedSequences(): void;
    getNode(): MutableMapTree;
    getParent(): [MutableMapTree, FieldKey];
    fork(source?: string): ITreeSubscriptionCursor;
    free(): void;
    buildAnchor(): Anchor;
}
/**
 * Returns an implementation of {@link IEditableForest} with no content.
 * @privateRemarks
 * TODO:
 * refactor to remove this function, and instead place `ForestTypeReference` and `ForestTypeExpensiveDebug` here as a better way to encapsulate ObjectForest.
 */
export declare function buildForest(breaker: Breakable, schema?: TreeStoredSchemaSubscription, anchors?: AnchorSet, additionalAsserts?: boolean): ObjectForest;
export {};
//# sourceMappingURL=objectForest.d.ts.map