/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ChangeFamily, ChangeFamilyEditor, ChangeRebaser } from "../core/index.js";
/**
 * Makes a given `ChangeFamily` safer to use by wrapping some of its functions in try-catch blocks.
 *
 * Mitigated functions:
 * - {@link ChangeFamily.intoDelta} (an empty Delta is returned instead)
 * - {@link ChangeRebaser.rebase} (the given `fallbackChange` is returned instead)
 * - {@link ChangeRebaser.invert} (the given `fallbackChange` is returned instead)
 * - {@link ChangeRebaser.compose} (the given `fallbackChange` is returned instead)
 *
 * @param unmitigatedChangeFamily - The change family to mitigate.
 * @param fallbackChange - A changeset to use as a fallback when one of the mitigated functions throws.
 * @param onError - A callback invoked for each error thrown.
 * @returns a mitigated change family.
 */
export declare function makeMitigatedChangeFamily<TEditor extends ChangeFamilyEditor, TChange>(unmitigatedChangeFamily: ChangeFamily<TEditor, TChange>, fallbackChange: TChange, onError: (error: unknown) => void): ChangeFamily<TEditor, TChange>;
export declare function makeMitigatedRebaser<TChange>(unmitigatedRebaser: ChangeRebaser<TChange>, fallbackChange: TChange, onError: (error: unknown) => void): ChangeRebaser<TChange>;
//# sourceMappingURL=mitigatedChangeFamily.d.ts.map