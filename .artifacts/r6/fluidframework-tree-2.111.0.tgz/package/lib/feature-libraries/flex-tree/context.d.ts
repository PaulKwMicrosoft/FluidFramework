/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Listenable } from "@fluidframework/core-interfaces";
import { type DetachedField, type FieldKindIdentifier, type ForestEvents, type SchemaPolicy, type TreeStoredSchema } from "../../core/index.js";
import type { ITreeCheckout } from "../../shared-tree/index.js";
import { type IDisposable, disposeSymbol } from "../../util/index.js";
import type { NodeIdentifierManager } from "../node-identifier/index.js";
import type { FlexTreeField } from "./flexTreeTypes.js";
import type { LazyEntity } from "./lazyEntity.js";
/**
 * Context for FlexTrees.
 */
export interface FlexTreeContext {
    /**
     * Schema used within this context.
     * All data must conform to these schema.
     */
    readonly schema: TreeStoredSchema;
    /**
     * SchemaPolicy used within this context.
     */
    readonly schemaPolicy: SchemaPolicy;
    /**
     * If true, this context is the canonical context instance for a given view,
     * and its schema include all schema from the document.
     *
     * If false, this context was created for use in a unhydrated tree, and the full document schema is unknown.
     */
    isHydrated(): this is FlexTreeHydratedContext;
    /**
     * If true, none of the nodes in this context can be used.
     */
    isDisposed(): boolean;
}
/**
 * Subset of a hydrated context which can be used in more cases (like before the root and events are set up).
 */
export interface FlexTreeHydratedContextMinimal {
    /**
     * The {@link NodeIdentifierManager} responsible for allocating and compressing identifiers for nodes in this context.
     */
    readonly nodeKeyManager: NodeIdentifierManager;
    /**
     * The checkout object associated with this context.
     */
    readonly checkout: ITreeCheckout;
}
/**
 * A common context of a "forest" of FlexTrees.
 * It handles group operations like transforming cursors into anchors for edits.
 */
export interface FlexTreeHydratedContext extends FlexTreeContext, FlexTreeHydratedContextMinimal {
    readonly events: Listenable<ForestEvents>;
    /**
     * Gets the root field of the tree.
     */
    get root(): FlexTreeField;
}
/**
 * Creating multiple flex tree contexts for the same branch, and thus with the same underlying AnchorSet does not work due to how TreeNode caching works.
 * This slot is used to detect if one already exists and error if creating a second.
 */
export declare const ContextSlot: import("../../core/index.js").AnchorSlot<Context>;
/**
 * Implementation of `FlexTreeHydratedContext`.
 *
 * @remarks An editor is required to edit the FlexTree.
 *
 * A {@link FlexTreeContext} which is used to manage the cursors and anchors within the FlexTrees:
 * This is necessary for supporting using this tree across edits to the forest, and not leaking memory.
 *
 * This context and the trees it produces observe the kinds of fields from the schema
 */
export declare class Context implements FlexTreeHydratedContext, IDisposable {
    readonly schemaPolicy: SchemaPolicy;
    readonly checkout: ITreeCheckout;
    /**
     * An object which handles node key generation and conversion
     */
    readonly nodeKeyManager: NodeIdentifierManager;
    readonly withCursors: Set<LazyEntity>;
    readonly withAnchors: Set<LazyEntity>;
    /**
     * Callbacks to run when disposing.
     *
     * Mainly event un-registration.
     */
    private readonly onDispose;
    private disposed;
    /**
     * Stores the last accessed version of the root.
     * @remarks
     * Anything which can delete this field must clear it.
     * Currently "clear" is the only case.
     */
    private lazyRootCache;
    constructor(schemaPolicy: SchemaPolicy, checkout: ITreeCheckout, 
    /**
     * An object which handles node key generation and conversion
     */
    nodeKeyManager: NodeIdentifierManager);
    isHydrated(): this is FlexTreeHydratedContext;
    isDisposed(): boolean;
    get schema(): TreeStoredSchema;
    /**
     * Called before editing.
     * Clears all cursors so editing can proceed.
     */
    private prepareForEdit;
    [disposeSymbol](): void;
    /**
     * Release any cursors and anchors held by tree entities created in this context.
     * @remarks
     * Ensures the cashed references to those entities on the Anchors are also cleared.
     * The tree entities are invalid to use after this, but the context may still be used
     * to create new trees starting from the root.
     */
    clear(): void;
    /**
     * Gets the root field of the tree.
     * @remarks
     * This is a cached value: it should not be disposed by the accessor.
     * Like all other fields from this context, it will become invalid to use after {@link clear} is called or the {@link disposeSymbol} method is called.
     */
    get root(): FlexTreeField;
    /**
     * Returns a new {@link FlexTreeField} that will live as long as the caller allows up to the next call to {@link clear} or disposal of the context.
     * @remarks
     * Due to limited support for detached fields, not all operations are supported.
     * Additionally if the detached field's content is deleted, the field will become out of schema if it is required: it must not be used after that point.
     */
    detachedField(key: DetachedField, schema: FieldKindIdentifier): FlexTreeField;
    get events(): Listenable<ForestEvents>;
}
//# sourceMappingURL=context.d.ts.map