/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { FieldKey } from "../../core/index.js";
import type { FlexTreeNode } from "./flexTreeTypes.js";
/**
 * An object informed about observation made to trees.
 * @remarks
 * See {@link withObservation} and {@link currentObserver}.
 */
export interface Observer {
    /**
     * Arbitrary content in `node` subtree might be observed.
     */
    observeNodeDeep(node: FlexTreeNode): void;
    /**
     * Which fields exist (as non-empty) on `node` is being observed.
     * @remarks
     * The set of fields should be considered order independent.
     */
    observeNodeFields(node: FlexTreeNode): void;
    /**
     * The contents of the `key` field of `node` are being observed.
     * @remarks
     * Any (shallow) change to which children exist in this field, or in what order should invalidate this observation.
     */
    observeNodeField(node: FlexTreeNode, key: FieldKey): void;
    /**
     * The parent of `node` is being observed.
     */
    observeParentOf(node: FlexTreeNode): void;
}
/**
 * The current observer, if any.
 * @remarks
 * Set via {@link setObserver} as used by {@link withObservation}.
 * It should not be assigned in any other way.
 * @privateRemarks
 * This is exported directly as a property instead of via a getter for reduced overhead (less code, faster access) as this is used on some hot paths and its performance matters.
 * The case where this is undefined (no observation) is particularly important for performance as we do not want to regress code which is not using this feature very much.
 * Since it is not exported outside the package, this seems like a fine tradeoff, but could be reevaluated with some benchmarking if needed.
 */
export declare let currentObserver: Observer | undefined;
/**
 * For the duration of `f`, pushes `newObserver` onto the observer stack, making it the {@link currentObserver}.
 */
export declare function withObservation<T>(newObserver: Observer | undefined, f: () => T): T;
//# sourceMappingURL=observer.d.ts.map