/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type FieldAnchor, type FieldKey, type FieldKindIdentifier, type ITreeCursorSynchronous, type ITreeSubscriptionCursor, type NormalizedFieldUpPath, type TreeNavigationResult } from "../../core/index.js";
import { type IDefaultEditBuilder, type OptionalFieldEditBuilder, type SequenceFieldEditBuilder, type ValueFieldEditBuilder } from "../default-schema/index.js";
import type { FlexFieldKind } from "../modular-schema/index.js";
import type { Context } from "./context.js";
import { FlexTreeEntityKind, type FlexTreeField, type FlexTreeOptionalField, type FlexTreeRequiredField, type FlexTreeSequenceField, type FlexTreeTypedField, type FlexTreeUnknownUnboxed, type FlexibleFieldContent, type FlexibleNodeContent, type HydratedFlexTreeNode, flexTreeMarker } from "./flexTreeTypes.js";
import { LazyEntity } from "./lazyEntity.js";
export declare function makeField(context: Context, schema: FieldKindIdentifier, cursor: ITreeSubscriptionCursor): FlexTreeField;
/**
 * Base type for fields implementing {@link FlexTreeField} using cursors.
 */
export declare abstract class LazyField extends LazyEntity<FieldAnchor> implements FlexTreeField {
    readonly schema: FieldKindIdentifier;
    get [flexTreeMarker](): FlexTreeEntityKind.Field;
    readonly key: FieldKey;
    /**
     * If this field ends its lifetime before the Anchor does, this needs to be invoked to avoid a double free
     * if/when the Anchor is destroyed.
     */
    private readonly offAfterDestroy?;
    constructor(context: Context, schema: FieldKindIdentifier, cursor: ITreeSubscriptionCursor, fieldAnchor: FieldAnchor);
    is<TKind2 extends FlexFieldKind>(kind: TKind2): this is FlexTreeTypedField<TKind2>;
    get parent(): HydratedFlexTreeNode | undefined;
    protected tryMoveCursorToAnchor(cursor: ITreeSubscriptionCursor): TreeNavigationResult;
    protected forgetAnchor(): void;
    get length(): number;
    atIndex(index: number): FlexTreeUnknownUnboxed;
    boxedAt(index: number): HydratedFlexTreeNode | undefined;
    map<U>(callbackfn: (value: FlexTreeUnknownUnboxed, index: number) => U): U[];
    [Symbol.iterator](): IterableIterator<HydratedFlexTreeNode>;
    getFieldPath(): NormalizedFieldUpPath;
    /**
     * Returns the path to this field to use for editing. Removed nodes additionally
     * permit editing when the checkout supports detached-root editing.
     * This path is not valid to hold onto across edits: this must be recalled for each edit.
     */
    getFieldPathForEditing(): NormalizedFieldUpPath;
    protected getEditor(): IDefaultEditBuilder<ITreeCursorSynchronous>;
    protected getDetachedId(node: HydratedFlexTreeNode): ChangeAtomId;
}
export declare class LazySequence extends LazyField implements FlexTreeSequenceField {
    at(index: number): FlexTreeUnknownUnboxed | undefined;
    get asArray(): readonly FlexTreeUnknownUnboxed[];
    editor: SequenceFieldEditBuilder<FlexibleFieldContent>;
    private sequenceEditor;
}
export declare class LazyValueField extends LazyField implements FlexTreeRequiredField {
    editor: ValueFieldEditBuilder<FlexibleNodeContent>;
    private valueFieldEditor;
    get content(): FlexTreeUnknownUnboxed;
}
export declare class LazyOptionalField extends LazyField implements FlexTreeOptionalField {
    editor: OptionalFieldEditBuilder<FlexibleNodeContent>;
    private optionalEditor;
    get content(): FlexTreeUnknownUnboxed | undefined;
}
export declare class LazyForbiddenField extends LazyField {
}
/**
 * Returns the flex tree node, or the value if it has one.
 */
export declare function unboxedFlexNode(context: Context, cursor: ITreeSubscriptionCursor, fieldAnchor: FieldAnchor): FlexTreeUnknownUnboxed;
//# sourceMappingURL=lazyField.d.ts.map