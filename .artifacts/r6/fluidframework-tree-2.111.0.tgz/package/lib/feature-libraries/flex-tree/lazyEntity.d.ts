/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ITreeCursorSynchronous, type ITreeSubscriptionCursor, TreeNavigationResult } from "../../core/index.js";
import { type IDisposable, disposeSymbol } from "../../util/index.js";
import type { Context } from "./context.js";
import { type FlexTreeEntity, type FlexTreeEntityKind, flexTreeMarker } from "./flexTreeTypes.js";
/**
 * Assert `entity` is not deleted.
 * @privateRemarks
 * This can be faster than getting the tree status and checking that since that can require computing removed vs deleted.
 * TODO: provide a non implementation dependent way to leverage this optimization.
 */
export declare function assertFlexTreeEntityNotFreed(entity: FlexTreeEntity): void;
/**
 * This is a base class for lazy (cursor based) UntypedEntity implementations, which uniformly handles cursors and anchors.
 */
export declare abstract class LazyEntity<TAnchor = unknown> implements FlexTreeEntity, IDisposable {
    #private;
    readonly context: Context;
    readonly anchor: TAnchor;
    protected constructor(context: Context, cursor: ITreeSubscriptionCursor, anchor: TAnchor);
    borrowCursor(): ITreeCursorSynchronous;
    abstract get [flexTreeMarker](): FlexTreeEntityKind;
    [disposeSymbol](): void;
    prepareForEdit(): void;
    isFreed(): boolean;
    get cursor(): ITreeSubscriptionCursor;
    protected abstract tryMoveCursorToAnchor(cursor: ITreeSubscriptionCursor): TreeNavigationResult;
    /**
     * Called when disposing of this target, iff it has an anchor.
     */
    protected abstract forgetAnchor(): void;
}
//# sourceMappingURL=lazyEntity.d.ts.map