/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type Anchor, type AnchorNode, type FieldKey, type ITreeSubscriptionCursor, type TreeNavigationResult, type TreeNodeSchemaIdentifier, type Value } from "../../core/index.js";
import type { Context } from "./context.js";
import { FlexTreeEntityKind, type FlexTreeField, type HydratedFlexTreeNode, flexTreeMarker } from "./flexTreeTypes.js";
import { LazyEntity } from "./lazyEntity.js";
/**
 * Get or create a {@link HydratedFlexTreeNode} for the given context at node indicated by the cursor.
 * @remarks
 * This does not take ownership of this cursor: Node will fork it as needed.
 */
export declare function getOrCreateHydratedFlexTreeNode(context: Context, cursor: ITreeSubscriptionCursor): HydratedFlexTreeNode;
/**
 * Lazy implementation of {@link FlexTreeNode}.
 */
export declare class LazyTreeNode extends LazyEntity<Anchor> implements HydratedFlexTreeNode {
    #private;
    readonly type: TreeNodeSchemaIdentifier;
    readonly anchorNode: AnchorNode;
    get [flexTreeMarker](): FlexTreeEntityKind.Node;
    private readonly storedSchema;
    constructor(context: Context, type: TreeNodeSchemaIdentifier, cursor: ITreeSubscriptionCursor, anchorNode: AnchorNode, anchor: Anchor);
    isHydrated(): this is HydratedFlexTreeNode;
    protected tryMoveCursorToAnchor(cursor: ITreeSubscriptionCursor): TreeNavigationResult;
    protected forgetAnchor(): void;
    get value(): Value;
    readonly fields: Pick<Map<FieldKey, FlexTreeField>, typeof Symbol.iterator | "get">;
    tryGetField(fieldKey: FieldKey): FlexTreeField | undefined;
    getBoxed(key: FieldKey): FlexTreeField;
    [Symbol.iterator](): IterableIterator<FlexTreeField>;
    get parentField(): {
        readonly parent: FlexTreeField;
        readonly index: number;
    };
    keys(): IterableIterator<FieldKey>;
}
//# sourceMappingURL=lazyNode.d.ts.map