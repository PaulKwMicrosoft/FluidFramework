/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IChannelStorageService } from "@fluidframework/datastore-definitions/internal";
import type { IExperimentalIncrementalSummaryContext, ITelemetryContext, MinimumVersionForCollab } from "@fluidframework/runtime-definitions/internal";
import type { SummaryTreeBuilder } from "@fluidframework/runtime-utils/internal";
import type { DetachedFieldIndex } from "../core/index.js";
import { type Summarizable, type SummaryElementParser, type SummaryElementStringifier, VersionedSummarizer } from "../shared-tree-core/index.js";
/**
 * The storage key for the blob in the summary containing schema data
 */
export declare const detachedFieldIndexBlobKey = "DetachedFieldIndexBlob";
/**
 * The versions for the detached field index summary format.
 */
export declare const enum DetachedFieldIndexSummaryFormatVersion {
    /**
     * This version represents summary format before summary versioning was introduced.
     */
    v1 = 1,
    /**
     * This version adds metadata to the summary. This is backward compatible with version 1.
     */
    v2 = 2,
    /**
     * The latest version of the summary. Must be updated when a new version is added.
     */
    vLatest = 2
}
/**
 * Provides methods for summarizing and loading a tree index.
 */
export declare class DetachedFieldIndexSummarizer extends VersionedSummarizer<DetachedFieldIndexSummaryFormatVersion> implements Summarizable {
    private readonly detachedFieldIndex;
    constructor(detachedFieldIndex: DetachedFieldIndex, minVersionForCollab: MinimumVersionForCollab);
    protected summarizeInternal(props: {
        stringify: SummaryElementStringifier;
        fullTree?: boolean;
        trackState?: boolean;
        telemetryContext?: ITelemetryContext;
        incrementalSummaryContext?: IExperimentalIncrementalSummaryContext;
        builder: SummaryTreeBuilder;
    }): void;
    protected loadInternal(services: IChannelStorageService, parse: SummaryElementParser): Promise<void>;
}
//# sourceMappingURL=detachedFieldIndexSummarizer.d.ts.map