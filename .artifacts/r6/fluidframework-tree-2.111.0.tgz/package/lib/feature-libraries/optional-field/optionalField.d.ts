/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type DeltaFieldChanges, Multiplicity } from "../../core/index.js";
import { optionalIdentifier } from "../fieldKindIdentifiers.js";
import { type FieldChangeHandler, type FieldChangeRebaser, type FieldEditor, type ToDelta, FlexFieldKind } from "../modular-schema/index.js";
import type { OptionalChangeset } from "./optionalFieldChangeTypes.js";
export declare const optionalChangeRebaser: FieldChangeRebaser<OptionalChangeset>;
export interface OptionalFieldEditor extends FieldEditor<OptionalChangeset> {
    /**
     * Creates a change which will replace the content already in the field (if any at the time the change applies)
     * with new content.
     * The content in the field will be moved to the `ids.detach` register.
     * The content in the `ids.detach` register will be moved to into the field.
     * @param isEmpty - whether the field is empty when creating this change
     * @param ids - the ids associated with the change.
     */
    set(isEmpty: boolean, ids: {
        /** The ID of the node to attach in the field. */
        fill: ChangeAtomId;
        /** The ID to assign to whichever node (if any) is detached from the field when the change applies. */
        detach: ChangeAtomId;
    }): OptionalChangeset;
    /**
     * Creates a change which clears the field's contents (if any).
     * @param isEmpty - whether the field is empty when creating this change
     * @param detachId - the ID to assign to whichever node (if any) is detached from the field when the change applies.
     */
    clear(isEmpty: boolean, detachId: ChangeAtomId): OptionalChangeset;
    /**
     * Creates a change which sets the field's content to the node already in the field.
     * The initial change has no effect, but will ensure that the node is in this field
     * after rebasing over other changes.
     * This is only valid to create if the field is not empty.
     * @param pinId - The ID to use for moving the current content.
     * @param clearId - The ID to use for removing any other node from this field.
     * @returns
     */
    pin(pinId: ChangeAtomId, clearId: ChangeAtomId): OptionalChangeset;
}
export declare const optionalFieldEditor: OptionalFieldEditor;
export declare function optionalFieldIntoDelta(change: OptionalChangeset, deltaFromChild: ToDelta): DeltaFieldChanges;
export declare const optionalChangeHandler: FieldChangeHandler<OptionalChangeset, OptionalFieldEditor>;
interface Optional extends FlexFieldKind<OptionalFieldEditor, typeof optionalIdentifier, Multiplicity.Optional> {
}
/**
 * 0 or 1 items.
 */
export declare const optional: Optional;
export {};
//# sourceMappingURL=optionalField.d.ts.map