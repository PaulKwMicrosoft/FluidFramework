/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ITreeCursorSynchronous } from "../core/index.js";
/**
 * Tests whether a cursor's current node matches a previously captured subtree.
 * Built by {@link buildNodeComparator}
 */
export type NodeComparator = (cursor: ITreeCursorSynchronous) => boolean;
/**
 * Walks the cursor at its current node position and builds a comparator that can test whether another
 * cursor position has the same structure and values.
 *
 * @remarks
 * Fields are compared by key (not iteration order), so this is safe regardless of cursor field ordering.
 * Missing fields in the compared node will cause a mismatch.
 *
 * The cursor must be in Nodes mode. After this call, the cursor is restored to its original position.
 *
 */
export declare function buildNodeComparator(cursor: ITreeCursorSynchronous): NodeComparator;
//# sourceMappingURL=cursorComparator.d.ts.map