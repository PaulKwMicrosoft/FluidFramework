/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { FieldChangeHandler } from "./fieldChangeHandler.js";
import { FlexFieldKind } from "./fieldKind.js";
import { type GenericChangeset } from "./genericFieldKindTypes.js";
/**
 * {@link FieldChangeHandler} implementation for {@link GenericChangeset}.
 */
export declare const genericChangeHandler: FieldChangeHandler<GenericChangeset>;
/**
 * {@link FieldKind} used to represent changes to elements of a field in a field-kind-agnostic format.
 */
export declare const genericFieldKind: FlexFieldKind;
/**
 * Converts a {@link GenericChangeset} into a field-kind-specific `TChange`.
 * @param changeset - The generic changeset to convert.
 * @param target - The {@link FieldChangeHandler} for the `FieldKind` that the returned change should target.
 * @param composeChild - A delegate to compose {@link NodeChangeset}s.
 * @returns An equivalent changeset as represented by the `target` field-kind.
 */
export declare function convertGenericChange<TChange>(changeset: GenericChangeset, target: FieldChangeHandler<TChange>): TChange;
//# sourceMappingURL=genericFieldKind.d.ts.map