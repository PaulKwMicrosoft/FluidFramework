/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ICodecFamily, JsonCodecPart } from "../../codec/index.js";
import type { ChangeAtomId, ChangeAtomIdRangeMap, ChangeEncodingContext, DeltaFieldChanges, DeltaFieldMap, RevisionMetadataSource, RevisionReplacer, RevisionTag, RevisionTagSchema } from "../../core/index.js";
import type { IdAllocator, Invariant, RangeQueryResult } from "../../util/index.js";
import type { ChangeAtomIdBTree } from "../changeAtomIdBTree.js";
import type { ComposeNodeManager, InvertNodeManager, RebaseNodeManager } from "./crossFieldQueries.js";
import type { EncodedNodeChangeset } from "./modularChangeFormatV1.js";
import type { CrossFieldKeyRange, NodeId, RebaseVersion } from "./modularChangeTypes.js";
export type NestedChangesIndices = readonly (readonly [NodeId, inputIndex: number])[];
/**
 * Functionality provided by a field kind which will be composed with other `FieldChangeHandler`s to
 * implement a unified ChangeFamily supporting documents with multiple field kinds.
 */
export interface FieldChangeHandler<TChangeset, TEditor extends FieldEditor<TChangeset> = FieldEditor<TChangeset>> {
    _typeCheck?: Invariant<TChangeset>;
    readonly rebaser: FieldChangeRebaser<TChangeset>;
    readonly codecsFactory: (revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>) => ICodecFamily<TChangeset, FieldChangeEncodingContext>;
    readonly editor: TEditor;
    intoDelta(change: TChangeset, deltaFromChild: ToDelta): DeltaFieldChanges;
    /**
     * Returns whether this change is empty, meaning that it represents no modifications to the field
     * and could be removed from the ModularChangeset tree without changing its behavior.
     */
    isEmpty(change: TChangeset): boolean;
    /**
     * @param change - The field change to get the child changes from.
     *
     * @returns The set of `NodeId`s that correspond to nested changes in the given `change`.
     * Each `NodeId` is associated with the following:
     * - index of the node in the field in the input context of the changeset (or `undefined` if the node is not
     * attached in the input context).
     * - index of the node in the field in the output context of the changeset (or `undefined` if the node is not
     * attached in the output context).
     * For all returned entries where the index is defined,
     * the indices are are ordered from smallest to largest (with no duplicates).
     * The returned array is owned by the caller.
     */
    getNestedChanges(change: TChangeset): NestedChangesIndices;
    /**
     * @returns A list of all cross-field keys contained in the change.
     * This should not include cross-field keys in descendant fields.
     */
    getCrossFieldKeys(change: TChangeset): CrossFieldKeyRange[];
    createEmpty(): TChangeset;
    /**
     * Returns a potentially simplified version of this change.
     * The returned change must produce the same delta as `change`, but may have different rebasing behavior.
     * The returned change should be compatible with `rebaseVersion`.
     */
    squash(change: TChangeset, rebaseVersion: RebaseVersion, getInputRootId: (id: ChangeAtomId, count: number) => RangeQueryResult<ChangeAtomId>): TChangeset;
}
export interface FieldChangeRebaser<TChangeset> {
    /**
     * Compose a collection of changesets into a single one.
     * For each node which has a change in both changesets, `composeChild` must be called
     * and the result used as the composite node change.
     * Calling `composeChild` when one of the changesets has no node change is unnecessary but tolerated.
     * See `ChangeRebaser` for more details.
     */
    compose(change1: TChangeset, change2: TChangeset, composeChild: NodeChangeComposer, genId: IdAllocator, nodeManager: ComposeNodeManager, revisionMetadata: RevisionMetadataSource): TChangeset;
    /**
     * @returns the inverse of `changes`.
     * See `ChangeRebaser` for details.
     */
    invert(change: TChangeset, isRollback: boolean, genId: IdAllocator, revision: RevisionTag | undefined, nodeManager: InvertNodeManager, revisionMetadata: RevisionMetadataSource): TChangeset;
    /**
     * Rebase `change` over `over`.
     * See `ChangeRebaser` for details.
     */
    rebase(change: TChangeset, over: TChangeset, rebaseChild: NodeChangeRebaser, genId: IdAllocator, nodeManager: RebaseNodeManager, revisionMetadata: RebaseRevisionMetadata): TChangeset;
    /**
     * @returns `change` with any empty child node changesets removed.
     */
    prune(change: TChangeset, pruneChild: NodeChangePruner): TChangeset;
    replaceRevisions(change: TChangeset, replacer: RevisionReplacer): TChangeset;
    /**
     * Returns a copy of the given changeset with the same declarations (e.g., new cells) but no actual changes.
     * This is a kludge. TODO: remove once AB#46104 is completed.
     */
    mute(change: TChangeset): TChangeset;
}
/**
 * Helper for creating a {@link FieldChangeRebaser} which does not need access to revision tags.
 * This should only be used for fields where the child nodes cannot be edited.
 */
export declare function referenceFreeFieldChangeRebaser<TChangeset>(data: {
    compose: (change1: TChangeset, change2: TChangeset) => TChangeset;
    invert: (change: TChangeset) => TChangeset;
    rebase: (change: TChangeset, over: TChangeset) => TChangeset;
    mute: (change: TChangeset) => TChangeset;
}): FieldChangeRebaser<TChangeset>;
export declare function isolatedFieldChangeRebaser<TChangeset>(data: {
    compose: FieldChangeRebaser<TChangeset>["compose"];
    invert: FieldChangeRebaser<TChangeset>["invert"];
    rebase: FieldChangeRebaser<TChangeset>["rebase"];
    mute: FieldChangeRebaser<TChangeset>["mute"];
}): FieldChangeRebaser<TChangeset>;
export interface FieldEditor<TChangeset> {
    /**
     * Creates a changeset which represents the given changes to the children of this editor's field.
     * For each element in the given iterable
     * - The number represents the index of the child node in the field.
     * - The `NodeId` represents the nested changes for that child node.
     * Note: The indices in the iterable must be ordered from smallest to largest (with no duplicates).
     */
    buildChildChanges(changes: Iterable<[index: number, change: NodeId]>): TChangeset;
}
/**
 * The `index` represents the index of the child node in the input context.
 * The `index` should be `undefined` iff the child node does not exist in the input context (e.g., an inserted node).
 */
export type ToDelta = (child: NodeId) => DeltaFieldMap;
export type NodeChangeInverter = (change: NodeId) => NodeId;
export declare enum NodeAttachState {
    Attached = 0,
    Detached = 1
}
export type NodeChangeRebaser = (change: NodeId | undefined, baseChange: NodeId | undefined, 
/**
 * Whether the node is attached to this field in the output context of the base change.
 * Defaults to attached if undefined.
 */
state?: NodeAttachState) => NodeId | undefined;
export type NodeChangeComposer = (change1: NodeId | undefined, change2: NodeId | undefined) => NodeId;
export type NodeChangePruner = (change: NodeId) => NodeId | undefined;
export interface RebaseRevisionMetadata extends RevisionMetadataSource {
    readonly getRevisionToRebase: () => RevisionTag | undefined;
    readonly getBaseRevisions: () => RevisionTag[];
}
export interface FieldChangeEncodingContext {
    readonly baseContext: ChangeEncodingContext;
    /**
     * A map from root ID to node ID, containing all roots which were last detached from this field.
     * The field must encode these root node changes.
     * This is only needed when encoding to a ModularChangeFormat older than v3,
     * as in those versions, changes to root nodes were represented in the field they were last detached from.
     * This should only be used during encoding.
     */
    readonly rootNodeChanges: ChangeAtomIdBTree<NodeId>;
    /**
     * A map from input context root ID to output context root ID, containing all roots which were last detached from this field.
     * The field must encode these renames.
     * This is only needed when encoding to a ModularChangeFormat older than v3,
     * as in those versions, root node renames were represented in the field they were last detached from.
     * This should only be used during encoding.
     */
    readonly rootRenames: ChangeAtomIdRangeMap<ChangeAtomId>;
    encodeNode(nodeId: NodeId): EncodedNodeChangeset;
    /**
     * Returns the input context root ID from an output context root ID.
     * This is only needed for encoding to sequence field format v3 and older.
     * This should only be called during encoding.
     */
    getInputRootId(outputRootId: ChangeAtomId, count: number): RangeQueryResult<ChangeAtomId | undefined>;
    /**
     * Returns the output context root ID from an input context root ID.
     * This is only needed for encoding to sequence field format v3 and older.
     * This should only be called during encoding.
     */
    getOutputRootId(outputRootId: ChangeAtomId, count: number): RangeQueryResult<ChangeAtomId | undefined>;
    /**
     * XXX: Comment
     */
    getFirstRenameId(inputRootId: ChangeAtomId, count: number): RangeQueryResult<ChangeAtomId | undefined>;
    /**
     * Returns the input context root ID from an output context root ID.
     * This is only needed for encoding to sequence field format v3 and older.
     * This should only be called during encoding.
     */
    isAttachId(id: ChangeAtomId, count: number): RangeQueryResult<boolean>;
    /**
     * Returns whether `id` is used as a detach ID in this changeset.
     * This is only needed for encoding to sequence field format v3 and older.
     * This should only be called during encoding.
     */
    isDetachId(id: ChangeAtomId, count: number): RangeQueryResult<boolean>;
    decodeNode(encodedNode: EncodedNodeChangeset): NodeId;
    /**
     * Must be called for each root node changeset encoded in this field.
     * This is only needed when encoding to a ModularChangeFormat older than v3,
     * as in those versions, changes to root node were represented in the field they were last detached from.
     * This should only be called during decoding.
     */
    decodeRootNodeChange(detachId: ChangeAtomId, encodedNode: EncodedNodeChangeset): void;
    /**
     * Must be called for each root node rename encoded in this field.
     * * This should only be called during decoding.
     * as in those versions, root node renames were represented in the field they were last detached from.
     * @param doesChangeDetachRoots - Should be true iff these roots are attached in the input context of this changeset.
     *
     * This method is only needed to support encoding to ModularChangeset formats older than v3.
     */
    decodeRootRename(oldId: ChangeAtomId, newId: ChangeAtomId, count: number, firstIntermediateRename: ChangeAtomId | undefined, doesChangeDetachRoots: boolean): void;
    /**
     * Must be called for each node which has its detach location changed to this field.
     * The node may be either detached by this change, or already detached in this change's input context.
     * This is only needed when encoding to a ModularChangeFormat older than v3,
     * as in those versions, root node locations were represented in the field they were last detached from.
     * This should only be called during decoding.
     */
    decodeMoveAndDetach(detachId: ChangeAtomId, count: number): void;
    /**
     * Generates a new ChangeAtomId which has not been used in this changeset.
     * This is only needed for decoding optional field format v2 and older.
     * This should only be called during decoding.
     */
    generateId(): ChangeAtomId;
}
//# sourceMappingURL=fieldChangeHandler.d.ts.map