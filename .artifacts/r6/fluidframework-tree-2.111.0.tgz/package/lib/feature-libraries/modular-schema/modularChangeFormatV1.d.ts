/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { schemaFormatV1 } from "../../core/index.js";
import { type JsonCompatibleReadOnly } from "../../util/index.js";
export declare const EncodedFieldChange: Type.TObject<{
    fieldKey: Type.TUnsafe<schemaFormatV1.FieldKey>;
    fieldKind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
    change: Type.TUnsafe<JsonCompatibleReadOnly>;
}>;
export interface EncodedFieldChange extends Static<typeof EncodedFieldChange> {
    /**
     * Encoded in format selected by `fieldKind`
     */
    change: JsonCompatibleReadOnly;
}
export declare const EncodedFieldChangeMap: Type.TArray<Type.TObject<{
    fieldKey: Type.TUnsafe<schemaFormatV1.FieldKey>;
    fieldKind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
    change: Type.TUnsafe<JsonCompatibleReadOnly>;
}>>;
/**
 * Format for encoding as json.
 *
 * This chooses to use lists of named objects instead of maps:
 * this choice is somewhat arbitrary, but avoids user data being used as object keys,
 * which can sometimes be an issue (for example handling that for "__proto__" can require care).
 */
export type EncodedFieldChangeMap = Static<typeof EncodedFieldChangeMap>;
export declare const EncodedNodeChangeset: Type.TObject<{
    fieldChanges: Type.TOptional<Type.TArray<Type.TObject<{
        fieldKey: Type.TUnsafe<schemaFormatV1.FieldKey>;
        fieldKind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
        change: Type.TUnsafe<JsonCompatibleReadOnly>;
    }>>>;
    nodeExistsConstraint: Type.TOptional<Type.TObject<{
        violated: Type.TBoolean;
    }>>;
}>;
/**
 * Format for encoding as json.
 */
export type EncodedNodeChangeset = Static<typeof EncodedNodeChangeset>;
export declare const EncodedRevisionInfo: Type.TObject<{
    revision: Type.TReadonly<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    rollbackOf: Type.TReadonly<Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>>;
}>;
export type EncodedRevisionInfo = Static<typeof EncodedRevisionInfo>;
/**
 * Index of field in an EncodedFieldBatch.
 */
export declare const EncodedTreeIndex: Type.TNumber;
export declare const CommitBuilds: Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>;
export type CommitBuilds = Static<typeof CommitBuilds>;
export declare const EncodedBuildsArray: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
export type EncodedBuildsArray = Static<typeof EncodedBuildsArray>;
export declare const EncodedBuilds: Type.TObject<{
    builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
    /**
     * FieldBatch codec encoded data indexed by the EncodedTreeIndexes above.
     */
    trees: Type.TUnsafe<JsonCompatibleReadOnly>;
}>;
export type EncodedBuilds = Static<typeof EncodedBuilds>;
export declare const EncodedModularChangesetV1: Type.TObject<{
    maxId: Type.TOptional<Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>>;
    changes: Type.TArray<Type.TObject<{
        fieldKey: Type.TUnsafe<schemaFormatV1.FieldKey>;
        fieldKind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
        change: Type.TUnsafe<JsonCompatibleReadOnly>;
    }>>;
    revisions: Type.TReadonly<Type.TOptional<Type.TArray<Type.TObject<{
        revision: Type.TReadonly<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        rollbackOf: Type.TReadonly<Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>>;
    }>>>>;
    builds: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        /**
         * FieldBatch codec encoded data indexed by the EncodedTreeIndexes above.
         */
        trees: Type.TUnsafe<JsonCompatibleReadOnly>;
    }>>;
    refreshers: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        /**
         * FieldBatch codec encoded data indexed by the EncodedTreeIndexes above.
         */
        trees: Type.TUnsafe<JsonCompatibleReadOnly>;
    }>>;
    /**
     * The number of constraints within this changeset that are violated.
     */
    violations: Type.TOptional<Type.TNumber>;
}>;
export type EncodedModularChangesetV1 = Static<typeof EncodedModularChangesetV1>;
//# sourceMappingURL=modularChangeFormatV1.d.ts.map