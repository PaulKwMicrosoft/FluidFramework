/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ICodecFamily } from "../../codec/index.js";
import type { FieldChangeEncodingContext } from "./fieldChangeHandler.js";
import { type GenericChangeset } from "./genericFieldKindTypes.js";
export declare function makeGenericChangeCodec(): ICodecFamily<GenericChangeset, FieldChangeEncodingContext>;
//# sourceMappingURL=genericFieldKindCodecs.d.ts.map