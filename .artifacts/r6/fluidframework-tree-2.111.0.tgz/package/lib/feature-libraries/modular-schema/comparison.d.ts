/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { Multiplicity, type TreeFieldStoredSchema, type TreeNodeStoredSchema, type TreeStoredSchema, type TreeTypeSet, type ValueSchema } from "../../core/index.js";
import type { FullSchemaPolicy } from "./fieldKind.js";
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 *
 * `undefined` TreeNodeStoredSchema means the schema is not present (and thus treated as a NeverTree).
 */
export declare function allowsTreeSuperset(policy: FullSchemaPolicy, originalData: TreeStoredSchema, original: TreeNodeStoredSchema | undefined, superset: TreeNodeStoredSchema | undefined): boolean;
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 */
export declare function allowsValueSuperset(original: ValueSchema | undefined, superset: ValueSchema | undefined): boolean;
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 *
 * @param monotonicOnly - If true, only allow changes of field kinds which are explicitly listed in {@link FieldKindOptions.allowMonotonicUpgradeFrom}.
 * This prevents this function from considering two different schema as equivalent, preventing upgrades which would allow their inverse.
 * This prevents infinite upgrade loops where two clients could keep upgrading between two schema.
 *
 * @remarks
 * True if a client should be able to {@link TreeView.upgradeSchema} from a field schema using this field kind and `originalTypes` to `superset`.
 *
 * @privateRemarks
 * See also {@link FieldKindOptions.allowMonotonicUpgradeFrom} for constraints on the implementation.
 */
export declare function allowsFieldSuperset(policy: FullSchemaPolicy, originalData: TreeStoredSchema, original: TreeFieldStoredSchema, superset: TreeFieldStoredSchema, monotonicOnly?: boolean): boolean;
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 */
export declare function allowsTreeSchemaIdentifierSuperset(original: TreeTypeSet, superset: TreeTypeSet): boolean;
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 *
 * A version of this that assumes a specific root field could be slightly more permissive in some simple cases,
 * however if any extra fields and fields with unconstrained types are reachable,
 * it would have to compare everything anyway.
 */
export declare function allowsRepoSuperset(policy: FullSchemaPolicy, original: TreeStoredSchema, superset: TreeStoredSchema): boolean;
/**
 * Returns true iff `superset` is a superset of `original`.
 *
 * This does not require a strict (aka proper) superset: equivalent schema will return true.
 */
export declare function allowsMultiplicitySuperset(original: Multiplicity, superset: Multiplicity): boolean;
//# sourceMappingURL=comparison.d.ts.map