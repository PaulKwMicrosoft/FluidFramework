/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TAnySchema } from "@sinclair/typebox";
import { type ICodecOptions, type IJsonCodec, type JsonCodecPart, type SchemaValidationFunction } from "../../codec/index.js";
import { type ChangeEncodingContext, type FieldKindIdentifier, type RevisionInfo, type RevisionTag, type RevisionTagSchema } from "../../core/index.js";
import { type JsonCompatibleReadOnly, type Mutable } from "../../util/index.js";
import { type ChangeAtomIdBTree } from "../changeAtomIdBTree.js";
import { type FieldBatchCodec, type TreeChunk } from "../chunked-forest/index.js";
import { TreeCompressionStrategy } from "../treeCompressionUtils.js";
import type { FieldChangeEncodingContext } from "./fieldChangeHandler.js";
import type { FieldKindConfiguration } from "./fieldKindConfiguration.js";
import { EncodedModularChangesetV1 } from "./modularChangeFormatV1.js";
import type { EncodedBuilds, EncodedNodeChangeset, EncodedRevisionInfo } from "./modularChangeFormatV1.js";
import { type FieldChangeset, type FieldId, type ModularChangeset, type NodeId } from "./modularChangeTypes.js";
type ModularChangeCodec = IJsonCodec<ModularChangeset, EncodedModularChangesetV1, EncodedModularChangesetV1, ChangeEncodingContext>;
type FieldCodec = IJsonCodec<FieldChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, FieldChangeEncodingContext>;
type FieldChangesetCodecs = Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>;
export declare function getFieldChangesetCodecs(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, codecOptions: ICodecOptions): Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>;
type NodeEncoder = (nodeId: NodeId) => EncodedNodeChangeset;
export declare function decodeDetachedNodes(encoded: EncodedBuilds | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): ChangeAtomIdBTree<TreeChunk> | undefined;
export declare function decodeRevisionInfos(revisions: readonly EncodedRevisionInfo[] | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>): RevisionInfo[] | undefined;
export declare function makeModularChangeCodecV1(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, codecOptions: ICodecOptions, chunkCompressionStrategy?: TreeCompressionStrategy): ModularChangeCodec;
export declare function encodeChange(change: ModularChangeset, context: ChangeEncodingContext, fieldKinds: FieldKindConfiguration, fieldChangesetCodecs: FieldChangesetCodecs, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): EncodedModularChangesetV1;
export declare function makeFieldEncodingContextFactory(change: ModularChangeset, context: ChangeEncodingContext, encodeNode: NodeEncoder, encodeGlobalRootsSeparately?: boolean): (fieldId: FieldId) => FieldChangeEncodingContext;
export declare function encodeRevisionInfos(revisions: readonly RevisionInfo[], context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>): EncodedRevisionInfo[] | undefined;
export declare function encodeDetachedNodes(detachedNodes: ChangeAtomIdBTree<TreeChunk> | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): EncodedBuilds | undefined;
export declare function decodeChange(encodedChange: EncodedModularChangesetV1, context: ChangeEncodingContext, fieldKinds: FieldKindConfiguration, fieldChangesetCodecs: Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): Mutable<ModularChangeset>;
export {};
//# sourceMappingURL=modularChangeCodecV1.d.ts.map