/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type RevisionReplacer, type RevisionTag } from "../../core/index.js";
export declare class DefaultRevisionReplacer implements RevisionReplacer {
    readonly updatedRevision: RevisionTag;
    private readonly obsoleteRevisions;
    /**
     * Mapping from (obsolete revision tag, original local id) to the updated local id.
     */
    private readonly updatedLocalIds;
    /**
     * The set of local IDs already used in the scope of the updated revision.
     */
    private readonly localIds;
    /**
     * The maximum local ID seen so far in the scope of the updated revision.
     */
    private maxSeen;
    constructor(updatedRevision: RevisionTag, obsoleteRevisions: Set<RevisionTag | undefined>);
    isObsolete(revision: RevisionTag | undefined): boolean;
    getUpdatedAtomId<T extends ChangeAtomId>(id: T, count?: number): T;
    private areAllUnallocated;
}
//# sourceMappingURL=defaultRevisionReplacer.d.ts.map