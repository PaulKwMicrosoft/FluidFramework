/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export { allowsRepoSuperset, allowsTreeSchemaIdentifierSuperset, allowsFieldSuperset, allowsTreeSuperset, allowsMultiplicitySuperset, } from "./comparison.js";
export { isNeverField, isNeverTree } from "./isNeverTree.js";
export { type InvertNodeManager, type RebaseNodeManager, type ComposeNodeManager, type CrossFieldMap, type CrossFieldQuerySet, type DetachedNodeEntry, NodeMoveType, setInCrossFieldMap, } from "./crossFieldQueries.js";
export { EncodedRevisionInfo, EncodedModularChangesetV1, EncodedNodeChangeset, } from "./modularChangeFormatV1.js";
export { EncodedModularChangesetV2 } from "./modularChangeFormatV2.js";
export { FlexFieldKind, type FullSchemaPolicy } from "./fieldKind.js";
export { type FieldChangeHandler, type FieldChangeRebaser, type FieldEditor, type NodeChangeComposer, type NodeChangeInverter, type NodeChangeRebaser, type NodeChangePruner, referenceFreeFieldChangeRebaser, type RebaseRevisionMetadata, type ToDelta, NodeAttachState, type FieldChangeEncodingContext, type NestedChangesIndices, } from "./fieldChangeHandler.js";
export { type CrossFieldKey, type CrossFieldKeyRange, type FieldChange, type FieldChangeMap, type FieldChangeset, type HasFieldChanges, type ModularChangeset, type NodeExistsConstraint, type NodeId, type RebaseVersion, } from "./modularChangeTypes.js";
export { convertGenericChange, genericChangeHandler, genericFieldKind, } from "./genericFieldKind.js";
export type { GenericChangeset } from "./genericFieldKindTypes.js";
export { ModularChangeFamily, ModularEditBuilder, type EditDescription, type GlobalEditDescription, type FieldEditDescription, rebaseRevisionMetadataFromInfo, intoDelta, relevantRemovedRoots, updateRefreshers, } from "./modularChangeFamily.js";
export { ModularChangeFormatVersion, makeModularChangeCodecFamily, } from "./modularChangeCodecs.js";
export type { FieldKindConfiguration, FieldKindConfigurationEntry, } from "./fieldKindConfiguration.js";
export { DefaultRevisionReplacer } from "./defaultRevisionReplacer.js";
//# sourceMappingURL=index.d.ts.map