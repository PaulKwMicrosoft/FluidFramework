/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static, TAnySchema, TSchema } from "@sinclair/typebox";
export declare const EncodedGenericChange: <NodeChangesetSchema extends Type.TSchema>(tNodeChangeset: NodeChangesetSchema) => Type.TTuple<[Type.TNumber, NodeChangesetSchema]>;
export type EncodedGenericChange<Schema extends TSchema = TAnySchema> = Static<ReturnType<typeof EncodedGenericChange<Schema>>>;
export declare const EncodedGenericChangeset: <NodeChangesetSchema extends Type.TSchema>(tNodeChangeset: NodeChangesetSchema) => Type.TArray<Type.TTuple<[Type.TNumber, NodeChangesetSchema]>>;
export type EncodedGenericChangeset<Schema extends TSchema = TAnySchema> = Static<ReturnType<typeof EncodedGenericChangeset<Schema>>>;
//# sourceMappingURL=genericFieldKindFormat.d.ts.map