/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ICodecOptions, type IJsonCodec, type JsonCodecPart } from "../../codec/index.js";
import type { ChangeEncodingContext, RevisionTag, RevisionTagSchema } from "../../core/index.js";
import type { FieldBatchCodec } from "../chunked-forest/index.js";
import { TreeCompressionStrategy } from "../treeCompressionUtils.js";
import type { FieldKindConfiguration } from "./fieldKindConfiguration.js";
import { EncodedModularChangesetV2 } from "./modularChangeFormatV2.js";
import type { ModularChangeset } from "./modularChangeTypes.js";
type ModularChangeCodec = IJsonCodec<ModularChangeset, EncodedModularChangesetV2, EncodedModularChangesetV2, ChangeEncodingContext>;
export declare function makeModularChangeCodecV2(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, codecOptions: ICodecOptions, chunkCompressionStrategy?: TreeCompressionStrategy): ModularChangeCodec;
export {};
//# sourceMappingURL=modularChangeCodecV2.d.ts.map