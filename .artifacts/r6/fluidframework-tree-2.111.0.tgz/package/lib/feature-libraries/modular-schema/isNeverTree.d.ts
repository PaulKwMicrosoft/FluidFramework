/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type TreeFieldStoredSchema, type TreeNodeStoredSchema, type TreeStoredSchema, type SchemaPolicy } from "../../core/index.js";
export declare function isNeverField(policy: SchemaPolicy, originalData: TreeStoredSchema, field: TreeFieldStoredSchema): boolean;
export declare function isNeverFieldRecursive(policy: SchemaPolicy, originalData: TreeStoredSchema, field: TreeFieldStoredSchema, parentTypeStack: Set<TreeNodeStoredSchema>): boolean;
/**
 * Returns true iff there are no possible trees that could meet this schema.
 * Trees which are infinite (like endless linked lists) are considered impossible.
 *
 * `undefined` means the schema is not present and thus a NeverTree.
 */
export declare function isNeverTree(policy: SchemaPolicy, originalData: TreeStoredSchema, treeNode: TreeNodeStoredSchema | undefined): boolean;
/**
 * Returns true iff there are no possible trees that could meet this schema.
 * Trees which are infinite (like endless linked lists) are considered impossible.
 *
 * `undefined` means the schema is not present and thus a NeverTree.
 */
export declare function isNeverTreeRecursive(policy: SchemaPolicy, originalData: TreeStoredSchema, treeNode: TreeNodeStoredSchema | undefined, parentTypeStack: Set<TreeNodeStoredSchema>): boolean;
//# sourceMappingURL=isNeverTree.d.ts.map