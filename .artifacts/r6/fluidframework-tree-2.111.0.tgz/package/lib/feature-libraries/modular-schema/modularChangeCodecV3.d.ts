/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ICodecOptions, type IJsonCodec, type JsonCodecPart } from "../../codec/index.js";
import { type ChangeEncodingContext, type RevisionTag, type RevisionTagSchema } from "../../core/index.js";
import type { FieldBatchCodec } from "../chunked-forest/index.js";
import { TreeCompressionStrategy } from "../treeCompressionUtils.js";
import type { FieldKindConfiguration } from "./fieldKindConfiguration.js";
import { EncodedModularChangesetV3 } from "./modularChangeFormatV3.js";
import { type ModularChangeset } from "./modularChangeTypes.js";
type ModularChangeCodec = IJsonCodec<ModularChangeset, EncodedModularChangesetV3, EncodedModularChangesetV3, ChangeEncodingContext>;
export declare function makeModularChangeCodecV3(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, codecOptions: ICodecOptions, chunkCompressionStrategy?: TreeCompressionStrategy): ModularChangeCodec;
export {};
//# sourceMappingURL=modularChangeCodecV3.d.ts.map