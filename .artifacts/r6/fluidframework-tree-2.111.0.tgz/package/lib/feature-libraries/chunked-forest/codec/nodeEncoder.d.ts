/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ITreeCursorSynchronous, type TreeNodeSchemaIdentifier } from "../../../core/index.js";
import type { Counter, DeduplicationTable } from "./chunkCodecUtilities.js";
import { type BufferFormat, Shape } from "./chunkEncodingGeneric.js";
import { type EncoderContext, type FieldEncoder, type KeyedFieldEncoder, type NodeEncoder } from "./compressedEncode.js";
import { type EncodedChunkShape, type EncodedFieldShape, type EncodedValueShape } from "./format/index.js";
/**
 * Encodes a node with the {@link EncodedNodeShape} shape.
 * @remarks
 * The fact this is also a Shape is an implementation detail of the encoder: that allows the shape it uses to be itself,
 * which is an easy way to keep all the related code together without extra objects.
 */
export declare class NodeShapeBasedEncoder extends Shape<EncodedChunkShape> implements NodeEncoder {
    readonly type: undefined | TreeNodeSchemaIdentifier;
    readonly value: EncodedValueShape;
    /**
     * Encoders for a specific set of fields, by key, in the order they will be encoded.
     * These are fields for which specialized encoding is provided as an optimization.
     * Using these for a given field instead of falling back to {@link NodeShapeBasedEncoder.specializedFieldEncoders} is often more efficient:
     * this avoids the need to explicitly include the key and shape in the encoded data for each node instance.
     * Instead, this information is here, and thus is encoded only once as part of the node shape.
     * These encoders will be used, even if the field they apply to is empty (which can add overhead for fields which are usually empty).
     *
     * Any fields not included here will be encoded using {@link NodeShapeBasedEncoder.otherFieldsEncoder}.
     * If {@link NodeShapeBasedEncoder.otherFieldsEncoder} is undefined, then this must handle all non-empty fields.
     */
    readonly specializedFieldEncoders: readonly KeyedFieldEncoder[];
    /**
     * Encoder for all other fields that are not in {@link NodeShapeBasedEncoder.specializedFieldEncoders}. These fields must
     * be encoded after the specialized fields.
     */
    readonly otherFieldsEncoder: undefined | FieldEncoder;
    /**
     * Set of keys for fields that are encoded using {@link NodeShapeBasedEncoder.specializedFieldEncoders}.
     * TODO: Ensure uniform chunks, encoding and identifier generation sort fields the same.
     */
    private readonly specializedFieldKeys;
    constructor(type: undefined | TreeNodeSchemaIdentifier, value: EncodedValueShape, 
    /**
     * Encoders for a specific set of fields, by key, in the order they will be encoded.
     * These are fields for which specialized encoding is provided as an optimization.
     * Using these for a given field instead of falling back to {@link NodeShapeBasedEncoder.specializedFieldEncoders} is often more efficient:
     * this avoids the need to explicitly include the key and shape in the encoded data for each node instance.
     * Instead, this information is here, and thus is encoded only once as part of the node shape.
     * These encoders will be used, even if the field they apply to is empty (which can add overhead for fields which are usually empty).
     *
     * Any fields not included here will be encoded using {@link NodeShapeBasedEncoder.otherFieldsEncoder}.
     * If {@link NodeShapeBasedEncoder.otherFieldsEncoder} is undefined, then this must handle all non-empty fields.
     */
    specializedFieldEncoders: readonly KeyedFieldEncoder[], 
    /**
     * Encoder for all other fields that are not in {@link NodeShapeBasedEncoder.specializedFieldEncoders}. These fields must
     * be encoded after the specialized fields.
     */
    otherFieldsEncoder: undefined | FieldEncoder);
    private getValueToEncode;
    encodeNode(cursor: ITreeCursorSynchronous, context: EncoderContext, outputBuffer: BufferFormat<EncodedChunkShape>): void;
    encodeShape(identifiers: DeduplicationTable<string>, shapes: DeduplicationTable<Shape<EncodedChunkShape>>): EncodedChunkShape;
    countReferencedShapesAndIdentifiers(identifiers: Counter<string>, shapeDiscovered: (shape: Shape<EncodedChunkShape>) => void): void;
    get shape(): Shape<EncodedChunkShape>;
}
export declare function encodeFieldShapes(fieldEncoders: readonly KeyedFieldEncoder[], identifiers: DeduplicationTable<string>, shapes: DeduplicationTable<Shape<EncodedChunkShape>>): EncodedFieldShape[] | undefined;
//# sourceMappingURL=nodeEncoder.d.ts.map