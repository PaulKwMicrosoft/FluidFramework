/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
/**
 * Encoded content is a {@link ChunkReferenceId}.
 * This represents the shape of a chunk that is encoded separately and is referenced by its {@link ChunkReferenceId}.
 */
export type EncodedIncrementalChunkShape = Static<typeof EncodedIncrementalChunkShape>;
export declare const EncodedIncrementalChunkShape: Type.TLiteral<0>;
/**
 * The chunk shapes supported by the V2 format.
 * @remarks
 * See {@link EncodedChunkShapeV2}.
 */
export declare const shapesV2: {
    readonly e: Type.TOptional<Type.TLiteral<0>>;
    readonly a: Type.TOptional<Type.TNumber>;
    readonly b: Type.TOptional<Type.TObject<{
        length: Type.TNumber;
        shape: Type.TNumber;
    }>>;
    readonly c: Type.TOptional<Type.TObject<{
        type: Type.TOptional<Type.TUnion<[Type.TString, Type.TNumber]>>;
        value: Type.TOptional<Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof import("./formatV1.js").SpecialField>]>>;
        fields: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>>>;
        extraFields: Type.TOptional<Type.TNumber>;
    }>>;
    readonly d: Type.TOptional<Type.TLiteral<0>>;
};
/**
 * V2 extension of {@link EncodedChunkShapeV1}.
 * @remarks
 * See {@link DiscriminatedUnionDispatcher} for more information on this pattern.
 */
export type EncodedChunkShapeV2 = Static<typeof EncodedChunkShapeV2>;
export declare const EncodedChunkShapeV2: Type.TObject<{
    readonly e: Type.TOptional<Type.TLiteral<0>>;
    readonly a: Type.TOptional<Type.TNumber>;
    readonly b: Type.TOptional<Type.TObject<{
        length: Type.TNumber;
        shape: Type.TNumber;
    }>>;
    readonly c: Type.TOptional<Type.TObject<{
        type: Type.TOptional<Type.TUnion<[Type.TString, Type.TNumber]>>;
        value: Type.TOptional<Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof import("./formatV1.js").SpecialField>]>>;
        fields: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>>>;
        extraFields: Type.TOptional<Type.TNumber>;
    }>>;
    readonly d: Type.TOptional<Type.TLiteral<0>>;
}>;
//# sourceMappingURL=formatV2.d.ts.map