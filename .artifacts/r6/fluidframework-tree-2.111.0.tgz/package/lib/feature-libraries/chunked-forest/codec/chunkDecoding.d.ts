/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor, OpSpaceCompressedId, SessionSpaceCompressedId } from "@fluidframework/id-compressor";
import type { Value, TreeChunk } from "../../../core/index.js";
import { type ChunkDecoder, type StreamCursor } from "./chunkCodecUtilities.js";
import { DecoderContext } from "./chunkDecodingGeneric.js";
import type { IncrementalDecoder } from "./codecs.js";
import { type EncodedChunkShape, type EncodedChunkShapeV2, type EncodedFieldBatchV1OrV2, type EncodedInlineArrayShape, type EncodedNestedArrayShape, type EncodedNodeShape, type EncodedSpecializedNodeShape, type EncodedValueShape, type ShapeIndex } from "./format/index.js";
/**
 * Context for decoding identifiers.
 * @remarks
 * See {@link FieldBatchDecodingContext} for the production implementation of this.
 *
 * This intentionally avoids exposing anything which depends on the underlying id-compressor's session ID to avoid confusion with the session ID of the compressor which encoded the data.
 * If the session ID of the encoder which encoded the data is known, that information is baked into `resolveEncodedId`.
 */
export interface IdDecodingContext {
    /**
     * Compressor which can decompress session-space identifiers from {@link resolveEncodedId} as needed.
     */
    readonly idCompressor: Pick<IIdCompressor, "decompress">;
    /**
     * Resolves an encoded op-space identifier to either a session-space ID
     * (which {@link idCompressor} can decompress if needed)
     * or a string (which passes through unchanged).
     * @remarks
     * In contexts where non-final identifiers can't be supported (where no originator session is available),
     * if a non-final identifier is encountered, this may throw or perform a data healing workaround.
     * See {@link FieldBatchDecodingContext.forOp} and {@link FieldBatchDecodingContext.forSummary} for details.
     */
    readonly resolveEncodedId: (id: OpSpaceCompressedId) => SessionSpaceCompressedId | string;
}
/**
 * Decode `chunk` into a TreeChunk.
 */
export declare function decode(chunk: EncodedFieldBatchV1OrV2, idDecodingContext: IdDecodingContext, incrementalDecoder?: IncrementalDecoder): TreeChunk[];
/**
 * Resolves `shapeIndex` to a fully-resolved {@link EncodedNodeShape}, normalizing away any
 * specialized node shapes (`f`) along the way by applying their overlays via
 * {@link applySpecialization} until a concrete node shape is reached.
 *
 * @param input - The index of the shape to resolve, which must be a concrete or specialized node shape.
 * @param context - The decoding context containing the shape definitions.
 * @param pendingResolution - (Internal) A set of shape indices visited so far in the current resolution chain, used to detect cycles in the specialization chain. Most callers should not provide this argument.
 *
 * @remarks
 * Exported for testing.
 */
export declare function normalizeToNodeShape(input: EncodedNodeShape | EncodedSpecializedNodeShape, context: DecoderContext<EncodedChunkShape>, pendingResolution?: Set<ShapeIndex>): EncodedNodeShape;
/**
 * Produces a specialized {@link EncodedNodeShape} by overlaying `overrides` onto `base`.
 *
 * See {@link EncodedSpecializedNodeShape} for the override/inherit/clear semantics.
 *
 * @remarks
 * Exported for testing.
 */
export declare function applySpecialization(base: EncodedNodeShape, overrides: EncodedSpecializedNodeShape, context: DecoderContext<EncodedChunkShape>): EncodedNodeShape;
/**
 * Decoder for {@link EncodedSpecializedNodeShape}s.
 * Applies the specialization's field overrides to the resolved base node shape, then delegates
 * to a {@link NodeDecoder} built from the resulting shape.
 */
export declare class SpecializedNodeDecoder implements ChunkDecoder {
    private readonly inner;
    constructor(shape: EncodedSpecializedNodeShape, context: DecoderContext<EncodedChunkShape>);
    decode(decoders: readonly ChunkDecoder[], stream: StreamCursor): TreeChunk;
}
/**
 * Decode a node's value from `stream` using its shape.
 */
export declare function readValue(stream: StreamCursor, shape: EncodedValueShape, idDecodingContext: IdDecodingContext): Value;
/**
 * Normalize a {@link TreeChunk} into an array.
 *
 * Unwraps {@link SequenceChunk}s, and wraps other chunks.
 */
export declare function deaggregateChunks(chunk: TreeChunk): TreeChunk[];
/**
 * Normalize a {@link TreeChunk}[] into a single TreeChunk.
 *
 * Avoids creating nested or less than 2 child {@link SequenceChunk}s.
 */
export declare function aggregateChunks(input: TreeChunk[]): TreeChunk;
/**
 * Decoder for {@link EncodedNestedArrayShape}s.
 */
export declare class NestedArrayDecoder implements ChunkDecoder {
    private readonly shape;
    constructor(shape: EncodedNestedArrayShape);
    decode(decoders: readonly ChunkDecoder[], stream: StreamCursor): TreeChunk;
}
/**
 * Decoder for {@link EncodedInlineArrayShape}s.
 */
export declare class InlineArrayDecoder implements ChunkDecoder {
    private readonly shape;
    constructor(shape: EncodedInlineArrayShape);
    decode(decoders: readonly ChunkDecoder[], stream: StreamCursor): TreeChunk;
}
/**
 * Decoder for {@link EncodedIncrementalChunkShape}s.
 */
export declare class IncrementalChunkDecoder implements ChunkDecoder {
    private readonly context;
    constructor(context: DecoderContext<EncodedChunkShapeV2>);
    decode(_: readonly ChunkDecoder[], stream: StreamCursor): TreeChunk;
}
/**
 * Decoder for {@link EncodedAnyShape}s.
 */
export declare const anyDecoder: ChunkDecoder;
/**
 * Decoder for {@link EncodedNodeShape}s.
 */
export declare class NodeDecoder implements ChunkDecoder {
    private readonly shape;
    private readonly context;
    private readonly type?;
    private readonly fieldDecoders;
    constructor(shape: EncodedNodeShape, context: DecoderContext<EncodedChunkShape>);
    decode(decoders: readonly ChunkDecoder[], stream: StreamCursor): TreeChunk;
}
//# sourceMappingURL=chunkDecoding.d.ts.map