/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import type { FieldBatchFormatVersion } from "./versions.js";
/**
 * Identifier OR Index of an identifier in the identifier list.
 */
export declare const IdentifierOrIndex: Type.TUnion<[Type.TString, Type.TNumber]>;
export type IdentifierOrIndex = Static<typeof IdentifierOrIndex>;
/**
 * Reference to a shape, by index.
 *
 * Shapes use a dictionary encoding where they are referenced by their index in a shape array.
 */
export declare const ShapeIndex: Type.TNumber;
export type ShapeIndex = Static<typeof ShapeIndex>;
export declare const Count: Type.TNumber;
declare const EncodedFieldBatchBase: Type.TObject<{
    identifiers: Type.TArray<Type.TString>;
    /**
     * Top level array is list of field from batch.
     * Inner are TreeValues mixed with indexes into "shapes" and nested arrays where lengths are needed.
     */
    data: Type.TArray<Type.TArray<Type.TAny>>;
}>;
/**
 * Format for encoding a tree chunk.
 * @param version - format version.
 * Must be changed if the previously existing decode logic will not correctly handle the new encoding.
 * If adding a new encoding version which does not use this format,
 * this parameter should be retyped to be a union of the subset of FieldBatchFormatVersion values which this supports.
 * @param shape - schema for union of shape format, see {@link DiscriminatedUnionDispatcher}.
 */
export declare const EncodedFieldBatchGeneric: <TShapeSchema extends Type.TSchema>(version: FieldBatchFormatVersion, shape: TShapeSchema) => Type.TObject<{
    data: Type.TArray<Type.TArray<Type.TAny>>;
    identifiers: Type.TArray<Type.TString>;
    version: Type.TLiteral<FieldBatchFormatVersion>;
    shapes: Type.TArray<TShapeSchema>;
}>;
export interface EncodedFieldBatchGeneric<TEncodedShape> extends Static<typeof EncodedFieldBatchBase> {
    shapes: TEncodedShape[];
    version: FieldBatchFormatVersion;
}
export {};
//# sourceMappingURL=formatGeneric.d.ts.map