/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
/**
 * Top level length is implied from length of data array.
 * All content are of this shape.
 */
export type EncodedNestedArrayShape = Static<typeof EncodedNestedArrayShape>;
export declare const EncodedNestedArrayShape: Type.TNumber;
/**
 * Inline array.
 */
export type EncodedInlineArrayShape = Static<typeof EncodedInlineArrayShape>;
export declare const EncodedInlineArrayShape: Type.TObject<{
    length: Type.TNumber;
    /**
     * All entries are this shape.
     */
    shape: Type.TNumber;
}>;
/**
 * Encoded as `shape, ...[data for shape]`.
 *
 * Used for polymorphism.
 */
export type EncodedAnyShape = Static<typeof EncodedAnyShape>;
export declare const EncodedAnyShape: Type.TLiteral<0>;
/**
 * Content of the encoded field is specified by the Shape referenced by the ShapeIndex.
 * This is a tuple for conciseness.
 */
export type EncodedFieldShape = Static<typeof EncodedFieldShape>;
export declare const EncodedFieldShape: Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>;
/**
 * Used in {@link EncodedValueShape} for special field kind handling.
 */
export declare enum SpecialField {
    /**
     * Special case for Identifier field kind.
     */
    Identifier = 0
}
/**
 * Shape of a value on a node.
 *
 * Due to limitations of TypeBox and differences between JavaScript objects, TypeScript types and JSON,
 * the case where no information about the value is captured in the shape is a bit confusing.
 * In TypeBox this is allowed by the user of this type putting it in an optional property.
 * In TypeScript it is modeled using `undefined`.
 * In JavaScript the property may be missing or explicitly `undefined`.
 * In JSON this will serialize as the property being omitted.
 * In this case, the value will be encoded as either:
 * - `false` (when there is no value) OR
 * - `true, value` when there is a value.
 *
 * For a more compact encoding, there are 4 options for the shape:
 * - `true`: there is a value, and it will simply be encoded by putting it in the output buffer (so `value`).
 * - `false`: there is never a value, and it takes up no space in the output buffer.
 * - `[value]`: there is a value, and its always the same.
 * - `SpecialField.Identifier`: special case for node identifier handling.
 * Takes up no space in the output buffer: the value comes from the shape arrays's content.
 * It is wrapped in an array to differentiate value shape types.
 *
 * In the future other value shape formats may be added, likely as objects.
 *
 * @remarks
 * See {@link EncodedNodeShape} for usage.
 */
export declare const EncodedValueShape: Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof SpecialField>]>;
export type EncodedValueShape = undefined | Static<typeof EncodedValueShape>;
/**
 * The encoded form of a {@link Shape} for a node.
 */
export type EncodedNodeShape = Static<typeof EncodedNodeShape>;
export declare const EncodedNodeShape: Type.TObject<{
    /**
     * If not provided, inlined in data.
     */
    type: Type.TOptional<Type.TUnion<[Type.TString, Type.TNumber]>>;
    value: Type.TOptional<Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof SpecialField>]>>;
    /**
     * Fields with fixed (per key) shapes.
     * They are encoded in the order they are specified here.
     * To ensure the order is preserved, this is an array instead of an object with keys.
     */
    fields: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>>>;
    /**
     * If undefined, no data. Otherwise, nested array of `[key, ...data]*`
     * Covers any fields beyond those in `fields`.
     */
    extraFields: Type.TOptional<Type.TNumber>;
}>;
/**
 * The chunk shapes supported by the V1 format.
 * @remarks
 * See {@link EncodedChunkShapeV1}.
 */
export declare const shapesV1: {
    /**
     * {@link EncodedNestedArrayShape} union member.
     */
    readonly a: Type.TOptional<Type.TNumber>;
    /**
     * {@link EncodedInlineArrayShape} union member.
     */
    readonly b: Type.TOptional<Type.TObject<{
        length: Type.TNumber;
        /**
         * All entries are this shape.
         */
        shape: Type.TNumber;
    }>>;
    /**
     * {@link EncodedNodeShape} union member.
     */
    readonly c: Type.TOptional<Type.TObject<{
        /**
         * If not provided, inlined in data.
         */
        type: Type.TOptional<Type.TUnion<[Type.TString, Type.TNumber]>>;
        value: Type.TOptional<Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof SpecialField>]>>;
        /**
         * Fields with fixed (per key) shapes.
         * They are encoded in the order they are specified here.
         * To ensure the order is preserved, this is an array instead of an object with keys.
         */
        fields: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>>>;
        /**
         * If undefined, no data. Otherwise, nested array of `[key, ...data]*`
         * Covers any fields beyond those in `fields`.
         */
        extraFields: Type.TOptional<Type.TNumber>;
    }>>;
    /**
     * {@link EncodedAnyShape} union member.
     */
    readonly d: Type.TOptional<Type.TLiteral<0>>;
};
/**
 * Discriminated union that represents the shapes of chunks in the encoded data.
 * "Chunk" here refers to a chunk of tree data, rooted at a range of nodes, that is encoded as a
 * single unit in a specific format represented by one of the shapes in this union.
 *
 * The concept of "chunk" is same for the tree data in memory and in the encoded wire format.
 * The physical representation of the chunk may differ, but the logical structure remains the same.
 * This is similar to other such concepts in the system.
 *
 * See {@link DiscriminatedUnionDispatcher} for more information on this pattern.
 * @privateRemarks
 * Because the TypeScript types for how we model these unions don't require exactly one property,
 * to prevent a union with more options from being assignable to this one, we include Never.
 * This matters in this case because the V2 format only differs in that it has another entry in this Union.
 */
export type EncodedChunkShapeV1 = Static<typeof EncodedChunkShapeV1>;
export declare const EncodedChunkShapeV1: Type.TObject<{
    e: Type.TOptional<Type.TNever>;
    a: Type.TOptional<Type.TNumber>;
    b: Type.TOptional<Type.TObject<{
        length: Type.TNumber;
        /**
         * All entries are this shape.
         */
        shape: Type.TNumber;
    }>>;
    c: Type.TOptional<Type.TObject<{
        /**
         * If not provided, inlined in data.
         */
        type: Type.TOptional<Type.TUnion<[Type.TString, Type.TNumber]>>;
        value: Type.TOptional<Type.TUnion<[Type.TBoolean, Type.TArray<Type.TAny>, Type.TEnum<typeof SpecialField>]>>;
        /**
         * Fields with fixed (per key) shapes.
         * They are encoded in the order they are specified here.
         * To ensure the order is preserved, this is an array instead of an object with keys.
         */
        fields: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TString, Type.TNumber]>, Type.TNumber]>>>;
        /**
         * If undefined, no data. Otherwise, nested array of `[key, ...data]*`
         * Covers any fields beyond those in `fields`.
         */
        extraFields: Type.TOptional<Type.TNumber>;
    }>>;
    d: Type.TOptional<Type.TLiteral<0>>;
}>;
//# sourceMappingURL=formatV1.d.ts.map