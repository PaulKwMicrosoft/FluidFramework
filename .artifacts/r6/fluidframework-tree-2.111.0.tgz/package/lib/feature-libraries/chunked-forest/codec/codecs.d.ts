/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor, OpSpaceCompressedId, SessionId, SessionSpaceCompressedId } from "@fluidframework/id-compressor";
import { VersionDispatchingCodecBuilder, type VersionDispatchingCodec } from "../../../codec/index.js";
import { type ITreeCursorSynchronous, type SchemaAndPolicy, type TreeChunk } from "../../../core/index.js";
import { type Brand, type IdentifierHealingConfig } from "../../../util/index.js";
import { TreeCompressionStrategy } from "../../treeCompressionUtils.js";
import { type IdDecodingContext } from "./chunkDecoding.js";
import type { FieldBatch } from "./fieldBatch.js";
import { EncodedFieldBatchV2, FieldBatchFormatVersion } from "./format/index.js";
import type { IncrementalEncodingPolicy } from "./incrementalEncodingPolicy.js";
/**
 * Reference ID for a chunk that is incrementally encoded.
 */
export type ChunkReferenceId = Brand<number, "forest.ChunkReferenceId">;
/**
 * Properties for incremental encoding.
 * Fields that support incremental encoding will encode their chunks separately by calling `encodeIncrementalField`.
 * @remarks
 * This supports features like incremental summarization where the summary from these fields can be re-used if
 * unchanged between summaries.
 * Note that each of these chunks that are incrementally encoded is fully self-describing (contain its own shapes
 * list and identifier table) and does not rely on context from its parent.
 */
export interface IncrementalEncoder {
    /**
     * Returns whether a node / field should be incrementally encoded.
     * @remarks See {@link IncrementalEncodingPolicy}.
     */
    shouldEncodeIncrementally: IncrementalEncodingPolicy;
    /**
     * Called to encode an incremental field at the cursor.
     * The chunks for this field are encoded separately from the main buffer.
     * @param cursor - The cursor pointing to the field to encode.
     * @param chunkEncoder - A function that encodes the contents of the passed chunk in the field.
     * @returns The reference IDs of the encoded chunks in the field.
     * This is used to retrieve the encoded chunks later.
     */
    encodeIncrementalField(cursor: ITreeCursorSynchronous, chunkEncoder: (chunk: TreeChunk) => EncodedFieldBatchV2): ChunkReferenceId[];
}
/**
 * Properties for incremental decoding.
 *
 * Fields that had their chunks incrementally encoded will retrieve them by calling `getEncodedIncrementalChunk`.
 * @remarks
 * See {@link IncrementalEncoder} for more details.
 */
export interface IncrementalDecoder {
    /**
     * Called to decode an incremental chunk with the given reference ID.
     * @param referenceId - The reference ID of the chunk to decode.
     * @param chunkDecoder - A function that decodes the chunk.
     * @returns The decoded chunk.
     */
    decodeIncrementalChunk(referenceId: ChunkReferenceId, chunkDecoder: (encoded: EncodedFieldBatchV2) => TreeChunk): TreeChunk;
}
/**
 * Combines the properties of {@link IncrementalEncoder} and {@link IncrementalDecoder}.
 */
export interface IncrementalEncoderDecoder extends IncrementalEncoder, IncrementalDecoder {
}
/**
 * Encode-side context for {@link FieldBatchCodec}.
 *
 * Carries only the data the encoder actually consumes. Originator-session
 * lookup, heal flags, and the incremental *decoder* live on
 * {@link FieldBatchDecodingContext}.
 */
export interface FieldBatchEncodingContext {
    readonly encodeType: TreeCompressionStrategy;
    readonly idCompressor: IIdCompressor;
    readonly schema?: SchemaAndPolicy;
    /**
     * Encoder for incremental fields. Defined when incremental encoding is
     * supported and enabled.
     */
    readonly incrementalEncoder?: IncrementalEncoder;
    /**
     * `true` when encoding to a summary blob. `false` for op-stream encode
     * paths and for utility encoders that aren't tied to a persisted document.
     *
     * @remarks
     * Used by the node encoder to decide whether non-finalized op-space ids
     * can be written into the batch (they can't, for summaries).
     */
    readonly isSummary: boolean;
}
/**
 * Decode-side context for {@link FieldBatchCodec}.
 *
 * Carries the per-call `resolveEncodedId` function that encapsulates the
 * originator-session lookup and (for the forest-summarizer's legacy heal path)
 * the deterministic UUIDv5 synthesis. Heal and originator-session flags live
 * inside that function, not on this context.
 *
 * Constructed via one of the two named static factories — {@link forOp} or
 * {@link forSummary} — depending on the call site's semantics. The constructor
 * is private; there is no general-purpose builder, because the choice between
 * op-style and summary-style decoding is load-bearing (different invariants
 * apply, and bugs in this area are typically the result of conflating them).
 */
export declare class FieldBatchDecodingContext implements IdDecodingContext {
    /**
     * Used internally to prevent the use of this decoder in incremental chunks if it has a session id (which would be wrong in those chunks).
     */
    private readonly hasOriginatorSessionId;
    readonly idCompressor: Pick<IIdCompressor, "decompress">;
    readonly resolveEncodedId: (id: OpSpaceCompressedId) => SessionSpaceCompressedId | string;
    /**
     * Decoder for incremental fields. Defined when the encoded batch contains
     * incremental chunks. Only populated on summary-style contexts; op-style
     * contexts always have this undefined.
     */
    readonly incrementalDecoder?: IncrementalDecoder | undefined;
    private constructor();
    /**
     * Construct a decode context for an op.
     *
     * The originator is the session that produced the encoded form (carried
     * alongside the op envelope by the caller). Heal-on-decode is *not*
     * available — an unresolvable id during op decode indicates a real bug,
     * not a recoverable state, so the resolver throws rather than synthesizing
     * a UUID. Incremental decoding is not used for ops.
     */
    static forOp(opts: {
        readonly idCompressor: IIdCompressor;
        readonly originatorId: SessionId;
    }): FieldBatchDecodingContext;
    /**
     * Construct a decode context for a summary blob.
     *
     * Summaries must contain only ids resolvable without an originator — either
     * finalized op-space ids, or (when {@link IdentifierHealingConfig} is supplied
     * via `healing`) non-final ids that get healed into deterministic UUIDv5
     * strings. Incremental decoding is attached via {@link withIncrementalDecoder}.
     *
     * @privateRemarks
     * In the future (if adding a summary format which includes the session id),
     * this could allow providing an originator ID to allow for op-space compressed identifiers in attach summaries.
     * Non-attach summaries should only have finalized compressed identifiers (due to only being made by summary clients which never allocate identifiers since they never edit).
     * Since only non-attach summaries can be incremental, incremental summaries should never have non finalized identifiers.
     * `withIncrementalDecoder` has logic to guard against cases which expect session-relative identifiers in incremental chunks,
     * as does the encoding-side assert in the {@link EncoderContext}.
     */
    static forSummary(opts: {
        readonly idCompressor: IIdCompressor;
        readonly healing?: IdentifierHealingConfig;
    }): FieldBatchDecodingContext;
    /**
     * Returns a copy of this context with `incrementalDecoder` swapped in. Used by
     * the forest summarizer to attach the per-call incremental builder to a base
     * decode context.
     */
    withIncrementalDecoder(incrementalDecoder: IncrementalDecoder): FieldBatchDecodingContext;
}
/**
 * @remarks
 * Fields in this batch currently don't have field schema for the root, which limits optimizations.
 */
export type FieldBatchCodec = VersionDispatchingCodec<FieldBatch, FieldBatchEncodingContext, FieldBatchFormatVersion, FieldBatchDecodingContext>;
/**
 * {@link VersionDispatchingCodecBuilder} for field batch codecs.
 */
export declare const fieldBatchCodecBuilder: VersionDispatchingCodecBuilder<import("../../../codec/codec.js").ICodecOptions, FieldBatch, FieldBatchEncodingContext, Brand<1, "FieldBatchFormatVersion"> | Brand<2, "FieldBatchFormatVersion">, "FieldBatch", FieldBatchDecodingContext>;
//# sourceMappingURL=codecs.d.ts.map