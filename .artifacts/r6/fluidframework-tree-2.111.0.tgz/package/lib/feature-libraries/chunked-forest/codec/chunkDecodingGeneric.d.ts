/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { DiscriminatedUnionDispatcher } from "../../../codec/index.js";
import type { TreeChunk } from "../../../core/index.js";
import type { BrandedType } from "../../../util/index.js";
import { type ChunkDecoder, type StreamCursor } from "./chunkCodecUtilities.js";
import type { IdDecodingContext } from "./chunkDecoding.js";
import type { IncrementalDecoder } from "./codecs.js";
import type { EncodedFieldBatchGeneric, IdentifierOrIndex } from "./format/index.js";
/**
 * General purpose shape based tree decoder which gets its support for specific shapes from the caller.
 */
export declare function decode<TEncodedShape extends object, TContext>(decoderLibrary: DiscriminatedUnionDispatcher<TEncodedShape, [
    context: TContext
], ChunkDecoder>, context: TContext, batch: EncodedFieldBatchGeneric<TEncodedShape>, rootDecoder: ChunkDecoder): TreeChunk[];
/**
 * Shared data for use in constructing decoders.
 */
export declare class DecoderContext<TEncodedShape = unknown> {
    /**
     * Identifier substitution table (use to replace numeric identifier indexes with the actual identifiers from this table).
     */
    readonly identifiers: readonly string[];
    readonly shapes: readonly TEncodedShape[];
    readonly idDecodingContext: IdDecodingContext;
    /**
     * To be used to decode incremental chunks, if any.
     * @remarks
     * See {@link IncrementalDecoder} for more information.
     */
    readonly incrementalDecoder: IncrementalDecoder | undefined;
    constructor(
    /**
     * Identifier substitution table (use to replace numeric identifier indexes with the actual identifiers from this table).
     */
    identifiers: readonly string[], shapes: readonly TEncodedShape[], idDecodingContext: IdDecodingContext, 
    /**
     * To be used to decode incremental chunks, if any.
     * @remarks
     * See {@link IncrementalDecoder} for more information.
     */
    incrementalDecoder: IncrementalDecoder | undefined);
    identifier<T extends string & BrandedType<string, string>>(encoded: IdentifierOrIndex): T;
}
/**
 * Read one identifier from the stream, advancing the stream offset.
 */
export declare function readStreamIdentifier<T extends string & BrandedType<string, string>>(stream: StreamCursor, context: DecoderContext): T;
//# sourceMappingURL=chunkDecodingGeneric.d.ts.map