/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { CursorLocationType, type FieldKey, type FieldUpPath, type PathRootPrefix, type TreeNodeSchemaIdentifier, type TreeType, type TreeValue, type UpPath, type Value, type ChunkedCursor, type TreeChunk, cursorChunk } from "../../core/index.js";
import { ReferenceCountedBase } from "../../util/index.js";
import { SynchronousCursor } from "../treeCursorUtils.js";
/**
 * General purpose one node chunk.
 */
export declare class BasicChunk extends ReferenceCountedBase implements TreeChunk {
    type: TreeNodeSchemaIdentifier;
    /**
     * Fields of this node.
     * @remarks
     * This object has exclusive deep ownership of this map (which might mutate it in the future).
     * Any code editing this map must update child reference counts.
     *
     * Like with {@link MapTree}, fields with no nodes must be removed from the map.
     */
    fields: Map<FieldKey, TreeChunk[]>;
    /**
     * The value on this node, if any.
     */
    value?: TreeValue | undefined;
    readonly topLevelLength: number;
    /**
     * Create a tree chunk with ref count 1.
     *
     * Caller must have already accounted for references via `fields` to the children in the fields map (via `referenceAdded`).
     */
    constructor(type: TreeNodeSchemaIdentifier, 
    /**
     * Fields of this node.
     * @remarks
     * This object has exclusive deep ownership of this map (which might mutate it in the future).
     * Any code editing this map must update child reference counts.
     *
     * Like with {@link MapTree}, fields with no nodes must be removed from the map.
     */
    fields: Map<FieldKey, TreeChunk[]>, 
    /**
     * The value on this node, if any.
     */
    value?: TreeValue | undefined);
    clone(): BasicChunk;
    cursor(): ChunkedCursor;
    protected onUnreferenced(): void;
}
export type SiblingsOrKey = readonly TreeChunk[] | readonly FieldKey[];
/**
 * Cursor over basic chunks.
 *
 * @remarks This implementation is similar to StackCursor, however it is distinct because:
 * 1. The children are chunks, which might have a top level length that's greater than 1.
 * 2. It needs to be able to delegate to cursors of other chunk formats it does not natively understand (See TODO below).
 *
 * TODO:
 * This cursor currently only handles child chunks which are BasicChunks:
 * BasicChunks should be an optimized fast path, and arbitrary chunk formats,
 * like UniformChunk, should be supported by delegating to their cursor implementations.
 */
export declare class BasicChunkCursor extends SynchronousCursor implements ChunkedCursor {
    protected root: readonly TreeChunk[];
    protected readonly siblingStack: SiblingsOrKey[];
    protected readonly indexStack: number[];
    protected readonly indexOfChunkStack: number[];
    protected readonly indexWithinChunkStack: number[];
    protected siblings: SiblingsOrKey;
    protected index: number;
    protected indexOfChunk: number;
    protected indexWithinChunk: number;
    protected nestedCursor: ChunkedCursor | undefined;
    /**
     * Starts at root field which might be a detached sequence.
     *
     * @param root - sequence of BasicChunk which make up the contents of the root sequence.
     * Since this cursor starts in `Fields` mode at the root, the siblings array when in fields mode is just the field keys,
     * this is needed to get the actual root nodes when entering nodes of the root field.
     * @param siblingStack - Stack of collections of siblings along the path through the tree:
     * does not include current level (which is stored in `siblings`).
     * Even levels in the stack (starting from 0) are keys and odd levels are sequences of nodes.
     * @param indexStack - Stack of indices into the corresponding levels in `siblingStack`.
     * @param indexOfChunkStack - Index of chunk in array of chunks. Only for Node levels.
     * @param indexWithinChunkStack - Index within chunk selected by indexOfChunkStack. Only for Node levels.
     * @param siblings - Siblings at the current level (not included in `siblingStack`).
     * @param index - Index into `siblings`.
     * @param indexOfChunk - Index of chunk in array of chunks. Only for Nodes mode.
     * @param indexWithinChunk - Index within chunk selected by indexOfChunkStack. Only for Nodes mode.
     * @param nestedCursor - When the outer cursor (this `BasicChunkCursor` cursor)
     * navigates into a chunk it does not natively understand (currently anything other than `BasicChunk`s)
     * it creates the `nestedCursor` over that chunk, and delegates all operations to it.
     */
    constructor(root: readonly TreeChunk[], siblingStack: SiblingsOrKey[], indexStack: number[], indexOfChunkStack: number[], indexWithinChunkStack: number[], siblings: SiblingsOrKey, index: number, indexOfChunk: number, indexWithinChunk: number, nestedCursor: ChunkedCursor | undefined);
    get [cursorChunk](): TreeChunk | undefined;
    atChunkRoot(): boolean;
    fork(): BasicChunkCursor;
    get mode(): CursorLocationType;
    /**
     * Asserts that the node-only stacks (`indexOfChunkStack` and `indexWithinChunkStack`) are in sync with `siblingStack`.
     * Since `siblingStack` interleaves field and node levels while the node-only stacks are pushed/popped only on node-level transitions,
     * their length should always equal the number of node levels traversed.
     */
    private assertChunkStacksMatchNodeDepth;
    getFieldKey(): FieldKey;
    private getStackedFieldKey;
    private getStackedNodeIndex;
    private getStackedChunkIndex;
    private getStackedChunk;
    /**
     * Converts a {@link height}, which contains field and node levels, into the corresponding depth/index
     * for the node-only stacks ({@link indexOfChunkStack} and {@link indexWithinChunkStack}), which are
     * only pushed on node-level transitions.
     *
     * @param height - A depth in {@link siblingStack} to convert. Defaults to {@link siblingStack}'s
     * current length, which gives the current depth of the node-only stacks.
     * @returns `floor(height / 2)` — the number of node levels at or below the given stack height.
     */
    private getNodeOnlyHeightFromHeight;
    getFieldLength(): number;
    enterNode(index: number): void;
    getPath(prefix?: PathRootPrefix): UpPath;
    private nestedPathPrefix;
    getFieldPath(prefix?: PathRootPrefix): FieldUpPath;
    private getOffsetPath;
    enterField(key: FieldKey): void;
    nextField(): boolean;
    firstField(): boolean;
    seekNodes(offset: number): boolean;
    firstNode(): boolean;
    nextNode(): boolean;
    private initNestedCursor;
    exitField(): void;
    exitNode(): void;
    private getNode;
    /**
     * Resolves the chunks that make up the field the cursor is currently in. At the root, this is
     * {@link root} directly. Otherwise, the cursor must be in {@link CursorLocationType.Fields} mode,
     * and the result is looked up on the parent node using the current field key.
     *
     * @returns The chunks that make up the field the cursor is currently in.
     */
    private getField;
    get value(): Value;
    get type(): TreeType;
    get fieldIndex(): number;
    /**
     * Within the field that `nestedCursor` is nested in:
     * returns the index within that field of the first node that is part of the chunk nestedCursor traverses.
     */
    private nestedOffset;
    get chunkStart(): number;
    get chunkLength(): number;
}
//# sourceMappingURL=basicChunk.d.ts.map