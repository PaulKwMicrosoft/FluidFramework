/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Listenable } from "@fluidframework/core-interfaces";
import type { IIdCompressor } from "@fluidframework/id-compressor";
import { type Anchor, AnchorSet, type AnnouncedVisitor, type DeltaVisitor, type DetachedField, type FieldAnchor, type FieldKey, type ForestEvents, type IEditableForest, type ITreeCursorSynchronous, type ITreeSubscriptionCursor, ITreeSubscriptionCursorState, TreeNavigationResult, type TreeStoredSchemaSubscription, type UpPath, type ChunkedCursor, type TreeChunk } from "../../core/index.js";
import { type Breakable } from "../../util/index.js";
import { BasicChunk, BasicChunkCursor, type SiblingsOrKey } from "./basicChunk.js";
import { type IChunker } from "./chunkTree.js";
/**
 * Implementation of IEditableForest based on copy on write chunks.
 *
 * This implementation focuses on performance.
 */
export declare class ChunkedForest implements IEditableForest {
    #private;
    roots: BasicChunk;
    readonly schema: TreeStoredSchemaSubscription;
    readonly chunker: IChunker;
    readonly anchors: AnchorSet;
    readonly idCompressor?: IIdCompressor | undefined;
    private activeVisitor?;
    private readonly deltaVisitors;
    readonly events: Listenable<ForestEvents>;
    /**
     * @param roots - dummy node above the root under which detached fields are stored. All content of the forest is reachable from this.
     * @param schema - schema which all content in this forest is assumed to comply with.
     * @param chunker - Chunking policy. TODO: dispose of this when forest is disposed.
     * @param anchors - anchorSet used to track location in this forest across changes. Callers of applyDelta must ensure this is updated accordingly.
     */
    constructor(roots: BasicChunk, schema: TreeStoredSchemaSubscription, chunker: IChunker, anchors?: AnchorSet, idCompressor?: IIdCompressor | undefined);
    get isEmpty(): boolean;
    clone(schema: TreeStoredSchemaSubscription, _breaker?: Breakable): ChunkedForest;
    chunkField(cursor: ITreeCursorSynchronous): TreeChunk[];
    forgetAnchor(anchor: Anchor): void;
    registerAnnouncedVisitor(visitor: () => AnnouncedVisitor): void;
    deregisterAnnouncedVisitor(visitor: () => AnnouncedVisitor): void;
    acquireVisitor(): DeltaVisitor;
    private nextDetachedFieldIdentifier;
    newDetachedField(): DetachedField;
    allocateCursor(): Cursor;
    tryMoveCursorToNode(destination: Anchor, cursorToMove: ITreeSubscriptionCursor): TreeNavigationResult;
    tryMoveCursorToField(destination: FieldAnchor, cursorToMove: ITreeSubscriptionCursor): TreeNavigationResult;
    moveCursorToPath(destination: UpPath, cursorToMove: ITreeSubscriptionCursor): void;
    getCursorAboveDetachedFields(): ITreeCursorSynchronous;
}
declare class Cursor extends BasicChunkCursor implements ITreeSubscriptionCursor {
    readonly forest: ChunkedForest;
    state: ITreeSubscriptionCursorState;
    constructor(forest: ChunkedForest, state: ITreeSubscriptionCursorState, root: readonly TreeChunk[], siblingStack: SiblingsOrKey[], indexStack: number[], indexOfChunkStack: number[], indexWithinChunkStack: number[], siblings: SiblingsOrKey, index: number, indexOfChunk: number, indexWithinChunk: number, nestedCursor: ChunkedCursor | undefined);
    setToDetachedSequence(key: FieldKey): void;
    fork(): Cursor;
    buildFieldAnchor(): FieldAnchor;
    free(): void;
    buildAnchor(): Anchor;
    clear(): void;
}
/**
 * Creates an implementation of {@link IEditableForest} with no data or schema.
 */
export declare function buildChunkedForest(chunker: IChunker, anchors?: AnchorSet, idCompressor?: IIdCompressor): ChunkedForest;
export {};
//# sourceMappingURL=chunkedForest.d.ts.map