/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChunkedCursor, type TreeChunk } from "../../core/index.js";
/**
 * Chunk that is empty.
 *
 * Since all emptiness is the same, this is a singleton.
 *
 * Useful for when a chunk or cursor is needed for an empty field or detached sequence.
 */
export declare const emptyChunk: TreeChunk;
/**
 * Cursor over an empty field.
 * Contains no nodes and is stateless.
 */
export declare const emptyCursor: ChunkedCursor;
//# sourceMappingURL=emptyChunk.d.ts.map