/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
/**
 * Format for encoding as json.
 *
 * For consistency all lists are sorted and undefined values are omitted.
 *
 * This chooses to use lists of named objects instead of maps:
 * this choice is somewhat arbitrary, but avoids user data being used as object keys,
 * which can sometimes be an issue (for example handling that for "__proto__" can require care).
 * It also makes it simpler to deterministically sort by keys.
 */
export declare const Format: Type.TObject<{
    version: Type.TLiteral<import("../../util/brand.js").Brand<2, "SchemaFormatVersion">>;
    nodes: Type.TRecord<Type.TString, Type.TObject<{
        kind: Type.TObject<{
            object: Type.TOptional<Type.TRecord<Type.TString, Type.TObject<{
                kind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
                types: Type.TArray<Type.TUnsafe<import("../../core/index.js").TreeNodeSchemaIdentifier<string>>>;
                metadata: Type.TOptional<Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnlyObject>>;
            }>>>;
            map: Type.TOptional<Type.TObject<{
                kind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
                types: Type.TArray<Type.TUnsafe<import("../../core/index.js").TreeNodeSchemaIdentifier<string>>>;
                metadata: Type.TOptional<Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnlyObject>>;
            }>>;
            leaf: Type.TOptional<Type.TEnum<typeof import("../../core/schema-stored/formatV1.js").PersistedValueSchema>>;
        }>;
        metadata: Type.TOptional<Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnlyObject>>;
    }>>;
    root: Type.TObject<{
        kind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<import("../../core/index.js").TreeNodeSchemaIdentifier<string>>>;
        metadata: Type.TOptional<Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnlyObject>>;
    }>;
}>;
export type Format = Static<typeof Format>;
//# sourceMappingURL=formatV2.d.ts.map