/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { schemaFormatV1 } from "../../core/index.js";
/**
 * Format for encoding as json.
 *
 * For consistency all lists are sorted and undefined values are omitted.
 *
 * This chooses to use lists of named objects instead of maps:
 * this choice is somewhat arbitrary, but avoids user data being used as object keys,
 * which can sometimes be an issue (for example handling that for "__proto__" can require care).
 * It also makes it simpler to determinately sort by keys.
 */
export declare const Format: Type.TObject<{
    version: Type.TLiteral<import("../../util/brand.js").Brand<1, "SchemaFormatVersion">>;
    nodes: Type.TRecord<Type.TString, Type.TObject<{
        object: Type.TOptional<Type.TRecord<Type.TString, Type.TObject<{
            kind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
            types: Type.TArray<Type.TUnsafe<schemaFormatV1.TreeNodeSchemaIdentifier<string>>>;
        }>>>;
        map: Type.TOptional<Type.TObject<{
            kind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
            types: Type.TArray<Type.TUnsafe<schemaFormatV1.TreeNodeSchemaIdentifier<string>>>;
        }>>;
        leaf: Type.TOptional<Type.TEnum<typeof schemaFormatV1.PersistedValueSchema>>;
    }>>;
    root: Type.TObject<{
        kind: Type.TUnsafe<schemaFormatV1.FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<schemaFormatV1.TreeNodeSchemaIdentifier<string>>>;
    }>;
}>;
export type Format = Static<typeof Format>;
//# sourceMappingURL=formatV1.d.ts.map