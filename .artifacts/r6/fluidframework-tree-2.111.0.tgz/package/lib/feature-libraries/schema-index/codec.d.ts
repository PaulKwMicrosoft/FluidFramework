/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { VersionDispatchingCodecBuilder } from "../../codec/index.js";
import { type TreeStoredSchema } from "../../core/index.js";
/**
 * Creates a codec which performs synchronous monolithic encoding of schema content.
 */
export declare const schemaCodecBuilder: VersionDispatchingCodecBuilder<import("../../codec/codec.js").ICodecOptions, TreeStoredSchema, void, import("../../util/brand.js").Brand<1, "SchemaFormatVersion"> | import("../../util/brand.js").Brand<2, "SchemaFormatVersion">, "Schema", void>;
//# sourceMappingURL=codec.d.ts.map