/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export declare const optionalIdentifier: import("../util/brand.js").BrandedType<string, "tree.FieldKindIdentifier"> & "Optional";
export declare const requiredIdentifier: import("../util/brand.js").BrandedType<string, "tree.FieldKindIdentifier"> & "Value";
export declare const sequenceIdentifier: import("../util/brand.js").BrandedType<string, "tree.FieldKindIdentifier"> & "Sequence";
export declare const identifierFieldIdentifier: import("../util/brand.js").BrandedType<string, "tree.FieldKindIdentifier"> & "Identifier";
//# sourceMappingURL=fieldKindIdentifiers.d.ts.map