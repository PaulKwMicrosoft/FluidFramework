/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type DetachedField, type ExclusiveMapTree, type FieldKey, type ITreeCursor, type NodeData } from "../core/index.js";
import { type CursorWithNode } from "./treeCursorUtils.js";
/**
 * A generic variant of {@link MapTree} that can be used to strongly type trees implementing a MapTree-like API.
 * @remarks
 * Due to how TypeScript handles recursive generic types, explicitly named extension interfaces work best for parameterizing this, and a default type parameter can't be provided.
 * @see {@link MinimalMapTreeNodeView} for a minimal configuration of this interface.
 */
export interface MapTreeNodeViewGeneric<TNode> extends NodeData {
    /**
     * The non-empty fields on this node.
     * @remarks
     * This is the subset of map needed to view the tree.
     * Theoretically `Symbol.iterator` and "keys" are redundant.
     */
    readonly fields: MinimalFieldMap<MapTreeFieldViewGeneric<TNode>>;
}
/**
 * A minimal map for the fields of a {@link MapTreeNodeViewGeneric}.
 * @remarks
 * Subset of map, so can be implemented by `Map<FieldKey, TField>`.
 */
export interface MinimalFieldMap<TField> {
    [Symbol.iterator]: () => Iterator<[FieldKey, TField]>;
    get: (key: FieldKey) => TField | undefined;
}
/**
 * A field in {@link MapTreeNodeViewGeneric}.
 * @remarks
 * Subset of array, so can be implemented by `TNode[]`.
 */
export interface MapTreeFieldViewGeneric<TNode> {
    readonly [Symbol.iterator]: () => Iterator<TNode>;
    readonly length: number;
}
/**
 * Like {@link MapTree} but with the minimal properties needed for reading.
 */
export interface MinimalMapTreeNodeView extends MapTreeNodeViewGeneric<MinimalMapTreeNodeView> {
}
/**
 * Returns an {@link ITreeCursorSynchronous} in nodes mode for a single {@link MapTree}.
 */
export declare function cursorForMapTreeNode<T extends MapTreeNodeViewGeneric<T>>(root: T): CursorWithNode<T>;
/**
 * Creates an {@link ExclusiveMapTree} with a single field and no value.
 * @remarks
 * This handles ensuring the field is omitted if empty, and defaults to making the node above the root.
 */
export declare function mapTreeWithField(children: ExclusiveMapTree[], key?: FieldKey, type?: import("../core/index.js").TreeNodeSchemaIdentifier): ExclusiveMapTree;
/**
 * Creates a Map suitable for use as {@link MapTree.fields} with a single field.
 * @remarks
 * This handles ensuring the field is omitted if empty.
 */
export declare function mapTreeFieldsWithField<T extends readonly unknown[]>(children: T, key: FieldKey): Map<FieldKey, T>;
/**
 * Returns an {@link ITreeCursorSynchronous} in fields mode for a MapTree field.
 */
export declare function cursorForMapTreeField<T extends MapTreeNodeViewGeneric<T>>(root: readonly T[], detachedField?: DetachedField): CursorWithNode<T>;
/**
 * Extract a MapTree from the contents of the given ITreeCursor's current node.
 */
export declare function mapTreeFromCursor(cursor: ITreeCursor): ExclusiveMapTree;
/**
 * Extract an array of MapTrees (a field) from the contents of the given ITreeCursor's current field.
 */
export declare function mapTreeFieldFromCursor(cursor: ITreeCursor): ExclusiveMapTree[];
//# sourceMappingURL=mapTreeCursor.d.ts.map