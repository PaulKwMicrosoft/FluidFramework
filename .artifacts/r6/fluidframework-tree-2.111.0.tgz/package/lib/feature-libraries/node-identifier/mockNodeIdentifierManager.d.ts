/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { StableId } from "@fluidframework/id-compressor";
import type { LocalNodeIdentifier, StableNodeIdentifier } from "./nodeIdentifier.js";
import { type NodeIdentifierManager } from "./nodeIdentifierManager.js";
/**
 * Mock {@link NodeIdentifierManager} that generates deterministic {@link StableNodeIdentifier}s and {@link LocalNodeIdentifier}s.
 * @remarks This is useful for test environments because it will always yield the same keys in the same order.
 * It should not be used for production environments for the same reason; the {@link StableNodeIdentifier}s are not universally unique.
 */
export declare class MockNodeIdentifierManager implements NodeIdentifierManager {
    private count;
    generateStableNodeIdentifier(): StableNodeIdentifier;
    generateLocalNodeIdentifier(): LocalNodeIdentifier;
    localizeNodeIdentifier(key: StableNodeIdentifier): LocalNodeIdentifier;
    stabilizeNodeIdentifier(key: LocalNodeIdentifier): StableNodeIdentifier;
    tryLocalizeNodeIdentifier(key: string): LocalNodeIdentifier | undefined;
    getId(offset: number): StableId;
}
//# sourceMappingURL=mockNodeIdentifierManager.d.ts.map