/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type DeltaDetachedNodeId, type DeltaFieldMap, type DeltaMark, type DeltaRoot } from "../core/index.js";
export declare function nodeIdFromChangeAtom(changeAtom: ChangeAtomId): DeltaDetachedNodeId;
export declare function changeAtomIdFromNodeId(nodeId: DeltaDetachedNodeId): ChangeAtomId;
/**
 * Converts a `Delta.Root` whose tree content is represented with by `TIn` instances
 * into a `Delta.Root`whose tree content is represented with by `TOut` instances.
 *
 * This function is useful for converting `Delta`s that represent tree content with cursors
 * into `Delta`s that represent tree content with a deep-comparable representation of the content.
 * See {@link assertDeltaEqual}.
 * @param root - The delta to convert. Not mutated.
 * @param func - The functions used to map tree content.
 */
export declare function mapRootChanges<TIn, TOut>(root: DeltaRoot<TIn>, func: (tree: TIn) => TOut): DeltaRoot<TOut>;
export declare function createDeltaMark(count: number, fields: DeltaFieldMap | undefined, detach: DeltaDetachedNodeId | undefined, attach: DeltaDetachedNodeId | undefined): DeltaMark;
//# sourceMappingURL=deltaUtils.d.ts.map