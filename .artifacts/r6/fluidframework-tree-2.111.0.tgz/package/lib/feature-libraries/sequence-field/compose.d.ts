/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type RevisionMetadataSource } from "../../core/index.js";
import type { IdAllocator } from "../../util/index.js";
import type { ComposeNodeManager, NodeChangeComposer } from "../modular-schema/index.js";
import type { Changeset, Mark } from "./types.js";
/**
 * Composes a sequence of changesets into a single changeset.
 * @param changes - The changesets to be applied.
 * Parts of the input may be reused in the output, but the input is not mutated.
 * Each changeset in the list is assumed to be applicable after the previous one.
 * @returns A changeset that is equivalent to applying each of the given `changes` in order.
 *
 * WARNING! This implementation is incomplete:
 * - Tombstone information is ignored.
 * - Support for moves is not implemented.
 * - Support for slices is not implemented.
 */
export declare function compose(change1: Changeset, change2: Changeset, composeChild: NodeChangeComposer, _genId: IdAllocator, manager: ComposeNodeManager, revisionMetadata: RevisionMetadataSource): Changeset;
export declare class ComposeQueue {
    private readonly moveEffects;
    private readonly revisionMetadata;
    private readonly baseMarks;
    private readonly newMarks;
    private readonly baseMarksCellSources;
    private readonly newMarksCellSources;
    constructor(baseMarks: Changeset, newMarks: Changeset, moveEffects: ComposeNodeManager, revisionMetadata: RevisionMetadataSource);
    isEmpty(): boolean;
    pop(): ComposeMarks;
    private dequeueBase;
    private dequeueNew;
    private dequeueBoth;
    private peekMinLength;
}
interface ComposeMarks {
    baseMark: Mark;
    newMark: Mark;
}
export {};
//# sourceMappingURL=compose.d.ts.map