/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { RevisionTag } from "../../core/index.js";
import type { IdAllocator } from "../../util/index.js";
import type { InvertNodeManager } from "../modular-schema/index.js";
import { type Changeset } from "./types.js";
/**
 * Inverts a given changeset.
 * @param change - The changeset to produce the inverse of.
 * @param isRollback - Whether the inverse is being produced for a rollback.
 * @param genId - The ID allocator to use for generating new IDs.
 * @param revision - The revision to use for the inverse changeset.
 * @param crossFieldManager - The cross-field manager to use for tracking cross-field changes.
 * @returns The inverse of the given `change` such that the inverse can be applied after `change`.
 *
 * WARNING! This implementation is incomplete:
 * - Support for slices is not implemented.
 */
export declare function invert(change: Changeset, isRollback: boolean, genId: IdAllocator, revision: RevisionTag | undefined, crossFieldManager: InvertNodeManager): Changeset;
//# sourceMappingURL=invert.d.ts.map