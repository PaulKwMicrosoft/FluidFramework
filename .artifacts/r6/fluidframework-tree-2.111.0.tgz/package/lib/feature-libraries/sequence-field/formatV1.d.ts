/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static, TSchema } from "@sinclair/typebox";
export declare enum DetachIdOverrideType {
    /**
     * The detach effect is the inverse of the prior attach characterized by the accompanying `CellId`'s revision and
     * local ID.
     *
     * An override is needed in such a case to ensure that rollbacks and undos return tree content to the appropriate
     * detached root. It is also needed to ensure that cell comparisons work properly for undos.
     */
    Unattach = 0,
    /**
     * The detach effect is reapplying a prior detach.
     *
     * The accompanying cell ID is used in two ways:
     * - It indicates the location of the cell (including adjacent cell information) so that rebasing over this detach
     * can contribute the correct lineage information to the rebased mark.
     * - It specifies the revision and local ID that should be used to characterize the cell in the output context of
     * detach.
     */
    Redetach = 1
}
declare const CellCount: Type.TNumber;
declare const MoveId: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
declare const LineageEvent: Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>;
declare const IdRange: Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>;
declare const CellId: Type.TObject<{
    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
}>;
declare const Insert: Type.TObject<{
    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
}>;
declare const MoveIn: Type.TObject<{
    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
}>;
declare const Remove: Type.TObject<{
    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    idOverride: Type.TOptional<Type.TObject<{
        type: Type.TEnum<typeof DetachIdOverrideType>;
        id: Type.TObject<{
            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
        }>;
    }>>;
}>;
declare const MoveOut: Type.TObject<{
    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    idOverride: Type.TOptional<Type.TObject<{
        type: Type.TEnum<typeof DetachIdOverrideType>;
        id: Type.TObject<{
            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
        }>;
    }>>;
}>;
declare const Attach: Type.TObject<{
    insert: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    }>>;
    moveIn: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    }>>;
}>;
declare const Detach: Type.TObject<{
    delete: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        idOverride: Type.TOptional<Type.TObject<{
            type: Type.TEnum<typeof DetachIdOverrideType>;
            id: Type.TObject<{
                lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
            }>;
        }>>;
    }>>;
    moveOut: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        idOverride: Type.TOptional<Type.TObject<{
            type: Type.TEnum<typeof DetachIdOverrideType>;
            id: Type.TObject<{
                lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
            }>;
        }>>;
    }>>;
}>;
declare const AttachAndDetach: Type.TObject<{
    attach: Type.TObject<{
        insert: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        }>>;
        moveIn: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
    }>;
    detach: Type.TObject<{
        delete: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
        moveOut: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
    }>;
}>;
declare const MarkEffect: Type.TObject<{
    insert: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    }>>;
    moveIn: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    }>>;
    delete: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        idOverride: Type.TOptional<Type.TObject<{
            type: Type.TEnum<typeof DetachIdOverrideType>;
            id: Type.TObject<{
                lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
            }>;
        }>>;
    }>>;
    moveOut: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        idOverride: Type.TOptional<Type.TObject<{
            type: Type.TEnum<typeof DetachIdOverrideType>;
            id: Type.TObject<{
                lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
            }>;
        }>>;
    }>>;
    attachAndDetach: Type.TOptional<Type.TObject<{
        attach: Type.TObject<{
            insert: Type.TOptional<Type.TObject<{
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            }>>;
            moveIn: Type.TOptional<Type.TObject<{
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            }>>;
        }>;
        detach: Type.TObject<{
            delete: Type.TOptional<Type.TObject<{
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                idOverride: Type.TOptional<Type.TObject<{
                    type: Type.TEnum<typeof DetachIdOverrideType>;
                    id: Type.TObject<{
                        lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                        atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                        adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                    }>;
                }>>;
            }>>;
            moveOut: Type.TOptional<Type.TObject<{
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                idOverride: Type.TOptional<Type.TObject<{
                    type: Type.TEnum<typeof DetachIdOverrideType>;
                    id: Type.TObject<{
                        lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                        atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                        adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                    }>;
                }>>;
            }>>;
        }>;
    }>>;
}>;
declare const CellMark: <TMark extends Type.TSchema, TNodeChange extends Type.TSchema>(tMark: TMark, tNodeChange: TNodeChange) => Type.TObject<{
    effect: TMark extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<TMark>>;
    cellId: Type.TOptional<Type.TObject<{
        lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
        atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
    }>>;
    changes: TNodeChange extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<TNodeChange>>;
    count: Type.TNumber;
}>;
declare const Mark: <Schema extends Type.TSchema>(tNodeChange: Schema) => Type.TObject<{
    effect: Type.TOptional<Type.TObject<{
        insert: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        }>>;
        moveIn: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        delete: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
        moveOut: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
        attachAndDetach: Type.TOptional<Type.TObject<{
            attach: Type.TObject<{
                insert: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                }>>;
                moveIn: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
            detach: Type.TObject<{
                delete: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    idOverride: Type.TOptional<Type.TObject<{
                        type: Type.TEnum<typeof DetachIdOverrideType>;
                        id: Type.TObject<{
                            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                        }>;
                    }>>;
                }>>;
                moveOut: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                    idOverride: Type.TOptional<Type.TObject<{
                        type: Type.TEnum<typeof DetachIdOverrideType>;
                        id: Type.TObject<{
                            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                        }>;
                    }>>;
                }>>;
            }>;
        }>>;
    }>>;
    cellId: Type.TOptional<Type.TObject<{
        lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
        atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
    }>>;
    changes: Schema extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<Schema>>;
    count: Type.TNumber;
}>;
export declare const Changeset: <Schema extends Type.TSchema>(tNodeChange: Schema) => Type.TArray<Type.TObject<{
    effect: Type.TOptional<Type.TObject<{
        insert: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        }>>;
        moveIn: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        delete: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
        moveOut: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            idOverride: Type.TOptional<Type.TObject<{
                type: Type.TEnum<typeof DetachIdOverrideType>;
                id: Type.TObject<{
                    lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                    atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                    adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                }>;
            }>>;
        }>>;
        attachAndDetach: Type.TOptional<Type.TObject<{
            attach: Type.TObject<{
                insert: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                }>>;
                moveIn: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
            detach: Type.TObject<{
                delete: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    idOverride: Type.TOptional<Type.TObject<{
                        type: Type.TEnum<typeof DetachIdOverrideType>;
                        id: Type.TObject<{
                            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                        }>;
                    }>>;
                }>>;
                moveOut: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                    idOverride: Type.TOptional<Type.TObject<{
                        type: Type.TEnum<typeof DetachIdOverrideType>;
                        id: Type.TObject<{
                            lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
                            atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
                            adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
                        }>;
                    }>>;
                }>>;
            }>;
        }>>;
    }>>;
    cellId: Type.TOptional<Type.TObject<{
        lineage: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber, Type.TNumber]>>>;
        atom: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        adjacentCells: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>>;
    }>>;
    changes: Schema extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<Schema>>;
    count: Type.TNumber;
}>>;
/**
 * @privateRemarks Many of these names are currently used in the sequence-field types. Putting them in a namespace makes codec code more readable.
 */
export declare namespace Encoded {
    type CellCount = Static<typeof CellCount>;
    type MoveId = Static<typeof MoveId>;
    type LineageEvent = Static<typeof LineageEvent>;
    type IdRange = Static<typeof IdRange>;
    type CellId = Static<typeof CellId>;
    type Insert = Static<typeof Insert>;
    type MoveIn = Static<typeof MoveIn>;
    type Remove = Static<typeof Remove>;
    type MoveOut = Static<typeof MoveOut>;
    type Attach = Static<typeof Attach>;
    type Detach = Static<typeof Detach>;
    type AttachAndDetach = Static<typeof AttachAndDetach>;
    type MarkEffect = Static<typeof MarkEffect>;
    type CellMark<Schema extends TSchema, TNodeChange extends TSchema> = Static<ReturnType<typeof CellMark<Schema, TNodeChange>>>;
    type Mark<Schema extends TSchema> = Static<ReturnType<typeof Mark<Schema>>>;
    type Changeset<Schema extends TSchema> = Static<ReturnType<typeof Changeset<Schema>>>;
}
export {};
//# sourceMappingURL=formatV1.d.ts.map