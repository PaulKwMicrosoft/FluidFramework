/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static, TSchema } from "@sinclair/typebox";
import { type Encoded as EncodedV2 } from "./formatV2.js";
declare const Rename: Type.TObject<{
    idOverride: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
}>;
declare const MarkEffect: Type.TObject<{
    remove: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    }>>;
    insert: Type.TOptional<Type.TObject<{
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    }>>;
    moveIn: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    }>>;
    moveOut: Type.TOptional<Type.TObject<{
        revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
        finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    }>>;
    attachAndDetach: Type.TOptional<Type.TObject<{
        attach: Type.TObject<{
            insert: Type.TOptional<Type.TObject<{
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            }>>;
            moveIn: Type.TOptional<Type.TObject<{
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            }>>;
        }>;
        detach: Type.TObject<{
            remove: Type.TOptional<Type.TObject<{
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            }>>;
            moveOut: Type.TOptional<Type.TObject<{
                revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            }>>;
        }>;
    }>>;
    rename: Type.TOptional<Type.TObject<{
        idOverride: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    }>>;
}>;
declare const Mark: <Schema extends Type.TSchema>(tNodeChange: Schema) => Type.TObject<{
    effect: Type.TOptional<Type.TObject<{
        remove: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        insert: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        }>>;
        moveIn: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        moveOut: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        attachAndDetach: Type.TOptional<Type.TObject<{
            attach: Type.TObject<{
                insert: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                }>>;
                moveIn: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
            detach: Type.TObject<{
                remove: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
                moveOut: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                    idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
        }>>;
        rename: Type.TOptional<Type.TObject<{
            idOverride: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        }>>;
    }>>;
    cellId: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    changes: Schema extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<Schema>>;
    count: Type.TNumber;
}>;
export declare const Changeset: <Schema extends Type.TSchema>(tNodeChange: Schema) => Type.TArray<Type.TObject<{
    effect: Type.TOptional<Type.TObject<{
        remove: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        insert: Type.TOptional<Type.TObject<{
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        }>>;
        moveIn: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        moveOut: Type.TOptional<Type.TObject<{
            revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
            id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
            finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
            idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
        }>>;
        attachAndDetach: Type.TOptional<Type.TObject<{
            attach: Type.TObject<{
                insert: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                }>>;
                moveIn: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
            detach: Type.TObject<{
                remove: Type.TOptional<Type.TObject<{
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
                moveOut: Type.TOptional<Type.TObject<{
                    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
                    id: Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>;
                    finalEndpoint: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                    idOverride: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
                }>>;
            }>;
        }>>;
        rename: Type.TOptional<Type.TObject<{
            idOverride: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        }>>;
    }>>;
    cellId: Type.TOptional<Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>>;
    changes: Schema extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<Schema>>;
    count: Type.TNumber;
}>>;
/**
 * @privateRemarks Many of these names are currently used in the sequence-field types. Putting them in a namespace makes codec code more readable.
 */
export declare namespace Encoded {
    type CellCount = EncodedV2.CellCount;
    type MoveId = EncodedV2.MoveId;
    type IdRange = EncodedV2.IdRange;
    type CellId = EncodedV2.CellId;
    type Insert = EncodedV2.Insert;
    type MoveIn = EncodedV2.MoveIn;
    type Remove = EncodedV2.Remove;
    type MoveOut = EncodedV2.MoveOut;
    type Attach = EncodedV2.Attach;
    type Detach = EncodedV2.Detach;
    type AttachAndDetach = EncodedV2.AttachAndDetach;
    type CellMark<Schema extends TSchema, TNodeChange extends TSchema> = EncodedV2.CellMark<Schema, TNodeChange>;
    type Rename = Static<typeof Rename>;
    type MarkEffect = Static<typeof MarkEffect>;
    type Mark<Schema extends TSchema> = Static<ReturnType<typeof Mark<Schema>>>;
    type Changeset<Schema extends TSchema> = Static<ReturnType<typeof Changeset<Schema>>>;
}
export {};
//# sourceMappingURL=formatV3.d.ts.map