/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Mark, MarkList } from "./types.js";
/**
 * Helper class for constructing an offset list of marks that...
 * - Does not insert offsets if there is no content after them
 * - Does not insert 0-sized offsets
 * - Merges runs of offsets together
 * - Merges marks together
 */
export declare class MarkListFactory {
    private offset;
    readonly list: MarkList;
    constructor();
    push(...marks: Mark[]): void;
    pushOffset(offset: number): void;
    pushContent(mark: Mark): void;
}
//# sourceMappingURL=markListFactory.d.ts.map