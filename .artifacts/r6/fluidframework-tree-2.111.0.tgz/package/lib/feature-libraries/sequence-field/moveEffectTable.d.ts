/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { MoveMarkEffect } from "./helperTypes.js";
import type { Attach, CellMark, Mark, MarkEffect } from "./types.js";
export type MoveMark = CellMark<MoveMarkEffect>;
export declare function isMoveMark(effect: MarkEffect): effect is MoveMarkEffect;
export declare function getAttach(effect: MarkEffect): Attach | undefined;
export type NodeRangeQueryFunc = (mark: Mark) => number;
export declare function splitMarkForMoveEffects(mark: Mark, getLength: NodeRangeQueryFunc): Mark[];
//# sourceMappingURL=moveEffectTable.d.ts.map