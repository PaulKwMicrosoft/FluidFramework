/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TreeView, TreeViewAlpha, TreeViewBeta, ImplicitAllowedTypes, ImplicitFieldSchema, TreeViewConfiguration, TreeViewConfigurationAlpha, TreeArrayNode, TreeArrayNodeAlpha, TreeMapNode, TreeMapNodeAlpha } from "./simple-tree/index.js";
/**
 * Module entry points for retrieving alternate (alpha/beta) versions of tree APIs.
 * For each API (usually a class) that has an alpha/beta version, add overloads to the function(s) below.
 * These functions should only be used by external consumers, not referenced internally within the tree package, to avoid circular import dependencies.
 */
/**
 * Retrieve the {@link TreeViewAlpha | alpha API} for a {@link TreeView}.
 * @alpha
 */
export declare function asAlpha<TSchema extends ImplicitFieldSchema>(view: TreeView<TSchema>): TreeViewAlpha<TSchema>;
/**
 * Retrieve the {@link TreeViewConfigurationAlpha | alpha API} for a {@link TreeViewConfiguration}.
 * @alpha
 */
export declare function asAlpha<TSchema extends ImplicitFieldSchema>(view: TreeViewConfiguration<TSchema>): TreeViewConfigurationAlpha<TSchema>;
/**
 * Retrieve the {@link TreeArrayNodeAlpha | alpha API} for a {@link (TreeArrayNode:interface)}.
 * @alpha
 */
export declare function asAlpha<TAllowedTypes extends ImplicitAllowedTypes>(node: TreeArrayNode<TAllowedTypes>): TreeArrayNodeAlpha<TAllowedTypes>;
/**
 * Retrieve the {@link TreeMapNodeAlpha | alpha API} for a {@link TreeMapNode}.
 * @alpha
 */
export declare function asAlpha<TAllowedTypes extends ImplicitAllowedTypes>(node: TreeMapNode<TAllowedTypes>): TreeMapNodeAlpha<TAllowedTypes>;
/**
 * Retrieve the {@link TreeViewBeta | beta API} for a {@link TreeView}.
 * @beta
 */
export declare function asBeta<TSchema extends ImplicitFieldSchema>(view: TreeView<TSchema>): TreeViewBeta<TSchema>;
//# sourceMappingURL=api.d.ts.map