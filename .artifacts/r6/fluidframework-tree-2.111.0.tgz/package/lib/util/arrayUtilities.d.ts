/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Validates that the provided index is a safe integer.
 * @throws If the index is invalid.
 * @param index - The index to validate.
 * @param apiName - The name of the API performing the validation.
 * @throws If the index is invalid.
 */
export declare function validateSafeInteger(index: number, apiName: string): void;
/**
 * Validates that the provided index is a 0 or greater safe integer.
 * @param index - The index to validate.
 * @param apiName - The name of the API performing the validation.
 * @throws If the index is invalid.
 */
export declare function validatePositiveIndex(index: number, apiName: string): void;
/**
 * Validates that the provided index is a non-negative safe integer within the bounds of the provided array (or, optionally, 1 past its end).
 * @throws If the index is invalid.
 * @param index - The index to validate.
 * @param array - The array to validate against.
 * @param apiName - The name of the API performing the validation.
 * @param allowOnePastEnd - Whether to allow the index to be one past the end of the array.
 */
export declare function validateIndex(index: number, array: {
    readonly length: number;
}, apiName: string, allowOnePastEnd?: boolean): void;
/**
 * Validates that the provided range `[startIndex, endIndex)` is valid and within the bounds of the provided array.
 * @remarks
 * This is intended for ranges which are inclusive for the lower bound, and exclusive for the upper bound,
 * and permits 0 length ranges, even `[array.length, array.length)`.
 * @throws If the index is invalid.
 * @param startIndex - The index that starts the range (inclusive).
 * @param endIndex - The index that ends the range (exclusive).
 * @param array - The array to validate against.
 * @param apiName - The name of the API performing the validation.
 */
export declare function validateIndexRange(startIndex: number, endIndex: number, array: {
    readonly length: number;
}, apiName: string): void;
/**
 * A half-open `[start, end)` range of array indices.
 */
export interface IndexRange {
    /** Start index, inclusive. */
    readonly start: number;
    /** End index, exclusive. */
    readonly end: number;
}
/**
 * Walks `array` in order and collects the indices of every element for which `predicate` returns
 * `true` into contiguous `[start, end)` ranges.
 * @param array - The array (or array-like) to scan.
 * @param shouldInclude - Returns `true` for elements whose indices should be included.
 * @returns The collected ranges in ascending order. The returned array is empty if no elements match.
 */
export declare function collectContiguousRanges<T>(array: {
    readonly length: number;
    readonly [index: number]: T;
}, shouldInclude: (item: T) => boolean): readonly IndexRange[];
//# sourceMappingURL=arrayUtilities.d.ts.map