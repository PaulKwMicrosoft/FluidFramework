/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export type OffsetList<TContent = Exclude<unknown, number>, TOffset = number> = (TOffset | TContent)[];
/**
 * Helper class for constructing an offset list that...
 *
 * - Does not insert offsets if there is no content after them
 *
 * - Does not insert 0-sized offsets
 *
 * - Merges runs of offsets together
 */
export declare class OffsetListFactory<TContent> {
    private offset;
    readonly list: OffsetList<TContent>;
    push(...offsetOrContent: (number | TContent)[]): void;
    pushOffset(offset: number): void;
    pushContent(content: TContent): void;
}
//# sourceMappingURL=offsetList.d.ts.map