/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type NestedMap } from "./nestedMap.js";
export type NestedSet<Key1, Key2> = NestedMap<Key1, Key2, boolean>;
export declare function addToNestedSet<Key1, Key2>(set: NestedSet<Key1, Key2>, key1: Key1, key2: Key2): void;
export declare function nestedSetContains<Key1, Key2>(set: NestedSet<Key1, Key2>, key1: Key1, key2: Key2): boolean;
//# sourceMappingURL=nestedSet.d.ts.map