/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor, OpSpaceCompressedId, SessionId, SessionSpaceCompressedId } from "@fluidframework/id-compressor";
/**
 * An encoded identifier that can be decoded without an originator session id.
 * A finalized compressed id — the same numeric value in op-space and session-space.
 * @remarks
 * These are safe to use in contexts where the encoding id compressor is available to decode them,
 * even when the session id of the encoding id compressor is not known.
 */
export type OriginatorlessEncodedId = SessionSpaceCompressedId & OpSpaceCompressedId;
/**
 * An encoded identifier that may require an originator session id to decode.
 * Any op-space compressed id, either finalized or session-local.
 * @remarks
 * These are only safe to use in contexts where the encoding id compressor is available
 * and the session id of the encoding id compressor is known.
 * Currently the only such case is in ops, excluding attach summary ops.
 */
export type OriginatorDependentEncodedId = OpSpaceCompressedId;
/**
 * Selects how identifiers are encoded for transport/persistence.
 */
export declare enum EncodedIdType {
    /**
     * {@link OriginatorlessEncodedId}.
     */
    Originatorless = 0,
    /**
     * {@link OriginatorDependentEncodedId}.
     */
    OriginatorDependent = 1
}
export type EncodedId<T extends EncodedIdType> = T extends EncodedIdType.Originatorless ? OriginatorlessEncodedId : T extends EncodedIdType.OriginatorDependent ? OriginatorDependentEncodedId : OriginatorlessEncodedId | OriginatorDependentEncodedId;
/**
 * Context for encoding identifiers.
 * @remarks
 * See {@link FieldBatchDecodingContext} for the decoder.
 */
export interface IdEncodingContext {
    encodePossiblyCompressedId(id: string): string | EncodedId<EncodedIdType>;
}
/**
 * Encode a string identifier into a possibly compressed form based on the requested mode.
 *
 * @param id - The string identifier to encode.
 * @param idCompressor - The ID compressor to use for compression.
 * @param encodedIdType - The type of encoding to use. If the context doing the decoding will have the originator {@link SessionId},
 * then {@link EncodedIdType.OriginatorDependent} can be used.
 * Otherwise, {@link EncodedIdType.Originatorless} must be used.
 *
 * @privateRemarks
 * Performance:
 * When trying to optimize to avoid unnecessary identifier decompression, and store identifiers compressed in memory,
 * this will likely need to be updated to allow in SessionSpaceCompressedIds.
 */
export declare function encodePossiblyCompressedId<T extends EncodedIdType>(id: string, idCompressor: IIdCompressor, encodedIdType: T): string | EncodedId<T>;
/**
 * Decode an {@link OriginatorlessEncodedId} without needing an originator session id.
 *
 * The id is guaranteed to be final by the type contract; it is normalized via
 * {@link IIdCompressor.tryNormalizeToSessionSpaceWithoutSession}, which handles the
 * cluster-aligned-local case rather than relying on the bare numeric value.
 */
export declare function decodeOriginatorlessEncodedId(id: OriginatorlessEncodedId, idCompressor: IIdCompressor): SessionSpaceCompressedId;
/**
 * Decode an {@link OriginatorDependentEncodedId} using a known originator session id.
 */
export declare function decodeEncodedIdWithOriginator(id: OriginatorDependentEncodedId, originator: SessionId, idCompressor: IIdCompressor): SessionSpaceCompressedId;
/**
 * Decode an {@link OriginatorDependentEncodedId} without a session.
 *
 * Returns the session-space id if `id` is finalized (and therefore resolvable
 * without an originator session), or `undefined` if `id` is a non-final op-space
 * id that cannot be resolved without the originator session.
 */
export declare function tryDecodeEncodedIdWithoutSession(id: OriginatorDependentEncodedId, idCompressor: IIdCompressor): SessionSpaceCompressedId | undefined;
/**
 * Configuration for the heal-on-decode workaround. The internal counterpart of
 * the user-facing {@link SharedTreeOptionsBeta.healUnresolvableIdentifiersOnDecode}
 * option — see that option for the user-facing rationale and trade-offs.
 *
 * Carried by decode-side contexts (`ChangeEncodingContext.healing`,
 * `EditManagerEncodingContext.healing`, etc.) when the workaround is enabled.
 * Presence enables healing; `undefined` opts out. There is no separate boolean,
 * which makes it impossible to enable healing without supplying the namespace
 * input.
 */
export interface IdentifierHealingConfig {
    /**
     * The SharedTree's shared-object id, used as the v5 namespace input so
     * healed UUIDs are unique across attaches of different documents with the
     * same session offsets.
     */
    readonly sharedObjectId: string;
}
/**
 * Decode an op-space compressed id without a session.
 *
 * Finalized ids are returned as session-space ids (final ids are invariant
 * across the two spaces). Non-final ids are healed via {@link IdentifierHealingConfig}
 * if provided, or cause the resolver to throw otherwise. A healed result is a
 * deterministic v5 UUID string — *not* a `StableId`, since that brand requires
 * v4, but still a valid identifier value; the `string` arm of the return type
 * covers this case.
 */
export declare function forceDecodeEncodedIdWithoutSession(id: OpSpaceCompressedId, idCompressor: IIdCompressor, healing: IdentifierHealingConfig | undefined): SessionSpaceCompressedId | string;
/**
 * Convert a decoded, but possibly compressed, identifier to the decompressed string format.
 *
 * Session-space compressed ids are decompressed to their UUID representation via the compressor.
 * String inputs pass through unchanged — they are already in the stored form,
 * whether a `StableId` UUID, a heal-synthesized v5 UUID or other arbitrary string identifier.
 */
export declare function decompressIdentifierIfNeeded(id: SessionSpaceCompressedId | string, idCompressor: Pick<IIdCompressor, "decompress">): string;
//# sourceMappingURL=compressedIds.d.ts.map