/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import * as Type from "@sinclair/typebox";
import { type EncodedRevisionTag } from "../core/index.js";
import type { JsonCompatibleReadOnly } from "../util/index.js";
import type { EncodedBranchId } from "./branch.js";
import { MessageFormatVersion } from "./messageFormat.js";
/**
 * The format of messages that SharedTree sends and receives.
 */
export interface Message {
    /**
     * The revision tag for the change in this message
     */
    readonly revision?: EncodedRevisionTag;
    /**
     * The stable ID that identifies the originator of the message.
     */
    readonly originatorId: SessionId;
    /**
     * The changeset to be applied.
     */
    readonly changeset?: JsonCompatibleReadOnly;
    readonly branchId?: EncodedBranchId;
    /**
     * The version of the message format.
     */
    readonly version: typeof MessageFormatVersion.vSharedBranches;
}
export declare const Message: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    revision: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    originatorId: Type.TUnsafe<SessionId>;
    changeset: ChangeSchema extends Type.TOptional<infer S extends Type.TSchema> ? Type.TOptional<S> : Type.Ensure<Type.TOptional<ChangeSchema>>;
    branchId: Type.TOptional<Type.TNumber>;
    version: Type.TLiteral<import("../util/brand.js").Brand<"shared-branches|v0.1", "MessageFormatVersion">>;
}>;
//# sourceMappingURL=messageFormatVSharedBranches.d.ts.map