/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { GraphCommit } from "../core/index.js";
import type { ChangeEnricher } from "./changeEnricher.js";
/**
 * Utility for enriching commits from a {@link Branch} before these commits are applied and submitted.
 */
export declare class BranchCommitEnricher<TChange> {
    private readonly enricher;
    /**
     * Maps each local commit to the corresponding enriched change.
     * @remarks
     * Entries are added when the commits are {@link BranchCommitEnricher.prepareChanges | prepared}.
     * Each entry is removed when it is {@link BranchCommitEnricher.retrieveChange | retrieved}.
     * In the event that an entry is not explicitly removed, it will eventually be {@link WeakMap | dropped from memory} along with the associated commit.
     */
    private readonly prepared;
    constructor(enricher: ChangeEnricher<TChange>);
    /**
     * Process the given commits for later {@link BranchCommitEnricher.retrieveChange | retrieval}.
     * @param commits - The commits to prepare.
     */
    prepareChanges(commits: readonly GraphCommit<TChange>[]): void;
    /**
     * Retrieves the enriched change for the given commit.
     * @param commit - A commit that was already {@link BranchCommitEnricher.prepareChanges | prepared}.
     * @remarks A commit can only be enriched once - subsequent calls to this method with the same commit will throw an error.
     * @returns The enriched change corresponding to the given `commit`.
     */
    retrieveChange(commit: GraphCommit<TChange>): TChange;
}
//# sourceMappingURL=branchCommitEnricher.d.ts.map