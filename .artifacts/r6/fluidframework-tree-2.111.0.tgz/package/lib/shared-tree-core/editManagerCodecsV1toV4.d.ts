/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { CodecAndSchema, IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, EncodedRevisionTag, RevisionTag, SchemaAndPolicy } from "../core/index.js";
import { type IdentifierHealingConfig, type JsonCompatibleReadOnly } from "../util/index.js";
import type { SummaryData } from "./editManager.js";
import { EncodedEditManager } from "./editManagerFormatV1toV4.js";
export interface EditManagerEncodingContext {
    idCompressor: IIdCompressor;
    readonly schema?: SchemaAndPolicy;
    readonly isSummary: boolean;
    /** See {@link IdentifierHealingConfig}. */
    readonly healing?: IdentifierHealingConfig;
}
/**
 * Create the provided version of the {@link EditManager} codec (which encodes it's {@link SummaryData}).
 * @remarks
 * The changeCodec and revisionTagCodec are not explicitly versioned, so the exact right version of them must be provided here
 * or data will be incompatible.
 *
 * TODO: this file should be renamed as this is used for v6 as well.
 */
export declare function makeV1toV4andV6CodecWithVersion<TChangeset>(changeCodec: IJsonCodec<TChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, ChangeEncodingContext>, revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>, version: EncodedEditManager<TChangeset>["version"]): CodecAndSchema<SummaryData<TChangeset>, EditManagerEncodingContext>;
//# sourceMappingURL=editManagerCodecsV1toV4.d.ts.map