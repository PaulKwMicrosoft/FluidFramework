/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import { type TelemetryLoggerExt } from "@fluidframework/telemetry-utils/internal";
import type { ExternalAuthorityAdvance, ExternalAuthorityOutcome, ExternalAuthorityState } from "./externalAuthority.js";
import { type ChangeFamily, type ChangeFamilyEditor, type GraphCommit, type RevisionTag } from "../core/index.js";
import { SharedTreeBranch, type BranchId } from "./branch.js";
import type { SeqNumber, SequencedCommit, SummarySessionBranch } from "./editManagerFormatCommons.js";
export declare const minimumPossibleSequenceNumber: SeqNumber;
/**
 * Represents a local branch of a document and interprets the effect on the document of adding sequenced changes,
 * which were based on a given session's branch, to the document history
 */
export declare class EditManager<TEditor extends ChangeFamilyEditor, TChangeset, TChangeFamily extends ChangeFamily<TEditor, TChangeset>> {
    readonly changeFamily: TChangeFamily;
    readonly localSessionId: SessionId;
    private readonly mintRevisionTag;
    private readonly onSharedBranchCreated?;
    private readonly externalAuthority;
    private readonly _events;
    private readonly sharedBranches;
    /**
     * Tracks where on the trunk of the main branch all registered branches are based.
     * Each key is the sequence id of a commit on the trunk,
     * and the value is the set of all branches who have that commit as their common ancestor with the trunk.
     *
     * @remarks
     * This does not include the local branch.
     */
    private readonly trunkBranches;
    /**
     * The sequence number of the newest commit on the trunk that has been received by all peers.
     * Defaults to {@link minimumPossibleSequenceNumber} if no commits have been received.
     *
     * @remarks If there are more than one commit with the same sequence number we assume this refers to the last commit in the batch.
     */
    private minimumSequenceNumber;
    /**
     * A special commit that is a "base" (tail) of the trunk, though not part of the trunk itself.
     * This makes it possible to model the trunk in the same way as any other branch (it branches off of a base commit)
     * which allows it to use branching APIs to interact with the other branches.
     * Each time trunk eviction occurs, the most recent evicted commit becomes the new `trunkBase`.
     */
    private trunkBase;
    private readonly telemetryEventBatcher;
    /**
     * @param changeFamily - the change family of changes on the trunk and local branch
     * @param localSessionId - the id of the local session that will be used for local commits
     * @param mintRevisionTag - a function which generates globally unique revision tags
     * @param onSharedBranchCreated - called when a new shared branch is created. This is not called for the main branch.
     */
    constructor(changeFamily: TChangeFamily, localSessionId: SessionId, mintRevisionTag: () => RevisionTag, onSharedBranchCreated?: ((branchId: BranchId) => void) | undefined, logger?: TelemetryLoggerExt, externalAuthority?: boolean);
    getLocalBranch(branchId: BranchId): SharedTreeBranch<TEditor, TChangeset>;
    private getSharedBranch;
    /**
     * Make the given branch known to the `EditManager`. The `EditManager` will ensure that all registered
     * branches remain usable even as the minimum sequence number advances.
     *
     * TODO#AB6926: Refactor local branch management into a separate class that encapsulates `trunkBranches` and everything
     * that touches it.
     * TODO#AB6925: Maintain the divergence point between each branch and the trunk so that we don't have to recompute
     * it so often.
     */
    private registerBranch;
    private trackBranch;
    private untrackBranch;
    /**
     * Return the sequenced number of the latest sequenced change.
     */
    getLatestSequenceNumber(): SeqNumber | undefined;
    /**
     * Advances the minimum sequence number, and removes all commits from the trunk which lie outside the collaboration window,
     * if they are not retained by revertibles or local branches.
     * @param minimumSequenceNumber - the sequence number of the newest commit that all peers (including this one) have received and applied to their trunks.
     *
     * @remarks If there are more than one commit with the same sequence number we assume this refers to the last commit in the batch.
     */
    advanceMinimumSequenceNumber(minimumSequenceNumber: SeqNumber, trimHistory?: boolean): void;
    /**
     * Examines the latest known minimum sequence number and the trunk bases of any registered branches to determine
     * if any commits on the trunk are unreferenced and unneeded for future computation; those found are evicted from the trunk.
     */
    private trimHistory;
    isEmpty(): boolean;
    getSummaryData(): SummaryData<TChangeset>;
    loadSummaryData(data: SummaryData<TChangeset>): void;
    getTrunkHead(branchId: BranchId): GraphCommit<TChangeset>;
    getTrunkChanges(branchId: BranchId): TChangeset[];
    getTrunkCommits(branchId: BranchId): GraphCommit<TChangeset>[];
    getLocalCommits(branchId: BranchId): readonly GraphCommit<TChangeset>[];
    /**
     * Gets the length of the longest branch maintained by this `EditManager`.
     * This may be the length of a peer branch or the local branch.
     *
     * @remarks
     * The length is counted from the lowest common ancestor with the trunk such that a fully sequenced branch would
     * have length zero.
     */
    getLongestBranchLength(): number;
    sequenceBranchCreation(sessionId: SessionId, referenceSequenceNumber: SeqNumber, branchId: BranchId): void;
    addNewBranch(branchId: BranchId): void;
    getSharedBranchIds(): BranchId[];
    removeBranch(branchId: BranchId): void;
    private createAndAddSharedBranch;
    private addSharedBranch;
    private createSharedBranch;
    /**
     * Add a bunch of sequenced changes. A bunch is a group of sequenced commits that have the following properties:
     * - They are not interleaved with messages from other DDSes in the container.
     * - They are all part of the same batch, which entails:
     *   - They are contiguous in sequencing order.
     *   - They are all from the same client.
     *   - They are all based on the same reference sequence number.
     *   - They are not interleaved with messages from other clients.
     */
    addSequencedChanges(newCommits: readonly GraphCommit<TChangeset>[], sessionId: SessionId, sequenceNumber: SeqNumber, referenceSequenceNumber: SeqNumber, branchId: BranchId): void;
    findLocalCommit(branchId: BranchId, revision: RevisionTag): [commit: GraphCommit<TChangeset>, commitsAfter: GraphCommit<TChangeset>[]];
    getExternalAuthorityState(): ExternalAuthorityState<TChangeset>;
    advanceExternalAuthority(advance: ExternalAuthorityAdvance<TChangeset>, sequenceNumber: SeqNumber, fingerprint: string): ExternalAuthorityOutcome;
}
/**
 * The in-memory data that summaries contain
 */
export interface SummaryData<TChangeset> {
    readonly originator?: SessionId;
    readonly main: SharedBranchSummaryData<TChangeset>;
    readonly branches?: ReadonlyMap<BranchId, SharedBranchSummaryData<TChangeset>>;
}
export interface SharedBranchSummaryData<TChangeset> {
    readonly id?: BranchId;
    readonly name?: string;
    readonly session?: SessionId;
    readonly author?: string;
    readonly base?: RevisionTag;
    readonly trunk: readonly SequencedCommit<TChangeset>[];
    readonly peerLocalBranches: ReadonlyMap<SessionId, SummarySessionBranch<TChangeset>>;
}
//# sourceMappingURL=editManager.d.ts.map