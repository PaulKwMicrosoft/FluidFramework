/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { CodecAndSchema, IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, EncodedRevisionTag, RevisionTag, SchemaAndPolicy } from "../core/index.js";
import { type IdentifierHealingConfig, type JsonCompatibleReadOnly } from "../util/index.js";
import type { SummaryData } from "./editManager.js";
import { EncodedEditManager } from "./editManagerFormatVSharedBranches.js";
export interface EditManagerEncodingContext {
    idCompressor: IIdCompressor;
    readonly schema?: SchemaAndPolicy;
    readonly isSummary: boolean;
    /** See {@link IdentifierHealingConfig}. */
    readonly healing?: IdentifierHealingConfig;
}
export declare function makeSharedBranchesCodecWithVersion<TChangeset>(changeCodec: IJsonCodec<TChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, ChangeEncodingContext>, revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>, version: EncodedEditManager<TChangeset>["version"]): CodecAndSchema<SummaryData<TChangeset>, EditManagerEncodingContext>;
//# sourceMappingURL=editManagerCodecsVSharedBranches.d.ts.map