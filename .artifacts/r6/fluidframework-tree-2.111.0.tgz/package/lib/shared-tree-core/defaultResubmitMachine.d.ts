/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { GraphCommit, RevisionTag } from "../core/index.js";
import type { ChangeEnricher } from "./changeEnricher.js";
import type { ResubmitMachine } from "./resubmitMachine.js";
/**
 * Default implementation of {@link ResubmitMachine}.
 */
export declare class DefaultResubmitMachine<TChange> implements ResubmitMachine<TChange> {
    /**
     * Change enricher that represent the tip of the top-level local branch (i.e., the branch on which in-flight
     * commits are applied and automatically rebased).
     */
    private readonly enricher;
    /**
     * Maps from revision of submitted commit to the pending change for that commit.
     */
    private readonly pendingChanges;
    /**
     * The current enrichment version for in-flight commits.
     * Incremented when a peer commit is sequenced.
     */
    private currentEnrichment;
    constructor(
    /**
     * Change enricher that represent the tip of the top-level local branch (i.e., the branch on which in-flight
     * commits are applied and automatically rebased).
     */
    enricher: ChangeEnricher<TChange>);
    onCommitSubmitted(commit: GraphCommit<TChange>): void;
    onCommitRollback(commit: GraphCommit<TChange>): void;
    private updateEnrichments;
    getEnrichedCommit(revision: RevisionTag, getLocalCommitsSince: () => readonly GraphCommit<TChange>[]): GraphCommit<TChange> | undefined;
    private getPendingChange;
    onSequencedCommitApplied(revision: RevisionTag, isLocal: boolean): void;
}
//# sourceMappingURL=defaultResubmitMachine.d.ts.map