/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { MinimumVersionForCollab } from "@fluidframework/runtime-definitions/internal";
import { VersionDispatchingCodecBuilder, type CodecTree, type DependentFormatVersion, type ICodecFamily, type ICodecOptions, type IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, EncodedRevisionTag, RevisionTag, SchemaAndPolicy } from "../core/index.js";
import type { IdentifierHealingConfig } from "../util/index.js";
import type { SummaryData } from "./editManager.js";
import { EditManagerFormatVersion } from "./editManagerFormatCommons.js";
/**
 * Context required for encoding/decoding the {@link EditManager}'s {@link SummaryData}.
 */
export interface EditManagerEncodingContext {
    idCompressor: IIdCompressor;
    readonly schema?: SchemaAndPolicy;
    readonly isSummary: boolean;
    /** See {@link IdentifierHealingConfig}. */
    readonly healing?: IdentifierHealingConfig;
}
/**
 * Codec name used to identify the {@link EditManager} codec, see {@link makeEditManagerCodecBuilder}.
 */
export declare const editManagerCodecName = "EditManager";
/**
 * Options for constructing an {@link EditManager} codec, see {@link makeEditManagerCodecBuilder}.
 */
interface EditManagerCodecOptions<TChangeset> extends ICodecOptions {
    /** Codecs for encoding changesets. */
    changeCodecs: ICodecFamily<TChangeset, ChangeEncodingContext>;
    /** Maps each EditManager format version to the corresponding changeset format version. */
    dependentChangeFormatVersion: DependentFormatVersion<EditManagerFormatVersion>;
    /** Codec for encoding revision tags within changesets. */
    revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>;
}
/**
 * Creates a {@link VersionDispatchingCodecBuilder} encoding for {@link SummaryData}.
 */
export declare function makeEditManagerCodecBuilder<TChangeset>(): VersionDispatchingCodecBuilder<EditManagerCodecOptions<TChangeset>, SummaryData<TChangeset>, EditManagerEncodingContext, EditManagerFormatVersion, typeof editManagerCodecName>;
/**
 * Returns a {@link CodecTree} for the EditManager format at the given client version,
 * with the provided change codec tree as a child.
 */
export declare function getCodecTreeForEditManagerFormatWithChange(clientVersion: MinimumVersionForCollab, changeFormat: CodecTree): CodecTree;
export {};
//# sourceMappingURL=editManagerCodecs.d.ts.map