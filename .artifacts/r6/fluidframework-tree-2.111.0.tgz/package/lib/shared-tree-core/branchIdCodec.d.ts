/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor, OpSpaceCompressedId, SessionId } from "@fluidframework/id-compressor";
import type { BranchId } from "./branch.js";
export declare function encodeBranchId(idCompressor: IIdCompressor, branchId: BranchId): OpSpaceCompressedId | undefined;
export declare function decodeBranchId(idCompressor: IIdCompressor, encoded: OpSpaceCompressedId | undefined, context: {
    readonly originatorId: SessionId;
}): BranchId;
//# sourceMappingURL=branchIdCodec.d.ts.map