/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IChannelStorageService } from "@fluidframework/datastore-definitions/internal";
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { IExperimentalIncrementalSummaryContext, ITelemetryContext, MinimumVersionForCollab } from "@fluidframework/runtime-definitions/internal";
import type { SummaryTreeBuilder } from "@fluidframework/runtime-utils/internal";
import type { IJsonCodec } from "../codec/index.js";
import type { ChangeFamily, ChangeFamilyEditor, SchemaAndPolicy } from "../core/index.js";
import type { IdentifierHealingConfig, JsonCompatibleReadOnly } from "../util/index.js";
import type { EditManager, SummaryData } from "./editManager.js";
import type { EditManagerEncodingContext } from "./editManagerCodecs.js";
import type { Summarizable, SummaryElementParser, SummaryElementStringifier } from "./summaryTypes.js";
import { VersionedSummarizer } from "./versionedSummarizer.js";
export declare const stringKey = "String";
/**
 * The versions for the edit manager summary format.
 */
export declare const enum EditManagerSummaryFormatVersion {
    /**
     * This version represents summary format before summary versioning was introduced.
     */
    v1 = 1,
    /**
     * This version adds metadata to the summary. This is backward compatible with version 1.
     */
    v2 = 2,
    /**
     * The latest version of the summary. Must be updated when a new version is added.
     */
    vLatest = 2
}
/**
 * Provides methods for summarizing and loading an `EditManager`
 */
export declare class EditManagerSummarizer<TChangeset> extends VersionedSummarizer<EditManagerSummaryFormatVersion> implements Summarizable {
    private readonly editManager;
    private readonly codec;
    private readonly idCompressor;
    private readonly schemaAndPolicy?;
    /** See {@link IdentifierHealingConfig}. */
    private readonly healing?;
    static readonly key = "EditManager";
    constructor(editManager: EditManager<ChangeFamilyEditor, TChangeset, ChangeFamily<ChangeFamilyEditor, TChangeset>>, codec: IJsonCodec<SummaryData<TChangeset>, JsonCompatibleReadOnly, JsonCompatibleReadOnly, EditManagerEncodingContext>, idCompressor: IIdCompressor, minVersionForCollab: MinimumVersionForCollab, schemaAndPolicy?: SchemaAndPolicy | undefined, 
    /** See {@link IdentifierHealingConfig}. */
    healing?: IdentifierHealingConfig | undefined);
    protected summarizeInternal(props: {
        stringify: SummaryElementStringifier;
        fullTree?: boolean;
        trackState?: boolean;
        telemetryContext?: ITelemetryContext;
        incrementalSummaryContext?: IExperimentalIncrementalSummaryContext;
        builder: SummaryTreeBuilder;
    }): void;
    protected loadInternal(services: IChannelStorageService, parse: SummaryElementParser): Promise<void>;
}
//# sourceMappingURL=editManagerSummarizer.d.ts.map