/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor, SessionId } from "@fluidframework/id-compressor";
import type { IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, EncodedRevisionTag, RevisionTag, SchemaAndPolicy } from "../core/index.js";
import { type IdentifierHealingConfig, type JsonCompatibleReadOnly } from "../util/index.js";
import type { SharedBranchSummaryData } from "./editManager.js";
import type { EncodedSharedBranch } from "./editManagerFormatCommons.js";
export interface EditManagerEncodingContext {
    idCompressor: IIdCompressor;
    readonly schema?: SchemaAndPolicy;
    /**
     * See {@link ChangeEncodingContext.isSummary}. EditManager codec callers
     * always set this to `true` (the codec is only invoked for summaries),
     * but it is carried explicitly so downstream codecs can read it.
     */
    readonly isSummary: boolean;
    /** See {@link IdentifierHealingConfig}. */
    readonly healing?: IdentifierHealingConfig;
}
export declare function encodeSharedBranch<TChangeset>(changeCodec: IJsonCodec<TChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, ChangeEncodingContext>, revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>, data: SharedBranchSummaryData<TChangeset>, context: EditManagerEncodingContext, originatorId: SessionId | undefined): EncodedSharedBranch<TChangeset>;
export declare function decodeSharedBranch<TChangeset>(changeCodec: IJsonCodec<TChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, ChangeEncodingContext>, revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>, json: EncodedSharedBranch<TChangeset>, context: EditManagerEncodingContext, originatorId: SessionId | undefined): SharedBranchSummaryData<TChangeset>;
//# sourceMappingURL=editManagerCodecsCommons.d.ts.map