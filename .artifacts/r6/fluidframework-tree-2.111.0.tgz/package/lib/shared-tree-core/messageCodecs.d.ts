/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { MinimumVersionForCollab } from "@fluidframework/runtime-definitions/internal";
import { VersionDispatchingCodecBuilder, type CodecTree, type DependentFormatVersion, type ICodecFamily, type ICodecOptions, type IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, EncodedRevisionTag, RevisionTag, SchemaAndPolicy } from "../core/index.js";
import { MessageFormatVersion } from "./messageFormat.js";
import type { DecodedMessage } from "./messageTypes.js";
export interface MessageEncodingContext {
    idCompressor: IIdCompressor;
    schema?: SchemaAndPolicy;
}
/**
 * Codec name used to identify the message codec, see {@link makeMessageCodecBuilder}.
 */
export declare const messageCodecName = "Message";
/**
 * Options for constructing a message codec, see {@link makeMessageCodecBuilder}.
 */
interface MessageCodecBuilderOptions<TChangeset> extends ICodecOptions {
    /** Codecs for encoding changesets. */
    changeCodecs: ICodecFamily<TChangeset, ChangeEncodingContext>;
    /** Maps each MessageFormatVersion to the corresponding changeset format version. */
    dependentChangeFormatVersion: DependentFormatVersion<MessageFormatVersion>;
    /** Codec for encoding revision tags within changesets. */
    revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>;
}
/**
 * Creates a {@link VersionDispatchingCodecBuilder} for encoding/decoding messages.
 */
export declare function makeMessageCodecBuilder<TChangeset>(): VersionDispatchingCodecBuilder<MessageCodecBuilderOptions<TChangeset>, DecodedMessage<TChangeset>, MessageEncodingContext, MessageFormatVersion | undefined, typeof messageCodecName>;
export declare function getCodecTreeForMessageFormatWithChange(clientVersion: MinimumVersionForCollab, changeFormat: CodecTree): CodecTree;
export {};
//# sourceMappingURL=messageCodecs.d.ts.map