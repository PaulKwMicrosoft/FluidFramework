/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { CodecAndSchema, IJsonCodec } from "../codec/index.js";
import type { ChangeEncodingContext, ChangeFamilyCodec, EncodedRevisionTag, RevisionTag } from "../core/index.js";
import type { MessageEncodingContext } from "./messageCodecs.js";
import type { MessageFormatVersion } from "./messageFormat.js";
import type { DecodedMessage } from "./messageTypes.js";
export declare function makeSharedBranchesCodecWithVersion<TChangeset>(changeCodec: ChangeFamilyCodec<TChangeset>, revisionTagCodec: IJsonCodec<RevisionTag, EncodedRevisionTag, EncodedRevisionTag, ChangeEncodingContext>, version: typeof MessageFormatVersion.vSharedBranches): CodecAndSchema<DecodedMessage<TChangeset>, MessageEncodingContext>;
//# sourceMappingURL=messageCodecVSharedBranches.d.ts.map