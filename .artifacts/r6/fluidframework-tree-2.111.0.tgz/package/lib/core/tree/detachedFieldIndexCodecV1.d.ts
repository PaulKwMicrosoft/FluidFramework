/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import type { CodecAndSchema } from "../../codec/index.js";
import { type RevisionTagCodec } from "../rebase/index.js";
import type { DetachedFieldSummaryData } from "./detachedFieldIndexTypes.js";
export declare function makeDetachedNodeToFieldCodecV1(revisionTagCodec: RevisionTagCodec, idCompressor: IIdCompressor): CodecAndSchema<DetachedFieldSummaryData>;
//# sourceMappingURL=detachedFieldIndexCodecV1.d.ts.map