/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Static } from "@sinclair/typebox";
import { DetachedFieldIndexFormatVersion } from "./detachedFieldIndexFormatCommon.js";
export declare const FormatV1: import("@sinclair/typebox").TObject<{
    version: import("@sinclair/typebox").TLiteral<DetachedFieldIndexFormatVersion>;
    data: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TTuple<[import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"root">, import("@sinclair/typebox").TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, import("@sinclair/typebox").TArray<import("@sinclair/typebox").TTuple<[import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>>]>, import("@sinclair/typebox").TTuple<[import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"root">, import("@sinclair/typebox").TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>]>>;
    maxId: import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>;
}>;
export type FormatV1 = Static<typeof FormatV1>;
//# sourceMappingURL=detachedFieldIndexFormatV1.d.ts.map