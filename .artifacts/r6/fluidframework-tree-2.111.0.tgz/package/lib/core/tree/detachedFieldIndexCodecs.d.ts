/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import { VersionDispatchingCodecBuilder, type ICodecOptions } from "../../codec/index.js";
import type { RevisionTagCodec } from "../rebase/index.js";
export declare const detachedFieldIndexCodecBuilder: VersionDispatchingCodecBuilder<ICodecOptions & {
    readonly revisionTagCodec: RevisionTagCodec;
    readonly idCompressor: IIdCompressor;
}, import("./detachedFieldIndexTypes.js").DetachedFieldSummaryData, void, import("../../util/brand.js").Brand<1, "DetachedFieldIndexFormatVersion"> | import("../../util/brand.js").Brand<2, "DetachedFieldIndexFormatVersion">, "DetachedFieldIndex", void>;
//# sourceMappingURL=detachedFieldIndexCodecs.d.ts.map