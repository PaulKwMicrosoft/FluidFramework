/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { type Values } from "../../util/index.js";
import type { ForestRootId } from "./detachedFieldIndexTypes.js";
/**
 * The format version for the detached field index.
 */
export declare const DetachedFieldIndexFormatVersion: {
    readonly v1: import("../../util/brand.js").Brand<1, "DetachedFieldIndexFormatVersion">;
    readonly v2: import("../../util/brand.js").Brand<2, "DetachedFieldIndexFormatVersion">;
};
export type DetachedFieldIndexFormatVersion = Values<typeof DetachedFieldIndexFormatVersion>;
/**
 * The ID of a detached node. Is not globally unique on.
 * A `RevisionTag` + `DetachId` pair is globally unique and eventually consistent across clients.
 */
export declare const DetachId: Type.TNumber;
/**
 * The ID of a root node in the forest associated with the owning checkout. Is unique for that forest.
 * Is not consistent across clients.
 */
export declare const ForestRootIdSchema: Type.TUnsafe<ForestRootId>;
/**
 * A mapping from a range of the detached node IDs the corresponding range root IDs.
 * The detached node IDs need to be qualified with a revision (stored in the containing `EncodedRootsForRevision`).
 * Note: the length of the range (currently always 1) can be looked up in the forest.
 */
export declare const RootRange: Type.TTuple<[Type.TNumber, Type.TUnsafe<ForestRootId>]>;
export type RootRange = Static<typeof RootRange>;
export declare const RootRanges: Type.TArray<Type.TTuple<[Type.TNumber, Type.TUnsafe<ForestRootId>]>>;
export type RootRanges = Static<typeof RootRanges>;
/**
 * For all the roots detached in a revision, represents a mapping from the detached node ID to corresponding root ID.
 */
export declare const EncodedRootsForRevision: <Schema extends Type.TSchema>(tRevisionTag: Schema) => Type.TUnion<[Type.TTuple<[Schema, Type.TArray<Type.TTuple<[Type.TNumber, Type.TUnsafe<ForestRootId>]>>]>, Type.TTuple<[Schema, Type.TNumber, Type.TUnsafe<ForestRootId>]>]>;
export type EncodedRootsForRevision = Static<ReturnType<typeof EncodedRootsForRevision>>;
export declare const Format: <TVersion extends DetachedFieldIndexFormatVersion, TRevisionTagSchema extends Type.TSchema>(tVersion: TVersion, tRevisionTag: TRevisionTagSchema) => Type.TObject<{
    version: Type.TLiteral<TVersion>;
    data: Type.TArray<Type.TUnion<[Type.TTuple<[TRevisionTagSchema, Type.TArray<Type.TTuple<[Type.TNumber, Type.TUnsafe<ForestRootId>]>>]>, Type.TTuple<[TRevisionTagSchema, Type.TNumber, Type.TUnsafe<ForestRootId>]>]>>;
    maxId: Type.TUnsafe<ForestRootId>;
}>;
export type Format = Static<ReturnType<typeof Format>>;
//# sourceMappingURL=detachedFieldIndexFormatCommon.d.ts.map