/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TreeChunk } from "./chunk.js";
import type { DetachedNodeId, FieldChanges, FieldMap, Root } from "./delta.js";
export declare const emptyDelta: Root;
export declare function deltaForRootInitialization(content: TreeChunk): Root;
export declare function makeDetachedNodeId(major: DetachedNodeId["major"], minor: DetachedNodeId["minor"]): DetachedNodeId;
export declare function offsetDetachId(id: DetachedNodeId, offset: number): DetachedNodeId;
export declare function offsetDetachId(id: DetachedNodeId | undefined, offset: number): DetachedNodeId | undefined;
export declare function areDetachedNodeIdsEqual(a: DetachedNodeId, b: DetachedNodeId): boolean;
/**
 * Returns true if a delta field map contains any changes that would be visible in the document (i.e., a detach or an attach)
 * @param fields - Delta FieldMap to check for visible changes
 * @returns True if change map contains any changes that would be visible in the document, false otherwise
 */
export declare function deltaFieldMapHasVisibleChanges(fields: FieldMap | undefined): boolean;
/**
 * Returns true if the given field changes contains any changes that would be visible in the document (i.e., a detach or an attach)
 * @param fieldChanges - Field changes to check for visible changes
 * @returns True if the field changes contain any changes that would be visible in the document, false otherwise
 */
export declare function deltaFieldChangesHaveVisibleChanges(fieldChanges: FieldChanges): boolean;
//# sourceMappingURL=deltaUtil.d.ts.map