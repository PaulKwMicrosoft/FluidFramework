/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Static, TSchema } from "@sinclair/typebox";
import type { IJsonCodec } from "../../codec/index.js";
import { type DetachedFieldIndexFormatVersion } from "./detachedFieldIndexFormatCommon.js";
import type { DetachedFieldSummaryData, Major } from "./detachedFieldIndexTypes.js";
export declare function makeDetachedFieldIndexCodecFromMajorCodec<TEncodedRevisionTag, TEncodedRevisionTagSchema extends TSchema, TVersion extends DetachedFieldIndexFormatVersion>(majorCodec: IJsonCodec<Major, TEncodedRevisionTag>, version: TVersion, encodedRevisionTagSchema: TEncodedRevisionTagSchema): {
    schema: import("@sinclair/typebox").TObject<{
        version: import("@sinclair/typebox").TLiteral<TVersion>;
        data: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TTuple<[TEncodedRevisionTagSchema, import("@sinclair/typebox").TArray<import("@sinclair/typebox").TTuple<[import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>>]>, import("@sinclair/typebox").TTuple<[TEncodedRevisionTagSchema, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>]>>;
        maxId: import("@sinclair/typebox").TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>;
    }>;
    encode: (data: DetachedFieldSummaryData) => {
        data: ([Static<TEncodedRevisionTagSchema, unknown[] & []>, [number, import("./detachedFieldIndexTypes.js").ForestRootId][]] | [Static<TEncodedRevisionTagSchema, unknown[] & []>, number, import("./detachedFieldIndexTypes.js").ForestRootId])[];
        version: TVersion;
        maxId: import("./detachedFieldIndexTypes.js").ForestRootId;
    };
    decode: (parsed: {
        data: ([Static<TEncodedRevisionTagSchema, unknown[] & []>, [number, import("./detachedFieldIndexTypes.js").ForestRootId][]] | [Static<TEncodedRevisionTagSchema, unknown[] & []>, number, import("./detachedFieldIndexTypes.js").ForestRootId])[];
        version: TVersion;
        maxId: import("./detachedFieldIndexTypes.js").ForestRootId;
    }) => DetachedFieldSummaryData;
};
//# sourceMappingURL=detachedFieldIndexCodecCommon.d.ts.map