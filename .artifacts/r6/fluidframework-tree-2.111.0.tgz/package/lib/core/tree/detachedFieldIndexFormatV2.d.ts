/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { DetachedFieldIndexFormatVersion } from "./detachedFieldIndexFormatCommon.js";
export declare const StableOrFinalRevisionTag: Type.TUnion<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TString]>;
export declare const FormatV2: Type.TObject<{
    version: Type.TLiteral<DetachedFieldIndexFormatVersion>;
    data: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TUnion<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TString]>, Type.TArray<Type.TTuple<[Type.TNumber, Type.TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>>]>, Type.TTuple<[Type.TUnion<[Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>, Type.TString]>, Type.TNumber, Type.TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>]>]>>;
    maxId: Type.TUnsafe<import("./detachedFieldIndexTypes.js").ForestRootId>;
}>;
export type FormatV2 = Static<typeof FormatV2>;
//# sourceMappingURL=detachedFieldIndexFormatV2.d.ts.map