/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IIdCompressor } from "@fluidframework/id-compressor";
import { type CodecWriteOptions } from "../../codec/index.js";
import { type IdAllocator, type JsonCompatibleReadOnly } from "../../util/index.js";
import type { RevisionTag, RevisionTagCodec } from "../rebase/index.js";
import type { FieldKey } from "../schema-stored/index.js";
import type * as Delta from "./delta.js";
import type { ForestRootId } from "./detachedFieldIndexTypes.js";
/**
 * Readonly interface for {@link DetachedFieldIndex}.
 */
export interface ReadOnlyDetachedFieldIndex {
    /**
     * Creates a deep clone of this `DetachedFieldIndex`.
     */
    clone(): DetachedFieldIndex;
    /**
     * Returns a field key for the given ID.
     * This does not save the field key on the index. To do so, call {@link createEntry}.
     */
    toFieldKey(id: ForestRootId): FieldKey;
    /**
     * Returns the `ForestRootId` associated with the given id.
     * Returns undefined if no such id is known to the index.
     */
    tryGetEntry(id: Delta.DetachedNodeId): ForestRootId | undefined;
    /**
     * Returns the `ForestRootId` associated with the given id.
     * Fails if no such id is known to the index.
     */
    getEntry(id: Delta.DetachedNodeId): ForestRootId;
}
/**
 * Restores the originating DetachedFieldIndex to the state it was in when the checkpoint was created.
 * Can be invoked multiple times.
 */
export type DetachedFieldIndexCheckpoint = () => void;
/**
 * The tree index records detached field IDs and associates them with a change atom ID.
 */
export declare class DetachedFieldIndex implements ReadOnlyDetachedFieldIndex {
    private readonly name;
    private rootIdAllocator;
    private readonly revisionTagCodec;
    private readonly idCompressor;
    /**
     * A mapping from detached node ids to detached fields.
     */
    private detachedNodeToField;
    /**
     * A map from revisions to all detached fields for which the revision is the latest relevant revision.
     * See {@link DetachedField.latestRelevantRevision}.
     *
     * @remarks
     * undefined revisions are tolerated but any roots not associated with a revision must be disposed manually
     */
    private latestRelevantRevisionToFields;
    private readonly codec;
    private readonly options;
    /**
     * The process for loading `DetachedFieldIndex` data from a summary is split into two steps:
     * 1. Call {@link loadData}
     * 2. Call {@link setRevisionsForLoadedData}
     *
     * This flag is only set to `false` after calling `loadData` and is set back to `true` after calling `setRevisionsForLoadedData`.
     * This helps ensure that `setRevisionsForLoadedData` is only called after `loadData` and only called once.
     */
    private isFullyLoaded;
    /**
     * @param name - A name for the index, used as a prefix for the generated field keys.
     * @param rootIdAllocator - An ID allocator used to generate unique field keys.
     */
    constructor(name: string, rootIdAllocator: IdAllocator<ForestRootId>, revisionTagCodec: RevisionTagCodec, idCompressor: IIdCompressor, options?: CodecWriteOptions);
    clone(): DetachedFieldIndex;
    /**
     * Creates a restorable checkpoint of the current state of the DetachedFieldIndex.
     */
    createCheckpoint(): DetachedFieldIndexCheckpoint;
    entries(): Generator<{
        root: ForestRootId;
        latestRelevantRevision?: RevisionTag;
        id: Delta.DetachedNodeId;
    }>;
    /**
     * Removes all entries from the index.
     */
    purge(): void;
    toFieldKey(id: ForestRootId): FieldKey;
    tryGetEntry(id: Delta.DetachedNodeId): ForestRootId | undefined;
    getEntry(id: Delta.DetachedNodeId): ForestRootId;
    /**
     * Returns the detached root IDs for all the trees that were detached or last modified by the given revision.
     */
    getRootsLastTouchedByRevision(revision: RevisionTag): Iterable<ForestRootId>;
    /**
     * Removes the detached roots for all the trees that were detached or last modified by the given revision.
     */
    deleteRootsLastTouchedByRevision(revision: RevisionTag): void;
    deleteEntry(nodeId: Delta.DetachedNodeId): void;
    /**
     * Associates the DetachedNodeId with a field key and creates an entry for it in the index.
     * @param nodeId - The ID of the detached node.
     * @param revision - The revision that last detached the root.
     * See {@link DetachedField.latestRelevantRevision} for details.
     * @param count - The number of entries to create. These entries will have consecutive minor IDs.
     * @returns The atomic ID that the `DetachedFieldIndex` uses to uniquely identify the first root.
     */
    createEntry(nodeId?: Delta.DetachedNodeId, revision?: RevisionTag, count?: number): ForestRootId;
    /**
     * Updates the latest revision that is relevant to the provided root
     */
    updateLatestRevision(id: Delta.DetachedNodeId, revision: RevisionTag | undefined): void;
    encode(): JsonCompatibleReadOnly;
    /**
     * Loads the tree index from the given string, this overrides any existing data.
     */
    loadData(data: JsonCompatibleReadOnly): void;
    /**
     * Sets the latest relevant revision for any roots that have an undefined latest relevant revision.
     * This occurs when the detached field index is loaded from a summary and can only be called once after
     * the summary has been loaded.
     */
    setRevisionsForLoadedData(latestRevision: RevisionTag): void;
}
//# sourceMappingURL=detachedFieldIndex.d.ts.map