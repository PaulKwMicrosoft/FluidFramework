/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { Static } from "@sinclair/typebox";
import * as Type from "@sinclair/typebox";
import type { JsonCompatibleReadOnlyObject } from "../../util/index.js";
import { PersistedValueSchema } from "./formatV1.js";
export type PersistedMetadataFormat = Static<typeof PersistedMetadataFormat>;
export declare const PersistedMetadataFormat: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
export type FieldSchemaFormat = Static<typeof FieldSchemaFormat>;
export declare const FieldSchemaFormat: Type.TObject<{
    kind: Type.TUnsafe<import("./formatV1.js").FieldKindIdentifier>;
    types: Type.TArray<Type.TUnsafe<import("./formatV1.js").TreeNodeSchemaIdentifier<string>>>;
    metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
}>;
/**
 * Format for the content of a {@link TreeNodeStoredSchema}.
 *
 * See {@link DiscriminatedUnionDispatcher} for more information on this pattern.
 */
export declare const TreeNodeSchemaUnionFormat: Type.TObject<{
    /**
     * Object node union member.
     */
    object: Type.TOptional<Type.TRecord<Type.TString, Type.TObject<{
        kind: Type.TUnsafe<import("./formatV1.js").FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<import("./formatV1.js").TreeNodeSchemaIdentifier<string>>>;
        metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
    }>>>;
    /**
     * Map node union member.
     */
    map: Type.TOptional<Type.TObject<{
        kind: Type.TUnsafe<import("./formatV1.js").FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<import("./formatV1.js").TreeNodeSchemaIdentifier<string>>>;
        metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
    }>>;
    /**
     * Leaf node union member.
     */
    leaf: Type.TOptional<Type.TEnum<typeof PersistedValueSchema>>;
}>;
export type TreeNodeSchemaUnionFormat = Static<typeof TreeNodeSchemaUnionFormat>;
/**
 * Format for {@link TreeNodeStoredSchema}.
 *
 * See {@link DiscriminatedUnionDispatcher} for more information on this pattern.
 */
export type TreeNodeSchemaDataFormat = Static<typeof TreeNodeSchemaDataFormat>;
export declare const TreeNodeSchemaDataFormat: Type.TObject<{
    /**
     * Node kind specific data.
     */
    kind: Type.TObject<{
        /**
         * Object node union member.
         */
        object: Type.TOptional<Type.TRecord<Type.TString, Type.TObject<{
            kind: Type.TUnsafe<import("./formatV1.js").FieldKindIdentifier>;
            types: Type.TArray<Type.TUnsafe<import("./formatV1.js").TreeNodeSchemaIdentifier<string>>>;
            metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
        }>>>;
        /**
         * Map node union member.
         */
        map: Type.TOptional<Type.TObject<{
            kind: Type.TUnsafe<import("./formatV1.js").FieldKindIdentifier>;
            types: Type.TArray<Type.TUnsafe<import("./formatV1.js").TreeNodeSchemaIdentifier<string>>>;
            metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
        }>>;
        /**
         * Leaf node union member.
         */
        leaf: Type.TOptional<Type.TEnum<typeof PersistedValueSchema>>;
    }>;
    /**
     * Persisted subset of metadata for this node schema.
     */
    metadata: Type.TOptional<Type.TUnsafe<JsonCompatibleReadOnlyObject>>;
}>;
//# sourceMappingURL=formatV2.d.ts.map