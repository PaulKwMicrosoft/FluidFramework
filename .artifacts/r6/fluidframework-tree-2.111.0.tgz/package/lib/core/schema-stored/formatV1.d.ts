/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { type Brand } from "../../util/index.js";
/**
 * Key (aka Name or Label) for a field which is scoped to a specific TreeNodeStoredSchema.
 *
 * Stable identifier, used when persisting data.
 */
export type FieldKey = Brand<string, "tree.FieldKey">;
/**
 * TypeBox Schema for encoding {@link FieldKey} in persisted data.
 */
export declare const FieldKeySchema: Type.TUnsafe<FieldKey>;
/**
 * Identifier for a TreeNode schema.
 * Also known as "Definition"
 *
 * Stable identifier, used when persisting data.
 */
export type TreeNodeSchemaIdentifier<TName extends string = string> = Brand<TName, "tree.TreeNodeSchemaIdentifier">;
/**
 * Identifier for a FieldKind.
 * Refers to an exact stable policy (ex: specific version of a policy),
 * for how to handle (ex: edit and merge edits to) fields marked with this kind.
 * Persisted in documents as part of stored schema.
 */
export type FieldKindIdentifier = Brand<string, "tree.FieldKindIdentifier">;
export declare const FieldKindIdentifierSchema: Type.TUnsafe<FieldKindIdentifier>;
/**
 * TypeBox Schema for encoding {@link TreeNodeSchemaIdentifiers} in persisted data.
 */
export declare const TreeNodeSchemaIdentifierSchema: Type.TUnsafe<TreeNodeSchemaIdentifier<string>>;
export type FieldSchemaFormat = Static<typeof FieldSchemaFormat>;
export declare const FieldSchemaFormat: Type.TObject<{
    kind: Type.TUnsafe<FieldKindIdentifier>;
    types: Type.TArray<Type.TUnsafe<TreeNodeSchemaIdentifier<string>>>;
}>;
/**
 * Persisted version of {@link ValueSchema}.
 */
export declare enum PersistedValueSchema {
    Number = 0,
    String = 1,
    Boolean = 2,
    FluidHandle = 3,
    Null = 4
}
/**
 * Discriminated union content of tree node schema.
 *
 * See {@link DiscriminatedUnionDispatcher} for more information on this pattern.
 */
export type TreeNodeSchemaDataFormat = Static<typeof TreeNodeSchemaDataFormat>;
export declare const TreeNodeSchemaDataFormat: Type.TObject<{
    /**
     * Object node union member.
     */
    object: Type.TOptional<Type.TRecord<Type.TString, Type.TObject<{
        kind: Type.TUnsafe<FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<TreeNodeSchemaIdentifier<string>>>;
    }>>>;
    /**
     * Map node union member.
     */
    map: Type.TOptional<Type.TObject<{
        kind: Type.TUnsafe<FieldKindIdentifier>;
        types: Type.TArray<Type.TUnsafe<TreeNodeSchemaIdentifier<string>>>;
    }>>;
    /**
     * Leaf node union member.
     */
    leaf: Type.TOptional<Type.TEnum<typeof PersistedValueSchema>>;
}>;
//# sourceMappingURL=formatV1.d.ts.map