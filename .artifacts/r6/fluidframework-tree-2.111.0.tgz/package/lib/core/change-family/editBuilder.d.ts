/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TaggedChange } from "../rebase/index.js";
import type { ChangeFamily, ChangeFamilyEditor } from "./changeFamily.js";
export declare abstract class EditBuilder<TChange> implements ChangeFamilyEditor {
    protected readonly changeFamily: ChangeFamily<ChangeFamilyEditor, TChange>;
    private readonly changeReceiver;
    constructor(changeFamily: ChangeFamily<ChangeFamilyEditor, TChange>, changeReceiver: (change: TaggedChange<TChange>) => void);
    /**
     * Subclasses add editing methods which call this with their generated edits.
     *
     * @sealed
     */
    protected applyChange(change: TaggedChange<TChange>): void;
    enterTransaction(): void;
    exitTransaction(): void;
}
//# sourceMappingURL=editBuilder.d.ts.map