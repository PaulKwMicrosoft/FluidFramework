/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ImplicitFieldSchema, ITree, TreeNode, TreeView, TreeViewConfiguration, VerboseTree } from "../simple-tree/index.js";
import { type SharedTreeAuthorityNodeReference, type SharedTreeAuthorityNodeResolution, type SharedTreeAuthorityReferenceOptions, type SharedTreeAuthorityReferenceResult } from "./authorityNodeReferences.js";
export type { SharedTreeAuthorityNodeReference, SharedTreeAuthorityNodeResolution, SharedTreeAuthorityReferenceOptions, SharedTreeAuthorityReferenceResult, } from "./authorityNodeReferences.js";
/**
 * An immutable, internally consistent A and A+P cut. It never includes local unsequenced work.
 * @alpha
 */
export interface SharedTreeAuthorityCapture {
    readonly checkpoint: string;
    readonly editIds: readonly string[];
    exportApproved(): VerboseTree | undefined;
    exportSequenced(): VerboseTree | undefined;
    dispose(): void;
}
/**
 * An opt-in capture with process-local counterparts for nodes in its sequenced history.
 * Later births (including local unsequenced and correction-draft births) are outside this capture.
 * @alpha
 */
export interface SharedTreeAuthorityReferenceCapture extends SharedTreeAuthorityCapture {
    reference(node: TreeNode): SharedTreeAuthorityReferenceResult;
    resolve(reference: SharedTreeAuthorityNodeReference, target: "live" | SharedTreeAuthorityDraft): SharedTreeAuthorityNodeResolution;
}
/**
 * A private, ordinary editable fork of the capture's approved history, optionally
 * including an explicitly selected prefix of its sequenced provisional edits.
 * Edits do not submit Fluid operations until published as one authority advance.
 * @alpha
 */
export interface SharedTreeAuthorityDraft {
    viewWith<TRoot extends ImplicitFieldSchema>(configuration: TreeViewConfiguration<TRoot>): TreeView<TRoot>;
    dispose(): void;
}
/**
 * Approves an unchanged captured prefix, optionally followed by an authoritative correction.
 * A correction draft must have been created with afterPrefix equal to approvePrefix.
 * Accepted revisions remain in history; this does not replace them or accept arbitrary subsets.
 * @alpha @input
 */
export interface SharedTreeAuthorityPublication {
    readonly batchId: string;
    readonly nextCheckpoint: string;
    readonly capture: SharedTreeAuthorityCapture;
    readonly approvePrefix?: number;
    readonly draft?: SharedTreeAuthorityDraft;
}
/**
 * Restricted v2 authority controller. All clients/writers must be trusted.
 * History is retained without bound; runtime summaries are explicitly unsupported.
 * @alpha
 */
export interface SharedTreeAuthorityController {
    capture(): SharedTreeAuthorityCapture;
    capture(options: SharedTreeAuthorityReferenceOptions): SharedTreeAuthorityReferenceCapture;
    /**
     * Forks captured A followed by exactly the first afterPrefix edits (default zero).
     * Later captured P and all local L are excluded. Publication must approve the same prefix.
     */
    createDraft(capture: SharedTreeAuthorityCapture, options?: {
        readonly afterPrefix: number;
    }): SharedTreeAuthorityDraft;
    publishAdvance(publication: SharedTreeAuthorityPublication): Promise<"applied" | "duplicate" | "stale">;
    onStateChanged(listener: () => void): () => void;
}
/**
 * Gets the restricted experimental controller of an explicitly opted-in tree.
 * This is not an authorization boundary: every Fluid writer is trusted.
 * @alpha
 */
export declare function getSharedTreeAuthority(tree: ITree): SharedTreeAuthorityController;
//# sourceMappingURL=externalAuthorityController.d.ts.map