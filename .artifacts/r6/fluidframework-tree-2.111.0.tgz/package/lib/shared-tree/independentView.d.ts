/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IFluidHandle } from "@fluidframework/core-interfaces";
import { type IIdCompressor } from "@fluidframework/id-compressor/internal";
import type { CodecWriteOptions, ICodecOptions } from "../codec/index.js";
import type { TreeViewConfiguration, ImplicitFieldSchema, TreeViewAlpha, ITreeAlpha, ViewableTree } from "../simple-tree/index.js";
import { type JsonCompatible } from "../util/index.js";
import { type ForestOptions } from "./sharedTree.js";
/**
 * {@link independentView} options.
 * @alpha @input
 */
export interface IndependentViewOptions extends ForestOptions, Partial<CodecWriteOptions> {
    /**
     * Optional ID compressor for generating and compressing identifiers.
     * If not provided, a new one will be created.
     */
    idCompressor?: IIdCompressor | undefined;
}
/**
 * {@link createIndependentTreeAlpha} options.
 * @alpha
 */
export type CreateIndependentTreeAlphaOptions = ForestOptions & ((IndependentViewOptions & {
    /**
     * Optional content for initializing the tree.
     * If not provided, the tree will be uninitialized.
     */
    content?: never;
}) | (ICodecOptions & {
    /**
     * Content for initializing the tree.
     * The content includes the idCompressor, so idCompressor should not be provided at the top level.
     */
    content: ViewContent;
    /**
     * Should not be provided when content is specified.
     * The idCompressor will be obtained from the content.
     */
    idCompressor?: never;
}));
/**
 * Create an uninitialized {@link TreeView} that is not tied to any {@link ITree} instance.
 *
 * @remarks
 * Such a view can never experience collaboration or be persisted to to a Fluid Container.
 *
 * This can be useful for testing, as well as use-cases like working on local files instead of documents stored in some Fluid service.
 * @alpha
 */
export declare function independentView<const TSchema extends ImplicitFieldSchema>(config: TreeViewConfiguration<TSchema>, options?: IndependentViewOptions): TreeViewAlpha<TSchema>;
/**
 * Create an initialized {@link TreeView} that is not tied to any {@link ITree} instance.
 *
 * @remarks
 * Such a view can never experience collaboration or be persisted to to a Fluid Container.
 *
 * This can be useful for testing, as well as use-cases like working on local files instead of documents stored in some Fluid service.
 * @privateRemarks
 * TODO: Providing an API which generates a {@link ViewableTree} extended with export options from {@link ITreeAlpha} and maybe even branching APIs would likely be better that just exposing a {@link TreeViewAlpha}.
 * @alpha
 */
export declare function independentInitializedView<const TSchema extends ImplicitFieldSchema>(config: TreeViewConfiguration<TSchema>, options: ForestOptions & ICodecOptions, content: ViewContent): TreeViewAlpha<TSchema>;
/**
 * Create a {@link ViewableTree} that is not tied to any Fluid runtimes or services.
 *
 * @remarks
 * Such a tree can never experience collaboration or be persisted to to a Fluid Container.
 *
 * This can be useful for testing, as well as use-cases like working on local files instead of documents stored in some Fluid service.
 *
 * @example
 * ```typescript
 * const tree = createIndependentTreeBeta();
 *
 * const stagedConfig = new TreeViewConfiguration({
 * 	schema: SchemaFactoryAlpha.types([
 * 		SchemaFactory.number,
 * 		SchemaFactoryAlpha.staged(SchemaFactory.string),
 * 	]),
 * });
 * const afterConfig = new TreeViewConfigurationAlpha({
 * 	schema: [SchemaFactory.number, SchemaFactory.string],
 * });
 *
 * // Initialize tree
 * {
 * 	const view = tree.viewWith(stagedConfig);
 * 	view.initialize(1);
 * 	view.dispose();
 * }
 *
 * // Do schema upgrade
 * {
 * 	const view = tree.viewWith(afterConfig);
 * 	view.upgradeSchema();
 * 	view.root = "A";
 * 	view.dispose();
 * }
 *
 * // Can still view tree with staged schema
 * {
 * 	const view = tree.viewWith(stagedConfig);
 * 	assert.equal(view.root, "A");
 * 	view.dispose();
 * }
 * ```
 * @privateRemarks
 * Before stabilizing this as public, consider if we can instead just expose a better way to create regular Fluid service based SharedTrees for tests.
 * Something like https://github.com/microsoft/FluidFramework/pull/25422 might be a better long term stable/public solution.
 * @beta
 */
export declare function createIndependentTreeBeta<const TSchema extends ImplicitFieldSchema>(options?: ForestOptions): ViewableTree;
/**
 * Alpha extensions to {@link createIndependentTreeBeta}.
 *
 * @param options - Configuration options for the independent tree.
 * This can be used to create an uninitialized tree, or `content` can be provided to create an initialized tree.
 * If content is provided, the idCompressor is a required part of it: otherwise it is optional and provided at the top level.
 *
 * @privateRemarks
 * TODO: Support more of {@link ITreeAlpha}, including branching APIs to allow for merges.
 * TODO: Better unify this logic with SharedTreeKernel and SharedTreeCore.
 *
 * Before further stabilizing: consider better ways to handle initialized vs uninitialized trees.
 * Perhaps it would be better to not allow initialize here at all, but expose the ability to load compressed tree content and stored schema via ITree or TreeView?
 * If keeping the option here, maybe a separate function of overload would be better? Or maybe flatten ViewContent inline to deduplicate the idCompressor options?
 * @alpha
 */
export declare function createIndependentTreeAlpha<const TSchema extends ImplicitFieldSchema>(options?: CreateIndependentTreeAlphaOptions): ViewableTree & Pick<ITreeAlpha, "exportVerbose" | "exportSimpleSchema">;
/**
 * The portion of SharedTree data typically persisted by the container.
 * Usable with {@link independentInitializedView} to create a {@link TreeView}
 * without loading a container.
 * @alpha
 */
export interface ViewContent {
    /**
     * Compressed tree from {@link (TreeAlpha:interface).exportCompressed}.
     * @remarks
     * This is an owning reference:
     * consumers of this content might modify this data in place (for example when applying edits) to avoid copying.
     */
    readonly tree: JsonCompatible<IFluidHandle>;
    /**
     * Persisted schema from {@link extractPersistedSchema}.
     */
    readonly schema: JsonCompatible;
    /**
     * IIdCompressor which will be used to decompress any compressed identifiers in `tree`
     * as well as for any other identifiers added to the view.
     */
    readonly idCompressor: IIdCompressor;
}
//# sourceMappingURL=independentView.d.ts.map