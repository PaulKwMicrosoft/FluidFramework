/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { GraphCommit } from "../core/index.js";
import { type TreeNode } from "../simple-tree/index.js";
import type { SharedTreeChange } from "./sharedTreeChangeTypes.js";
import type { TreeCheckout } from "./treeCheckout.js";
/**
 * An opaque process-local identity owned by one reference-enabled authority capture.
 * There is no encoding or reopening API. Constructed lookalikes are rejected.
 * @alpha
 */
export interface SharedTreeAuthorityNodeReference {
    readonly scope: "capture-local";
}
/** Result of registering a node from an admitted live or draft view. @alpha */
export type SharedTreeAuthorityReferenceResult = {
    readonly kind: "tracked";
    readonly reference: SharedTreeAuthorityNodeReference;
} | {
    readonly kind: "outsideCapture";
};
/** A counterpart in the requested checkout, never a wrapper from another context. @alpha */
export type SharedTreeAuthorityNodeResolution = {
    readonly kind: "node";
    readonly node: TreeNode;
    readonly status: "inDocument" | "removed";
} | {
    readonly kind: "absent";
} | {
    readonly kind: "unavailable";
    readonly reason: "destroyed";
};
/** Opts in to bounded, eager node tracking for one capture. @alpha @input */
export interface SharedTreeAuthorityReferenceOptions {
    readonly trackNodeReferences: true;
    /** Counts all stored nodes, including leaves and retained removed trees. Default 10,000. */
    readonly maxNodes?: number;
    /** Maximum concurrently retained public reference drafts. Default 16. */
    readonly maxDrafts?: number;
}
export declare function projectAuthorityCheckout(checkout: TreeCheckout, head: GraphCommit<SharedTreeChange>): void;
/** Identity bookkeeping only: no edit IDs, native IDs, path matching, or serialized node keys. */
export declare class AuthorityNodeReferences {
    private readonly live;
    private readonly maxDrafts;
    private readonly contexts;
    private readonly references;
    private readonly indices;
    readonly sequenced: TreeCheckout;
    private disposed;
    constructor(live: TreeCheckout, sequencedHead: GraphCommit<SharedTreeChange>, maxDrafts: number, maxNodes: number);
    private register;
    private release;
    private context;
    createDraft(head: GraphCommit<SharedTreeChange>): TreeCheckout;
    reference(node: TreeNode): SharedTreeAuthorityReferenceResult;
    resolve(reference: SharedTreeAuthorityNodeReference, checkout: TreeCheckout): SharedTreeAuthorityNodeResolution;
    dispose(): void;
    sealDraft(checkout: TreeCheckout): void;
}
//# sourceMappingURL=authorityNodeReferences.d.ts.map