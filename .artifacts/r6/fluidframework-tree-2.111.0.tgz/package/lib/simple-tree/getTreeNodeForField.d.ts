/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TreeValue } from "../core/index.js";
import { type FlexTreeField } from "../feature-libraries/index.js";
import { type TreeNode } from "./core/index.js";
/**
 * Retrieve the associated {@link TreeNode} for the given field's content.
 */
export declare function tryGetTreeNodeForField(field: FlexTreeField): TreeNode | TreeValue | undefined;
//# sourceMappingURL=getTreeNodeForField.d.ts.map