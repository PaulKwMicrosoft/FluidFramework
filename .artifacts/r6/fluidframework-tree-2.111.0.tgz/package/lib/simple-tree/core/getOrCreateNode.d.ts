/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TreeValue } from "../../core/index.js";
import { type FlexTreeUnknownUnboxed } from "../../feature-libraries/index.js";
import type { TreeNode } from "./treeNode.js";
import { type InnerNode } from "./treeNodeKernel.js";
import type { TreeLeafValue } from "./treeNodeSchema.js";
/**
 * Returns the TreeNode or TreeValue for the provided {@link InnerNode}.
 * This will allocate a new one if needed, and otherwise return one from cache.
 * @remarks
 * This supports both hydrated and unhydrated nodes.
 */
export declare function getOrCreateNodeFromInnerNode(flexNode: InnerNode): TreeNode | TreeValue;
/**
 * Returns the TreeNode or TreeValue for the provided {@link FlexTreeUnknownUnboxed}.
 * This will allocate a new one if needed, and otherwise return one from cache.
 * @remarks
 * This supports both hydrated and unhydrated nodes.
 */
export declare function getOrCreateNodeFromInnerUnboxedNode(flexTree: FlexTreeUnknownUnboxed): TreeNode | TreeLeafValue;
//# sourceMappingURL=getOrCreateNode.d.ts.map