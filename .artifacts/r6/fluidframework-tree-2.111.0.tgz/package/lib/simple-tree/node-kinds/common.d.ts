/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type FlexContent } from "../core/index.js";
import { type InsertableContent } from "../unhydratedFlexTreeFromInsertable.js";
import type { MapNodeSchema } from "./map/index.js";
import type { RecordNodeSchema } from "./record/index.js";
/**
 * Utilities shared by multiple node kinds.
 */
/**
 * Converts record-like data to a FlexContent representation for map/record schema.
 */
export declare function recordLikeDataToFlexContent(fieldsIterator: Iterable<readonly [string, InsertableContent]>, schema: MapNodeSchema | RecordNodeSchema): FlexContent;
//# sourceMappingURL=common.d.ts.map