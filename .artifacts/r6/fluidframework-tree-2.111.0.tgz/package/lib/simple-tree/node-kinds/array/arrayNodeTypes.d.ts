/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { NodeKind } from "../../core/index.js";
import type { TreeNodeSchemaClass, TreeNodeSchema, TreeNodeSchemaNonClass, WithType, ImplicitAllowedTypes, InsertableTreeNodeFromImplicitAllowedTypes } from "../../core/index.js";
import type { SchemaType, SimpleArrayNodeSchema } from "../../simpleSchema.js";
import type { TreeArrayNode, TreeArrayNodeAlpha } from "./arrayNode.js";
/**
 * A schema for customizable {@link (TreeArrayNode:interface)}s.
 * @system @sealed @alpha
 */
export interface ArrayNodeCustomizableSchema<out TName extends string = string, in out T extends ImplicitAllowedTypes = ImplicitAllowedTypes, out ImplicitlyConstructable extends boolean = true, out TCustomMetadata = unknown> extends TreeNodeSchemaClass<TName, NodeKind.Array, TreeArrayNode<T> & WithType<TName, NodeKind.Array, T>, Iterable<InsertableTreeNodeFromImplicitAllowedTypes<T>>, ImplicitlyConstructable, T, undefined, TCustomMetadata>, SimpleArrayNodeSchema<SchemaType.View, TCustomMetadata> {
}
/**
 * A Schema for customizable {@link (TreeArrayNode:interface)}s with additional alpha APIs.
 * @remarks
 * Duplicates {@link ArrayNodeCustomizableSchema} with {@link TreeArrayNodeAlpha} as the node type,
 * adding support for the alpha APIs on those nodes.
 * @system @sealed @alpha
 */
export interface ArrayNodeCustomizableSchemaAlpha<out TName extends string = string, in out T extends ImplicitAllowedTypes = ImplicitAllowedTypes, out ImplicitlyConstructable extends boolean = true, out TCustomMetadata = unknown> extends TreeNodeSchemaClass<TName, NodeKind.Array, TreeArrayNodeAlpha<T> & WithType<TName, NodeKind.Array, T>, Iterable<InsertableTreeNodeFromImplicitAllowedTypes<T>>, ImplicitlyConstructable, T, undefined, TCustomMetadata>, SimpleArrayNodeSchema<SchemaType.View, TCustomMetadata> {
}
/**
 * A schema for POJO emulation mode {@link (TreeArrayNode:interface)}s.
 * @system @sealed @alpha
 */
export interface ArrayNodePojoEmulationSchema<out TName extends string = string, in out T extends ImplicitAllowedTypes = ImplicitAllowedTypes, out ImplicitlyConstructable extends boolean = true, out TCustomMetadata = unknown> extends TreeNodeSchemaNonClass<TName, NodeKind.Array, TreeArrayNode<T> & WithType<TName, NodeKind.Array, T>, Iterable<InsertableTreeNodeFromImplicitAllowedTypes<T>>, ImplicitlyConstructable, T, undefined, TCustomMetadata>, SimpleArrayNodeSchema<SchemaType.View, TCustomMetadata> {
}
/**
 * A schema for {@link (TreeArrayNode:interface)}s.
 * @privateRemarks
 * This could have generic arguments added and forwarded.
 * The expected use-cases for this don't need them however, and if they did want an argument it would probably be the allowed types;
 * perhaps if moving to an order independent way to pass generic arguments, adding support for them here would make sense.
 * @alpha
 */
export type ArrayNodeSchema = ArrayNodeCustomizableSchema | ArrayNodePojoEmulationSchema;
/**
 * @alpha
 */
export declare const ArrayNodeSchema: {
    /**
     * instanceof-based narrowing support for ArrayNodeSchema in Javascript and TypeScript 5.3 or newer.
     */
    readonly [Symbol.hasInstance]: (value: TreeNodeSchema) => value is ArrayNodeSchema;
};
/**
 * Narrows a {@link (TreeNodeSchema:interface)} to an {@link (ArrayNodeSchema:interface)}.
 * @privateRemarks
 * If at some point we want to have internal only APIs for ArrayNodeSchema (like done for objects),
 * this can include those since its not the public facing API.
 */
export declare function isArrayNodeSchema(schema: TreeNodeSchema): schema is ArrayNodeSchema;
//# sourceMappingURL=arrayNodeTypes.d.ts.map