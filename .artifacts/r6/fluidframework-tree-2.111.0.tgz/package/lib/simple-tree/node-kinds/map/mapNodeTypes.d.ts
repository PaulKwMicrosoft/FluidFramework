/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { NodeKind } from "../../core/index.js";
import type { TreeNodeSchemaClass, TreeNodeSchema, TreeNodeSchemaNonClass, WithType, ImplicitAllowedTypes } from "../../core/index.js";
import type { SchemaType, SimpleMapNodeSchema } from "../../simpleSchema.js";
import type { MapNodeInsertableData, TreeMapNodeAlpha } from "./mapNode.js";
/**
 * A schema for customizable {@link (TreeMapNodeAlpha:interface)}s.
 * @system @sealed @alpha
 */
export interface MapNodeCustomizableSchema<out TName extends string = string, in out T extends ImplicitAllowedTypes = ImplicitAllowedTypes, out ImplicitlyConstructable extends boolean = true, out TCustomMetadata = unknown> extends TreeNodeSchemaClass<TName, NodeKind.Map, TreeMapNodeAlpha<T> & WithType<TName, NodeKind.Map, T>, MapNodeInsertableData<T>, ImplicitlyConstructable, T, undefined, TCustomMetadata>, SimpleMapNodeSchema<SchemaType.View, TCustomMetadata> {
}
/**
 * A schema for POJO emulation mode {@link (TreeMapNodeAlpha:interface)}s.
 * @system @sealed @alpha
 */
export interface MapNodePojoEmulationSchema<out TName extends string = string, in out T extends ImplicitAllowedTypes = ImplicitAllowedTypes, out ImplicitlyConstructable extends boolean = true, out TCustomMetadata = unknown> extends TreeNodeSchemaNonClass<TName, NodeKind.Map, TreeMapNodeAlpha<T> & WithType<TName, NodeKind.Map, T>, MapNodeInsertableData<T>, ImplicitlyConstructable, T, undefined, TCustomMetadata>, SimpleMapNodeSchema<SchemaType.View, TCustomMetadata> {
}
/**
 * A schema for {@link (TreeMapNodeAlpha:interface)}s.
 * @privateRemarks
 * This could have generic arguments added and forwarded.
 * The expected use-cases for this don't need them however, and if they did want an argument it would probably be the allowed types;
 * perhaps if moving to an order independent way to pass generic arguments, adding support for them here would make sense.
 * @alpha
 */
export type MapNodeSchema = MapNodeCustomizableSchema | MapNodePojoEmulationSchema;
/**
 * @alpha
 */
export declare const MapNodeSchema: {
    /**
     * instanceof-based narrowing support for MapNodeSchema in Javascript and TypeScript 5.3 or newer.
     */
    readonly [Symbol.hasInstance]: (value: TreeNodeSchema) => value is MapNodeSchema;
};
/**
 * Narrows a {@link (TreeNodeSchema:interface)} to an {@link (MapNodeSchema:interface)}.
 * @privateRemarks
 * If at some point we want to have internal only APIs for MapNodeSchema (like done for objects),
 * this can include those since its not the public facing API.
 */
export declare function isMapNodeSchema(schema: TreeNodeSchema): schema is MapNodeSchema;
//# sourceMappingURL=mapNodeTypes.d.ts.map