/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { FluidReadonlyMap } from "@fluidframework/core-interfaces/internal";
import { type RestrictiveStringRecord } from "../../../util/index.js";
import type { NodeSchemaOptionsAlpha } from "../../api/index.js";
import { NodeKind, type TreeNode, type ImplicitAllowedTypes, type InsertableTreeNodeFromImplicitAllowedTypes, type TreeNodeFromImplicitAllowedTypes, type TreeNodeSchemaCorePrivate } from "../../core/index.js";
import type { MapNodeCustomizableSchema, MapNodePojoEmulationSchema } from "./mapNodeTypes.js";
/**
 * A map of string keys to tree objects.
 *
 * @privateRemarks
 * Add support for `clear` once we have established merge semantics for it.
 *
 * @sealed @public
 */
export interface TreeMapNode<T extends ImplicitAllowedTypes = ImplicitAllowedTypes> extends ReadonlyMap<string, TreeNodeFromImplicitAllowedTypes<T>>, TreeNode {
    /**
     * Adds or updates an entry in the map with a specified `key` and a `value`.
     *
     * @param key - The key of the element to add to the map.
     * @param value - The value of the element to add to the map.
     *
     * @remarks
     * Setting the value at a key to `undefined` is equivalent to calling {@link TreeMapNode.delete} with that key.
     */
    set(key: string, value: InsertableTreeNodeFromImplicitAllowedTypes<T> | undefined): void;
    /**
     * Removes the specified element from this map by its `key`.
     *
     * @remarks
     * Note: unlike JavaScript's Map API, this method does not return a flag indicating whether or not the value was
     * deleted.
     *
     * @privateRemarks
     * Regarding the choice to not return a boolean: Since this data structure is distributed in nature, it isn't
     * possible to tell whether or not the item was deleted as a result of this method call. Returning a "best guess"
     * is more likely to create issues / promote bad usage patterns than offer useful information.
     *
     * @param key - The key of the element to remove from the map.
     */
    delete(key: string): void;
    /**
     * Returns an iterable of keys in the map.
     *
     * @remarks
     * Note: no guarantees are made regarding the order of the keys returned.
     * If your usage scenario depends on consistent ordering, you will need to sort these yourself.
     */
    keys(): IterableIterator<string>;
    /**
     * Returns an iterable of values in the map.
     *
     * @remarks
     * Note: no guarantees are made regarding the order of the values returned.
     * If your usage scenario depends on consistent ordering, you will need to sort these yourself.
     */
    values(): IterableIterator<TreeNodeFromImplicitAllowedTypes<T>>;
    /**
     * Returns an iterable of key, value pairs for every entry in the map.
     *
     * @remarks
     * Note: no guarantees are made regarding the order of the entries returned.
     * If your usage scenario depends on consistent ordering, you will need to sort these yourself.
     */
    entries(): IterableIterator<[string, TreeNodeFromImplicitAllowedTypes<T>]>;
    /**
     * Executes the provided function once per each key/value pair in this map.
     *
     * @remarks
     * Note: no guarantees are made regarding the order in which the function is called with respect to the map's entries.
     * If your usage scenario depends on consistent ordering, you will need to account for this.
     */
    forEach(callbackfn: (value: TreeNodeFromImplicitAllowedTypes<T>, key: string, map: ReadonlyMap<string, TreeNodeFromImplicitAllowedTypes<T>>) => void, thisArg?: any): void;
}
/**
 * {@link TreeMapNode} with FluidReadonlyMap-based iteration.
 *
 * @remarks
 * This is the same as {@link TreeMapNode} except that it extends FluidReadonlyMap
 * instead of the built-in `ReadonlyMap`, insulating against breaking changes
 * in TypeScript's standard library iterator types.
 *
 * @sealed @alpha
 */
export interface TreeMapNodeAlpha<T extends ImplicitAllowedTypes = ImplicitAllowedTypes> extends FluidReadonlyMap<string, TreeNodeFromImplicitAllowedTypes<T>>, TreeNode, Pick<TreeMapNode<T>, "set" | "delete"> {
}
/**
 * Define a {@link TreeNodeSchema} for a {@link (TreeArrayNode:interface)}.
 *
 * @param base - base schema type to extend.
 * @param useMapPrototype - should this type emulate a ES6 Map object (by faking its prototype with a proxy).
 * @param persistedMetadata - Optional persisted metadata for the object node schema.
 */
export declare function mapSchema<TName extends string, const T extends ImplicitAllowedTypes, const ImplicitlyConstructable extends boolean, const TCustomMetadata = unknown>(identifier: TName, info: T, implicitlyConstructable: ImplicitlyConstructable, useMapPrototype: boolean, nodeOptions?: NodeSchemaOptionsAlpha<TCustomMetadata>): MapNodeCustomizableSchema<TName, T, ImplicitlyConstructable, TCustomMetadata> & MapNodePojoEmulationSchema<TName, T, ImplicitlyConstructable, TCustomMetadata> & TreeNodeSchemaCorePrivate<string, NodeKind, never, boolean, unknown, unknown>;
/**
 * Content which can be used to construct a Map node, explicitly or implicitly.
 * @system @public
 */
export type MapNodeInsertableData<T extends ImplicitAllowedTypes> = Iterable<readonly [string, InsertableTreeNodeFromImplicitAllowedTypes<T>]> | RestrictiveStringRecord<InsertableTreeNodeFromImplicitAllowedTypes<T>>;
//# sourceMappingURL=mapNode.d.ts.map