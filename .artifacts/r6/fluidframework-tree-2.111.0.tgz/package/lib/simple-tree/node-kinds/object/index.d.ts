/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export { type FieldHasDefault, type FieldHasDefaultAlpha, type InsertableObjectFromSchemaRecord, type InsertableObjectFromSchemaRecordAlpha, type ObjectFromSchemaRecord, objectSchema, setField, type TreeObjectNode, type SimpleKeyMap, } from "./objectNode.js";
export { isObjectNodeSchema, ObjectNodeSchema, type ObjectNodeSchemaWorkaround, type ObjectNodeSchemaPrivate, } from "./objectNodeTypes.js";
//# sourceMappingURL=index.d.ts.map