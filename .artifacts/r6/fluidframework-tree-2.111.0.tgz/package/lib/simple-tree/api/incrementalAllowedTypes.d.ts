/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IncrementalEncodingPolicy } from "../../feature-libraries/index.js";
import type { TreeSchema } from "../treeSchema.js";
/**
 * A symbol when present in the {@link AnnotatedAllowedTypes.metadata}'s `custom` property as true, opts in the allowed
 * types to incremental summary optimization.
 * These allowed types will be optimized during summary such that if they don't change across summaries,
 * they will not be encoded and their content will not be included in the summary that is uploaded to the service.
 * @remarks
 * See {@link incrementalEncodingPolicyForAllowedTypes} for more details.
 *
 * Use {@link SchemaStaticsBeta.types} to add this metadata to allowed types in a schema.
 * @example
 * ```typescript
 * const sf = new SchemaFactoryAlpha("IncrementalSummarization");
 * class Foo extends sf.objectAlpha("foo", {
 *   bar: sf.types([{ type: sf.string, metadata: {} }], {
 *     custom: { [incrementalSummaryHint]: true },
 *   }),
 * }) {}
 * ```
 * @alpha
 */
export declare const incrementalSummaryHint: unique symbol;
/**
 * This helper function {@link incrementalEncodingPolicyForAllowedTypes} can be used to generate a callback function
 * of type {@link IncrementalEncodingPolicy}. It determines if each {@link AllowedTypes} in a schema should be
 * incrementally summarized.
 * This callback can be passed as the value for {@link SharedTreeOptions.shouldEncodeIncrementally} parameter
 * when creating the tree.
 *
 * @param rootSchema - The schema for the root of the tree.
 * @returns A callback function of type {@link IncrementalEncodingPolicy} which determines if allowed types should
 * be incrementally summarized based on whether they have opted in via the {@link incrementalSummaryHint} metadata.
 *
 * @remarks
 * This only works for forest type {@link ForestTypeOptimized} and compression strategy
 * {@link TreeCompressionStrategy.CompressedIncremental}.
 *
 * @privateRemarks
 * The {@link incrementalSummaryHint} will be replaced with a specialized metadata property once the
 * incremental summary feature and APIs are stabilized.
 *
 * @alpha
 */
export declare function incrementalEncodingPolicyForAllowedTypes(rootSchema: TreeSchema): IncrementalEncodingPolicy;
//# sourceMappingURL=incrementalAllowedTypes.d.ts.map