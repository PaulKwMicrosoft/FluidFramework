/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { TreeNode } from "../core/index.js";
import type { ImplicitFieldSchema } from "../fieldSchema.js";
import type { TreeViewAlpha } from "./tree.js";
/**
 * The status of a node in a that has been {@link trackDirtyNodes | tracked for changes}.
 * @remarks Nodes can be marked "new", "changed", or "moved", with "new" taking precedence over "changed" and "changed" taking precedence over "moved".
 * * "new": The node was added.
 * * "changed": A direct child was updated, added, removed, or moved (and the node is not "new").
 * * "moved": The node was moved between/within arrays (and the node is not "new" or "changed").
 * @privateRemarks
 * It is unclear how this will handle forward compatibility with other kinds of edits, like moves that are not limited to arrays (attach, detach, swap):
 * this needs to be sorted out before this is stabilized.
 * It is also unclear how this is supposed to handle schema changes (which can result in new TreeNode instance, but I think won't trigger "new" here).
 * @alpha
 */
export type DirtyTreeStatus = "new" | "changed" | "moved";
/**
 * A map-like interface for tracking the {@link DirtyTreeStatus | status} of nodes that have been {@link trackDirtyNodes | tracked for changes}.
 * @privateRemarks TODO: Replace this with `MapGetSet` from `@fluidframework/core-interfaces`.
 * @alpha
 */
export interface DirtyTreeMap {
    get(node: TreeNode): DirtyTreeStatus | undefined;
    set(node: TreeNode, status: DirtyTreeStatus): void;
}
/**
 * Registers a visitor on the view's forest that tracks which nodes are dirty.
 * @param view - The view to track dirty nodes on
 * @param dirty - A {@link DirtyTreeMap | map} that will be updated over time to reflect the {@link DirtyTreeStatus | status} of nodes as they change.
 * Nodes that have not changed will not be inserted/updated in the map.
 * @returns a cleanup function that should be called when the tracking is no longer needed.
 * @example
 * ```typescript
 * const dirty = new Map<TreeNode, DirtyTreeStatus>();
 * const stopTracking = trackDirtyNodes(view, dirty);
 * // ... make changes to the view ...
 * console.log(`The root of the tree is ${dirty.get(view.root) ?? "unchanged"}`);
 * stopTracking();
 * ```
 * @privateRemarks
 * This provides an opportunity for user code ("set" on dirty) to run during forest changes, in the middle of processing an edit.
 * We have generally avoided exposing such times to users and instead flush events after the edit has finished and user facing invariants are known to be restored.
 * Before stabilizing, how this event relates to other events time/ordering wise should be clarified, and if any APIs have been provided to defer events, that mentioned as well.
 * Maybe updates should be deferred?
 *
 * This is also documented in terms of "forest" which is not a concept in the public API, and thus needs to be redefined in terms of public concepts.
 * @alpha
 */
export declare function trackDirtyNodes(view: TreeViewAlpha<ImplicitFieldSchema>, dirty: DirtyTreeMap): () => void;
//# sourceMappingURL=dirtyIndex.d.ts.map