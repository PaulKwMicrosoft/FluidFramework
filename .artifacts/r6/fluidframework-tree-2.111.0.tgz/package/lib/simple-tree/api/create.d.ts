/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ITreeCursorSynchronous, type TreeFieldStoredSchema } from "../../core/index.js";
import { type Context, type Unhydrated, UnhydratedFlexTreeNode } from "../core/index.js";
import type { ImplicitFieldSchema, TreeFieldFromImplicitField } from "../fieldSchema.js";
/**
 * Creates an unhydrated simple-tree field from a cursor in nodes mode.
 * @remarks
 * Does not support providing missing defaults values.
 * Validates the field is in schema using `destinationSchema` the provided `contextForNewNodes` or the default unhydrated context if not provided.
 */
export declare function createFromCursor<const TSchema extends ImplicitFieldSchema>(schema: TSchema, cursor: ITreeCursorSynchronous | undefined, destinationSchema: TreeFieldStoredSchema, contextForNewNodes?: Context): Unhydrated<TreeFieldFromImplicitField<TSchema>>;
/**
 * Construct an {@link UnhydratedFlexTreeNode} from a cursor in Nodes mode.
 * @remarks
 * This does not fully validate the node is in schema, but does throw UsageErrors for some cases of out-of-schema content.
 *
 * Does not support unknown optional fields: will throw a UsageError if the field is not in schema.
 * This cannot easily be fixed as this code requires a schema for each subtree to process, and none is available for unknown optional fields.
 */
export declare function unhydratedFlexTreeFromCursor(context: Context, cursor: ITreeCursorSynchronous): UnhydratedFlexTreeNode;
//# sourceMappingURL=create.d.ts.map