/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type FieldKey, type FieldKindIdentifier, LeafNodeStoredSchema, MapNodeStoredSchema, ObjectNodeStoredSchema, type TreeNodeSchemaIdentifier, type TreeStoredSchema, type TreeTypeSet, type ValueSchema } from "../../core/index.js";
import { NodeKind, type AnnotatedAllowedType, type TreeNodeSchema } from "../core/index.js";
import type { TreeSchema } from "../treeSchema.js";
/**
 * Discriminated union (keyed on `mismatch`) of discrepancies between a view and stored schema which
 * make it possible for content matching the stored schema to be incompatible with the view schema.
 */
export type Discrepancy = FieldDiscrepancy | NodeKindDiscrepancy;
/**
 * A discrepancy in the declaration of a field.
 */
export type FieldDiscrepancy = AllowedTypeDiscrepancy | FieldKindDiscrepancy | ValueSchemaDiscrepancy;
/**
 * Information about where a field discrepancy is located within a collection of schema.
 */
export interface FieldDiscrepancyLocation {
    /**
     * The {@link TreeNodeSchemaIdentifier} that contains the discrepancy.
     *
     * Undefined iff the discrepancy is part of the root field schema.
     */
    readonly identifier: TreeNodeSchemaIdentifier | undefined;
    /**
     * The {@link FieldKey} for the field that contains the discrepancy.
     * Undefined when:
     * - the discrepancy is part of the root field schema
     * - the discrepancy is for 'all fields' of a map node
     */
    readonly fieldKey: FieldKey | undefined;
}
/**
 * A discrepancy in the allowed types of a field.
 *
 * @remarks
 * This reports the symmetric difference of allowed types.
 */
export interface AllowedTypeDiscrepancy extends FieldDiscrepancyLocation {
    readonly mismatch: "allowedTypes";
    /**
     * Annotated allowed types in viewed schema
     * (excluding {@link SchemaStaticsBeta.staged | staged} schema) which are not allowed in stored schema.
     */
    readonly view: readonly AnnotatedAllowedType<TreeNodeSchema>[];
    /**
     * Allowed type identifiers in stored schema which are not allowed in view schema
     * (including the view schema's {@link SchemaStaticsBeta.staged | staged} schema).
     */
    readonly stored: readonly TreeNodeSchemaIdentifier[];
}
/**
 * Differences in `FieldKindIdentifier` between two schema.
 */
export interface FieldKindDiscrepancy extends FieldDiscrepancyLocation {
    readonly mismatch: "fieldKind";
    readonly view: FieldKindIdentifier;
    readonly stored: FieldKindIdentifier;
}
/**
 * Differences in the `ValueSchema` of two `LeafNodeStoredSchema` objects.
 */
export interface ValueSchemaDiscrepancy {
    identifier: TreeNodeSchemaIdentifier;
    mismatch: "valueSchema";
    view: ValueSchema | undefined;
    stored: ValueSchema | undefined;
}
/**
 * Differences in the kind of node schema.
 *
 * Includes when stored object schema are expected to be compatible with an array node schema.
 */
export interface NodeKindDiscrepancy {
    identifier: TreeNodeSchemaIdentifier;
    mismatch: "nodeKind";
    view: NodeKind;
    stored: SchemaFactoryNodeKind;
}
type SchemaFactoryNodeKind = typeof ObjectNodeStoredSchema | typeof MapNodeStoredSchema | typeof LeafNodeStoredSchema;
/**
 * Finds and reports discrepancies between a view schema and a stored schema which make "canView" false.
 * @remarks
 * See documentation on {@link Discrepancy} and its subtypes for details of possible discrepancies.
 */
export declare function getDiscrepanciesInAllowedContent(view: TreeSchema, stored: TreeStoredSchema): Iterable<Discrepancy>;
/**
 * Returns the allowed types that are not present in both the given view and stored schemas.
 */
export declare function findExtraAllowedTypes(viewAllowedTypes: readonly AnnotatedAllowedType<TreeNodeSchema>[], storedAllowedTypes: TreeTypeSet): Pick<AllowedTypeDiscrepancy, "view" | "stored">;
export {};
//# sourceMappingURL=discrepancies.d.ts.map