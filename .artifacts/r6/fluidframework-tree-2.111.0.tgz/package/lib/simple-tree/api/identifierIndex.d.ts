/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TreeIndex } from "../../feature-libraries/index.js";
import type { TreeNode } from "../core/index.js";
import { type ImplicitFieldSchema } from "../fieldSchema.js";
import type { TreeView } from "./tree.js";
/**
 * An index that returns tree nodes given their associated identifiers.
 *
 * @beta
 */
export type IdentifierIndex = TreeIndex<string, TreeNode>;
/**
 * Creates an {@link IdentifierIndex} for a given {@link TreeView}.
 *
 * @beta
 */
export declare function createIdentifierIndex<TSchema extends ImplicitFieldSchema>(view: TreeView<TSchema>): IdentifierIndex;
//# sourceMappingURL=identifierIndex.d.ts.map