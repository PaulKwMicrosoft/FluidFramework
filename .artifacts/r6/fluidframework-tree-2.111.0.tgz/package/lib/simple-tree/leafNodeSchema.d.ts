/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type TreeValue, ValueSchema } from "../core/index.js";
import { type FlexTreeNode } from "../feature-libraries/index.js";
import { type JsonCompatibleReadOnlyObject } from "../util/index.js";
import { NodeKind, type TreeNodeSchema, type TreeNodeSchemaNonClass, type NodeSchemaMetadata, type TreeLeafValue, type TreeNodeSchemaCorePrivate, type TreeNodeSchemaPrivateData, privateDataSymbol, type FlexContent } from "./core/index.js";
import type { SimpleLeafNodeSchema } from "./simpleSchema.js";
import type { FactoryContent } from "./unhydratedFlexTreeFromInsertable.js";
/**
 * Instances of this class are schema for leaf nodes.
 * @remarks
 * Unlike other schema, leaf schema are class instances instead of classes themselves.
 * This is because the instance type (the tree node type) for leaves are not objects,
 * so those instances can't be instances of a schema based class.
 * @privateRemarks
 * This class refers to the underlying flex tree schema in its constructor, so this class can't be included in the package API.
 */
export declare class LeafNodeSchema<Name extends string, const T extends ValueSchema> implements TreeNodeSchemaNonClass<Name, NodeKind.Leaf, TreeValue<T>, TreeValue<T>>, SimpleLeafNodeSchema, TreeNodeSchemaCorePrivate {
    #private;
    readonly identifier: Name;
    readonly kind = NodeKind.Leaf;
    readonly info: T;
    readonly implicitlyConstructable: true;
    readonly childTypes: ReadonlySet<TreeNodeSchema>;
    readonly [privateDataSymbol]: TreeNodeSchemaPrivateData;
    create(data: TreeValue<T> | FlexTreeNode): TreeValue<T>;
    createFromInsertable(data: TreeValue<T>): TreeValue<T>;
    readonly leafKind: ValueSchema;
    readonly metadata: NodeSchemaMetadata;
    readonly persistedMetadata: JsonCompatibleReadOnlyObject | undefined;
    constructor(name: Name, t: T);
}
/**
 * A {@link TreeNodeSchema} for a {@link TreeLeafValue}.
 * @remarks
 * This is just a more specific alias for a particular {@link TreeNodeSchemaNonClass}.
 * It only exists to make the API (particularly errors, IntelliSense, and generated .d.ts files) more readable.
 *
 * See {@link SchemaFactory} and its various properties for actual leaf schema objects.
 * @privateRemarks
 * This is an interface so its name will show up in things like type errors instead of the fully expanded TreeNodeSchemaNonClass.
 * @system @sealed @public
 */
export interface LeafSchema<Name extends string, T extends TreeLeafValue> extends TreeNodeSchemaNonClass<`com.fluidframework.leaf.${Name}`, NodeKind.Leaf, T, T, true> {
}
export declare const stringSchema: LeafSchema<"string", string> & SimpleLeafNodeSchema<import("./simpleSchema.js").SchemaType>;
export declare const numberSchema: LeafSchema<"number", number> & SimpleLeafNodeSchema<import("./simpleSchema.js").SchemaType>;
export declare const booleanSchema: LeafSchema<"boolean", boolean> & SimpleLeafNodeSchema<import("./simpleSchema.js").SchemaType>;
export declare const nullSchema: LeafSchema<"null", null> & SimpleLeafNodeSchema<import("./simpleSchema.js").SchemaType>;
export declare const handleSchema: LeafSchema<"handle", import("@fluidframework/core-interfaces").IFluidHandle<unknown>> & SimpleLeafNodeSchema<import("./simpleSchema.js").SchemaType>;
/**
 * Transforms data under a Leaf schema.
 * @param data - The tree data to be transformed. Must be a {@link TreeValue}.
 * @param schema - The schema associated with the value.
 * @param allowedTypes - The allowed types specified by the parent.
 * Used to determine which fallback values may be appropriate.
 */
export declare function leafToFlexContent(data: FactoryContent, schema: TreeNodeSchema, allowedTypes: ReadonlySet<TreeNodeSchema>): FlexContent;
//# sourceMappingURL=leafNodeSchema.d.ts.map