/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { Context, type TreeNodeSchema, type TreeNodeSchemaInitializedData } from "./core/index.js";
import { type ImplicitFieldSchema } from "./fieldSchema.js";
/**
 * Utility for creating {@link Context}s for unhydrated nodes.
 * @remarks
 * The resulting context will not allow any unknown optional fields.
 */
export declare function getUnhydratedContext(schema: ImplicitFieldSchema): Context;
/**
 * Utility for creating {@link TreeNodeSchemaInitializedData}.
 */
export declare function getTreeNodeSchemaInitializedData(schema: TreeNodeSchema, handler: Pick<TreeNodeSchemaInitializedData, "toFlexContent" | "shallowCompatibilityTest">): TreeNodeSchemaInitializedData;
//# sourceMappingURL=createContext.d.ts.map