/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export type { _InlineTrick, FlattenKeys } from "./util/index.js";
export type { ApplyKind, ApplyKindInput, NodeBuilderData, FieldHasDefault, ScopedSchemaName, DefaultProvider, typeNameSymbol, InsertableObjectFromSchemaRecord, } from "./simple-tree/index.js";
export type { FlexList, FlexListToUnion, ExtractItemType } from "./simple-tree/index.js";
//# sourceMappingURL=internalTypes.d.ts.map