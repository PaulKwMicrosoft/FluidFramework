/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import * as Type from "@sinclair/typebox";
import type { ObjectOptions, Static } from "@sinclair/typebox";

import { SchemaFormatVersion, schemaFormatV2 } from "../../core/index.js";

const noAdditionalProps: ObjectOptions = { additionalProperties: false };

/**
 * Format for encoding as json.
 *
 * For consistency all lists are sorted and undefined values are omitted.
 *
 * This chooses to use lists of named objects instead of maps:
 * this choice is somewhat arbitrary, but avoids user data being used as object keys,
 * which can sometimes be an issue (for example handling that for "__proto__" can require care).
 * It also makes it simpler to deterministically sort by keys.
 */
export const Format = Type.Object(
	{
		version: Type.Literal(SchemaFormatVersion.v2),
		nodes: Type.Record(Type.String(), schemaFormatV2.TreeNodeSchemaDataFormat),
		root: schemaFormatV2.FieldSchemaFormat,
	},
	noAdditionalProps,
);
export type Format = Static<typeof Format>;
