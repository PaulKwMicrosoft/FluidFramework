/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import { assert, unreachableCase } from "@fluidframework/core-utils/internal";

import type { ChangeAtomId, RevisionTag } from "../../core/index.js";
import type { IdAllocator, Mutable } from "../../util/index.js";
import type { InvertNodeManager, NodeId } from "../modular-schema/index.js";

import { MarkListFactory } from "./markListFactory.js";
import {
	type Attach,
	type CellId,
	type CellMark,
	type Changeset,
	type Detach,
	type Mark,
	type MarkList,
	type NoopMark,
	NoopMarkType,
	type Rename,
} from "./types.js";
import {
	areEqualCellIds,
	getAttachedRootId,
	getDetachedRootId,
	getInputCellId,
	getOutputCellId,
	isImpactful,
	splitMark,
	withNodeChange,
} from "./utils.js";

/**
 * Inverts a given changeset.
 * @param change - The changeset to produce the inverse of.
 * @param isRollback - Whether the inverse is being produced for a rollback.
 * @param genId - The ID allocator to use for generating new IDs.
 * @param revision - The revision to use for the inverse changeset.
 * @param crossFieldManager - The cross-field manager to use for tracking cross-field changes.
 * @returns The inverse of the given `change` such that the inverse can be applied after `change`.
 *
 * WARNING! This implementation is incomplete:
 * - Support for slices is not implemented.
 */
export function invert(
	change: Changeset,
	isRollback: boolean,
	genId: IdAllocator,
	revision: RevisionTag | undefined,
	crossFieldManager: InvertNodeManager,
): Changeset {
	return invertMarkList(change, isRollback, crossFieldManager, revision);
}

function invertMarkList(
	markList: MarkList,
	isRollback: boolean,
	crossFieldManager: InvertNodeManager,
	revision: RevisionTag | undefined,
): MarkList {
	const inverseMarkList = new MarkListFactory();

	for (const mark of markList) {
		const inverseMarks = invertMark(mark, isRollback, crossFieldManager, revision);
		inverseMarkList.push(...inverseMarks);
	}

	return inverseMarkList.list;
}

function invertMark(
	mark: Mark,
	isRollback: boolean,
	crossFieldManager: InvertNodeManager,
	revision: RevisionTag | undefined,
): Mark[] {
	if (!isImpactful(mark)) {
		const inputId = getInputCellId(mark);
		return [invertNodeChangeOrSkip(mark.count, mark.changes, inputId)];
	}
	const type = mark.type;
	switch (type) {
		case NoopMarkType: {
			return [mark];
		}
		case "Rename": {
			const inputId = getInputCellId(mark);
			assert(inputId !== undefined, 0x9f5 /* Rename mark must have cell ID */);

			// In older client versions, the ID of a detached root was the same as the ID of the cell it was last detached from.
			// To preserve compatibility with those versions, we must make sure that we do not rename the cell if we are not also
			// renaming the associated detached root, if there is one.
			if (isRollback) {
				// A rollback inverse inverts any associated root rename, so we should also invert the cell rename.
				const inverse: Mutable<CellMark<Rename>> = {
					type: "Rename",
					count: mark.count,
					cellId: mark.idOverride,
					// Unlike a remove or move-out, which follow a node, there is no way for this mark to assign the original input cell ID to another cell.
					// This means it should be safe to always restore the input cell ID (as opposed to only doing it on rollbacks).
					// Despite that, we still only do it on rollback for the sake of consistency: once a cell has been assigned an ID,
					// the only way for that cell to be assigned that ID again is if it is rolled back to that state.
					idOverride: inputId,
				};
				return [withNodeChange(inverse, mark.changes)];
			} else {
				// An undo does not invert root renames, so we should not invert cell renames.
				return [invertNodeChangeOrSkip(mark.count, mark.changes, mark.idOverride)];
			}
		}
		case "Detach": {
			assert(mark.revision !== undefined, 0x5a1 /* Unable to revert to undefined revision */);
			const outputId = getOutputCellId(mark);
			const inputId = getInputCellId(mark);
			assert(inputId === undefined, "Unexpected detach of detached node");
			const detachId = getDetachedRootId(mark);
			const attachId = crossFieldManager.getInvertedMoveId(detachId);
			crossFieldManager.invertDetach(detachId, mark.count, mark.changes);

			const inverse: Mark = {
				type: "Attach",
				count: mark.count,
				cellId: outputId,
				revision: attachId.revision,
				id: attachId.localId,
			};
			return [inverse];
		}
		case "Attach": {
			return invertInsert(mark, revision, crossFieldManager, isRollback);
		}
		default: {
			unreachableCase(type);
		}
	}
}

function invertInsert(
	mark: CellMark<Attach>,
	revision: RevisionTag | undefined,
	manager: InvertNodeManager,
	isRollback: boolean,
): Mark[] {
	const entry = manager.invertAttach(getAttachedRootId(mark), mark.count);

	if (entry.length < mark.count) {
		const [mark1, mark2] = splitMark(mark, entry.length);
		return [
			invertInsertSegment(mark1, revision, isRollback, entry.value),
			...invertInsert(mark2, revision, manager, isRollback),
		];
	}

	return [invertInsertSegment(mark, revision, isRollback, entry.value)];
}

function invertInsertSegment(
	mark: CellMark<Attach>,
	revision: RevisionTag | undefined,
	isRollback: boolean,
	nodeChange: NodeId | undefined,
): Mark {
	const inputId = getInputCellId(mark);
	assert(inputId !== undefined, 0x80c /* Active inserts should target empty cells */);

	const detachId = invertAttachId(getAttachedRootId(mark), revision, isRollback);

	const removeMark: Mutable<CellMark<Detach>> = {
		type: "Detach",
		count: mark.count,
		id: detachId.localId,
		revision: detachId.revision,
	};

	if (isRollback && !areEqualCellIds(inputId, detachId)) {
		removeMark.cellRename = inputId;
	}

	if (nodeChange !== undefined) {
		removeMark.changes = nodeChange;
	}

	return removeMark;
}

function invertAttachId(
	attachId: ChangeAtomId,
	revision: RevisionTag | undefined,
	isRollback: boolean,
): ChangeAtomId {
	if (!isRollback) {
		return {
			revision,
			localId: attachId.localId,
		};
	}

	return attachId;
}

function invertNodeChangeOrSkip(
	count: number,
	changes: NodeId | undefined,
	cellId?: CellId,
): Mark {
	if (changes !== undefined) {
		assert(count === 1, 0x66c /* A modify mark must have length equal to one */);
		const noop: CellMark<NoopMark> = {
			count,
			changes,
		};
		if (cellId !== undefined) {
			noop.cellId = cellId;
		}
		return noop;
	}

	if (cellId !== undefined) {
		return { count, cellId };
	}
	return { count };
}
