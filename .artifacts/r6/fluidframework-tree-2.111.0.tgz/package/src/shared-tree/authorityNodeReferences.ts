/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import { assert } from "@fluidframework/core-utils/internal";
import { UsageError } from "@fluidframework/telemetry-utils/internal";
import type { Anchor, AnchorNode, GraphCommit } from "../core/index.js";
import { TreeStatus } from "../feature-libraries/index.js";
import {
	type TreeNode,
	isTreeNode,
	getKernel,
	SimpleContextSlot,
	treeNodeFromAnchor,
} from "../simple-tree/index.js";
import { disposeSymbol } from "../util/index.js";
import type { SharedTreeChange } from "./sharedTreeChangeTypes.js";
import type { TreeCheckout } from "./treeCheckout.js";

/**
 * An opaque process-local identity owned by one reference-enabled authority capture.
 * There is no encoding or reopening API. Constructed lookalikes are rejected.
 * @alpha
 */
export interface SharedTreeAuthorityNodeReference {
	readonly scope: "capture-local";
}

/** Result of registering a node from an admitted live or draft view. @alpha */
export type SharedTreeAuthorityReferenceResult =
	| { readonly kind: "tracked"; readonly reference: SharedTreeAuthorityNodeReference }
	| { readonly kind: "outsideCapture" };

/** A counterpart in the requested checkout, never a wrapper from another context. @alpha */
export type SharedTreeAuthorityNodeResolution =
	| {
			readonly kind: "node";
			readonly node: TreeNode;
			readonly status: "inDocument" | "removed";
	  }
	| { readonly kind: "absent" }
	| { readonly kind: "unavailable"; readonly reason: "destroyed" };

/** Opts in to bounded, eager node tracking for one capture. @alpha @input */
export interface SharedTreeAuthorityReferenceOptions {
	readonly trackNodeReferences: true;
	/** Counts all stored nodes, including leaves and retained removed trees. Default 10,000. */
	readonly maxNodes?: number;
	/** Maximum concurrently retained public reference drafts. Default 16. */
	readonly maxDrafts?: number;
}

interface ReferenceContext {
	readonly anchors: readonly Anchor[];
	readonly nodes: ReadonlyMap<AnchorNode, number>;
	readonly absent: ReadonlySet<number>;
	offDispose: () => void;
	sealed: boolean;
}

export function projectAuthorityCheckout(
	checkout: TreeCheckout,
	head: GraphCommit<SharedTreeChange>,
): void {
	const oldBranch = checkout.mainBranch;
	checkout.switchBranch(oldBranch.fork(head));
	oldBranch.dispose();
}

/** Identity bookkeeping only: no edit IDs, native IDs, path matching, or serialized node keys. */
export class AuthorityNodeReferences {
	private readonly contexts = new Map<TreeCheckout, ReferenceContext>();
	private readonly references: (SharedTreeAuthorityNodeReference | undefined)[] = [];
	private readonly indices = new Map<SharedTreeAuthorityNodeReference, number>();
	public readonly sequenced: TreeCheckout;
	private disposed = false;

	public constructor(
		private readonly live: TreeCheckout,
		sequencedHead: GraphCommit<SharedTreeChange>,
		private readonly maxDrafts: number,
		maxNodes: number,
	) {
		const liveAnchors = live.trackReferenceNodes(maxNodes);
		let fork: { checkout: TreeCheckout; anchors: Anchor[] } | undefined;
		let completed = false;
		try {
			fork = live.forkWithAnchors(liveAnchors);
			projectAuthorityCheckout(fork.checkout, sequencedHead);
			for (const [index, anchor] of fork.anchors.entries()) {
				assert(liveAnchors[index] !== undefined, "Fork correspondence must be complete");
				if (fork.checkout.forest.anchors.locate(anchor) === undefined) {
					this.references.push(undefined);
				} else {
					const reference: SharedTreeAuthorityNodeReference = Object.freeze({
						scope: "capture-local",
					});
					this.indices.set(reference, index);
					this.references.push(reference);
				}
			}
			this.sequenced = fork.checkout;
			this.register(live, liveAnchors);
			this.register(this.sequenced, fork.anchors);
			completed = true;
		} finally {
			if (!completed) {
				// A failed projection must not pin the live tree.
				for (const anchor of liveAnchors) {
					live.forest.anchors.forget(anchor);
				}
				if (fork !== undefined) {
					for (const anchor of fork.anchors) {
						fork.checkout.forest.anchors.forget(anchor);
					}
					if (!fork.checkout.disposed) {
						fork.checkout[disposeSymbol]();
					}
				}
			}
		}
	}

	private register(checkout: TreeCheckout, anchors: readonly Anchor[]): void {
		const nodes = new Map<AnchorNode, number>();
		const absent = new Set<number>();
		for (const [index, anchor] of anchors.entries()) {
			const node = checkout.forest.anchors.locate(anchor);
			if (node === undefined) {
				absent.add(index);
			} else {
				nodes.set(node, index);
			}
		}
		const context: ReferenceContext = {
			anchors,
			nodes,
			absent,
			offDispose: () => {},
			sealed: false,
		};
		this.contexts.set(checkout, context);
		context.offDispose = checkout.events.on("dispose", () => this.release(checkout));
	}

	private release(checkout: TreeCheckout): void {
		const context = this.contexts.get(checkout);
		if (context !== undefined) {
			context.offDispose();
			for (const anchor of context.anchors) {
				checkout.forest.anchors.forget(anchor);
			}
			this.contexts.delete(checkout);
		}
	}

	private context(checkout: TreeCheckout): ReferenceContext {
		if (this.disposed || this.live.disposed) {
			throw new UsageError("Capture node references have expired");
		}
		checkout.checkReferenceAccess();
		const context = this.contexts.get(checkout);
		if (context === undefined || context.sealed) {
			throw new UsageError("Expected a checkout owned by this reference capture");
		}
		return context;
	}

	public createDraft(head: GraphCommit<SharedTreeChange>): TreeCheckout {
		const source = this.context(this.sequenced);
		if (this.contexts.size - 2 >= this.maxDrafts) {
			throw new UsageError("Capture reference draft limit exceeded");
		}
		const fork = this.sequenced.forkWithAnchors(source.anchors);
		let completed = false;
		try {
			projectAuthorityCheckout(fork.checkout, head);
			this.register(fork.checkout, fork.anchors);
			completed = true;
			return fork.checkout;
		} finally {
			if (!completed) {
				for (const anchor of fork.anchors) {
					fork.checkout.forest.anchors.forget(anchor);
				}
				if (!fork.checkout.disposed) {
					fork.checkout[disposeSymbol]();
				}
			}
		}
	}

	public reference(node: TreeNode): SharedTreeAuthorityReferenceResult {
		this.context(this.live);
		if (!isTreeNode(node)) {
			throw new UsageError("Expected a TreeNode, not a native ID or serialized content");
		}
		const kernel = getKernel(node);
		if (!kernel.isHydrated()) {
			return { kind: "outsideCapture" };
		}
		const checkout = kernel.context.flexContext.checkout;
		const owned = [...this.contexts.keys()].find((candidate) => candidate === checkout);
		if (owned === undefined) {
			throw new UsageError("Source node belongs to another capture or checkout");
		}
		const context = this.context(owned);
		if (kernel.getStatus() === TreeStatus.Deleted || kernel.context.flexContext.isDisposed()) {
			throw new UsageError("Source node view or lifecycle has been disposed");
		}
		const index = context.nodes.get(kernel.anchorNode);
		if (index === undefined) {
			return { kind: "outsideCapture" };
		}
		const reference = this.references[index];
		if (reference === undefined) {
			return { kind: "outsideCapture" };
		}
		return { kind: "tracked", reference };
	}

	public resolve(
		reference: SharedTreeAuthorityNodeReference,
		checkout: TreeCheckout,
	): SharedTreeAuthorityNodeResolution {
		const context = this.context(checkout);
		const index = this.indices.get(reference);
		if (index === undefined) {
			throw new UsageError("Expected a node reference from this exact capture");
		}
		const view = checkout.forest.anchors.slots.get(SimpleContextSlot);
		if (view === undefined || view.flexContext.isDisposed()) {
			throw new UsageError("Reference resolution requires an active compatible target view");
		}
		if (context.absent.has(index)) {
			return { kind: "absent" };
		}
		const anchor = context.anchors[index];
		assert(anchor !== undefined, "Reference context must contain an anchor");
		const node = checkout.forest.anchors.locate(anchor);
		if (node === undefined) {
			return { kind: "unavailable", reason: "destroyed" };
		}
		const result = treeNodeFromAnchor(node);
		assert(isTreeNode(result), "Only non-leaf nodes can produce public node references");
		const status = getKernel(result).getStatus();
		assert(
			status === TreeStatus.InDocument || status === TreeStatus.Removed,
			"A located reference must be live or removed",
		);
		return {
			kind: "node",
			node: result,
			status: status === TreeStatus.InDocument ? "inDocument" : "removed",
		};
	}

	public dispose(): void {
		if (!this.disposed) {
			for (const checkout of this.contexts.keys()) {
				if (!checkout.disposed) {
					checkout.checkReferenceAccess();
				}
			}
			this.disposed = true;
			for (const checkout of this.contexts.keys()) {
				this.release(checkout);
				if (checkout !== this.live && checkout !== this.sequenced && !checkout.disposed) {
					checkout[disposeSymbol]();
				}
			}
			this.indices.clear();
			this.references.length = 0;
		}
	}

	public sealDraft(checkout: TreeCheckout): void {
		this.context(checkout).sealed = true;
	}
}
