/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import type { ErasedType } from "@fluidframework/core-interfaces/internal";
import { assert, fail } from "@fluidframework/core-utils/internal";
import type { MinimumVersionForCollab } from "@fluidframework/runtime-definitions/internal";
import { cleanedPackageVersion as runtimeUtilsCleanedPackageVersion } from "@fluidframework/runtime-utils/internal";
import type { Static, TAnySchema, TSchema } from "@sinclair/typebox";

import type { JsonCompatibleReadOnly } from "../util/index.js";

/**
 * Translates decoded data to encoded data.
 * @remarks Typically paired with an {@link IEncoder}.
 */
export interface IEncoder<TDecoded, TEncoded, TContext> {
	/**
	 * Encodes `obj` into some encoded format.
	 */
	encode(obj: TDecoded, context: TContext): TEncoded;
}

/**
 * Translates encoded data to decoded data.
 * @remarks Typically paired with an {@link IEncoder}.
 */
export interface IDecoder<TDecoded, TEncoded, TContext> {
	/**
	 * Decodes `obj` from some encoded format.
	 */
	decode(obj: TEncoded, context: TContext): TDecoded;
}

/**
 * Validates data complies with some particular schema.
 * Implementations are typically created by a {@link JsonValidator}.
 */
export interface SchemaValidationFunction<Schema extends TSchema> {
	/**
	 * Returns whether the data matches a schema.
	 */
	check(data: unknown): data is Static<Schema>;
}

/**
 * A kind of validator for SharedTree's internal data formats.
 * @remarks
 * Assuming no data corruption or type confusion, such validation should never fail.
 * Any client version compatibility issues should instead be detected by the data format versioning which Shared Tree does internally independent of data format validation.
 * However, persisted data can sometimes be corrupted, bugs can produce invalid data, or users can mix up which data is compatible with which APIs.
 * In such cases, a format validator can help catch issues.
 *
 * Current options are {@link FormatValidatorNoOp} and {@link FormatValidatorBasic}.
 * @privateRemarks
 * Implement using {@link toFormatValidator}.
 * Consume using {@link extractJsonValidator}.
 *
 * Exposing this as the stable API entry point (instead of {@link JsonValidator}) means that we avoid leaking the reference to TypeBox to the API surface.
 * Additionally, if we adopt non JSON formats, we can just update the validators as needed without breaking the API.
 * This also allows us to avoid stabilizing or documenting how handles interact with JSON validation since that is not exposed through this type.
 * @sealed @alpha
 */
export interface FormatValidator extends ErasedType<"FormatValidator"> {}

/**
 * A {@link JsonValidator} implementation which performs no validation and accepts all data as valid.
 * @privateRemarks Having this as an option unifies opting out of validation with selection of
 * validators, simplifying code performing validation.
 */
const noopValidator: JsonValidator = {
	compile: <Schema extends TSchema>() => ({ check: (data): data is Static<Schema> => true }),
};

/**
 * A {@link FormatValidator} which does no validation.
 * @alpha
 */
export const FormatValidatorNoOp = toFormatValidator(noopValidator);

/**
 * Type erase a {@link JsonValidator} to a {@link FormatValidator}.
 */
export function toFormatValidator(factory: JsonValidator): FormatValidator {
	return factory as unknown as FormatValidator;
}

/**
 * Un-type-erase the {@link FormatValidator}.
 */
export function extractJsonValidator(input: FormatValidator | JsonValidator): JsonValidator {
	return input as unknown as JsonValidator;
}

/**
 * JSON schema validator compliant with draft 6 schema. See https://json-schema.org.
 * @alpha @input
 */
export interface JsonValidator {
	/**
	 * Compiles the provided JSON schema into a validator for that schema.
	 * @param schema - A valid draft 6 JSON schema
	 * @remarks IFluidHandles--which have circular property references--are used in various places in SharedTree's persisted
	 * format. Handles should only be contained in sections of data which are validated against the empty schema `{}`
	 * (see https://datatracker.ietf.org/doc/html/draft-wright-json-schema-01#section-4.4).
	 *
	 * Implementations of `JsonValidator` must therefore tolerate these values, despite the input not being valid JSON.
	 */
	compile<Schema extends TSchema>(schema: Schema): SchemaValidationFunction<Schema>;
}

/**
 * Options relating to handling of persisted data.
 *
 * @see {@link CodecWriteOptions} for options that are specific to encoding data.
 * @alpha @input
 */
export interface ICodecOptions {
	/**
	 * {@link FormatValidator} which SharedTree uses to validate persisted data it reads & writes
	 * matches the expected encoded format (i.e. the wire format for ops and summaries).
	 * @remarks
	 * See {@link FormatValidatorNoOp} and {@link FormatValidatorBasic} for out-of-the-box implementations.
	 *
	 * This option is not "on-by-default" because JSON schema validation comes with a small but noticeable
	 * runtime performance cost, and popular schema validation libraries have relatively large bundle size.
	 *
	 * SharedTree users are still encouraged to use a non-trivial validator (i.e. not `FormatValidatorNoOp`)
	 * whenever reasonable: it gives better fail-fast behavior when unexpected encoded data is found,
	 * which reduces the risk of unrecoverable data corruption.
	 * @privateRemarks
	 * This property should probably be renamed to `validator` before stabilizing the API.
	 */
	readonly jsonValidator: FormatValidator;
}

/**
 * Options relating to encoding of persisted data.
 * @input @beta
 */
export interface CodecWriteOptionsBeta {
	/**
	 * The minimum version of the Fluid Framework client output must be encoded to be compatible with.
	 * @remarks
	 * This is used to ensure that the the output from this codec can be used with older versions of the Fluid Framework client.
	 * This includes both concurrent collaboration, and an older version opening the document later.
	 *
	 * Note that versions older than this should not result in data corruption if they access the data:
	 * the data's format should be versioned and if they can't handle the format they should error.
	 */
	readonly minVersionForCollab: MinimumVersionForCollab;
}

/**
 * Options relating to encoding of persisted data.
 * @remarks
 * Extends {@link ICodecOptions} with options that are specific to encoding data.
 * @alpha @input
 */
export interface CodecWriteOptions extends ICodecOptions, CodecWriteOptionsBeta {
	/**
	 * Overrides the version of the codec to use for encoding.
	 * @remarks
	 * Without an override, the selected version will be based on {@link CodecWriteOptionsBeta.minVersionForCollab}.
	 */
	readonly writeVersionOverrides?: ReadonlyMap<CodecName, FormatVersion>;

	/**
	 * If true, suppress errors when `writeVersionOverrides` selects a version which may not be compatible with the {@link CodecWriteOptionsBeta.minVersionForCollab}.
	 */
	readonly allowPossiblyIncompatibleWriteVersionOverrides?: boolean;
}

/**
 * `TEncodeContext` and `TDecodeContext` allow passing context to the codec which may configure how data is encoded/decoded.
 * `TDecodeContext` defaults to `TEncodeContext`; specify them separately when encode and decode need different context (for example, when encoding uses heuristics that are unneeded when decoding).
 * These parameters are typically used for:
 * - Codecs which can pick from multiple encoding options, and imbue the encoded data with information about which option was used.
 * The caller of such a codec can provide context about which encoding choice to make as part of the `encode` call without creating
 * additional codecs. Note that this pattern can always be implemented by having the caller create multiple codecs and selecting the
 * appropriate one, but depending on API layering this might be less ergonomic.
 * - Context for the object currently being encoded, which might enable more efficient encoding. When used in this fashion, the codec author
 * should be careful to include the context somewhere in the encoded data such that decoding can correctly round-trip.
 * For example, a composed set of codecs could implement a form of {@link https://en.wikipedia.org/wiki/Dictionary_coder | dictionary coding}
 * using a context map which was created by the top-level codec and passed to the inner codecs.
 * This pattern is used:
 * - To avoid repeatedly encoding session ids on commits (only recording it once at the top level)
 * @remarks `TEncoded` should always be valid Json (i.e. not contain functions), but due to TypeScript's handling
 * of index signatures and `JsonCompatibleReadOnly`'s index signature in the Json object case, specifying this as a
 * type-system level constraint makes code that uses this interface more difficult to write.
 *
 * If provided, `TValidate` allows the input type passed to `decode` to be different than `TEncoded`.
 * This is useful when, for example, the type being decoded is `unknown` and must be validated to be a `TEncoded` before being decoded to a `TDecoded`.
 */
export interface IJsonCodec<
	TDecoded,
	TEncoded = JsonCompatibleReadOnly,
	TValidate = TEncoded,
	TEncodeContext = void,
	TDecodeContext = TEncodeContext,
> extends IEncoder<TDecoded, TEncoded, TEncodeContext>,
		IDecoder<TDecoded, TValidate, TDecodeContext> {
	encodedSchema?: TAnySchema;
}

/**
 * Part of a codec.
 * @remarks
 * Encode and decode logic and schema for some chunk of data.
 * Can be composed into larger codecs, and eventually versioned at the top level using
 * {@link VersionDispatchingCodecBuilder}.
 *
 * This portion of a codec is not responsible for managing versioning or validation of the data against the schema.
 */
export interface JsonCodecPart<
	TDecoded,
	TEncodedSchema extends TAnySchema,
	TEncodeContext = void,
	TDecodeContext = TEncodeContext,
> extends IEncoder<TDecoded, Static<TEncodedSchema>, TEncodeContext>,
		IDecoder<TDecoded, Static<TEncodedSchema>, TDecodeContext> {
	/**
	 * TypeBox schema which describes the encoded format for this chunk of data.
	 * @remarks
	 * The user of this codec can use this to build its own larger schema,
	 * until eventually it is provided to the {@link VersionDispatchingCodecBuilder}.
	 */
	encodedSchema: TEncodedSchema;
}

/**
 * Type erase the more detailed encoded type from a codec.
 */
export function eraseEncodedType<
	TDecoded,
	TEncoded = JsonCompatibleReadOnly,
	TValidate = TEncoded,
	TEncodeContext = void,
	TDecodeContext = TEncodeContext,
>(
	codec: IJsonCodec<TDecoded, TEncoded, TValidate, TEncodeContext, TDecodeContext>,
): IJsonCodec<TDecoded, TValidate, TValidate, TEncodeContext, TDecodeContext> {
	return codec as unknown as IJsonCodec<
		TDecoded,
		TValidate,
		TValidate,
		TEncodeContext,
		TDecodeContext
	>;
}

/**
 * Represents a family of codecs that can be used to encode and decode data in different formats.
 * The family is identified by a format version, which is typically used to select the codec to use.
 *
 * Separating codecs into families rather than having a single codec support multiple versions (i.e. currying
 * the `formatVersion` parameter)
 * allows avoiding some duplicate work at encode/decode time, since the vast majority of document usage will not
 * involve mixed format versions.
 *
 * @privateRemarks
 * Encode and decode can be parameterized independently — the encode-side context type need not equal the decode-side context type.
 * `TDecodeContext` defaults to `TEncodeContext` so callers that share a single context shape (the common case) don't need to specify it.
 */
export interface ICodecFamily<
	TDecoded,
	TEncodeContext = void,
	TDecodeContext = TEncodeContext,
> {
	/**
	 * @returns a codec that can be used to encode and decode data in the specified format.
	 * @throws if the format version is not supported by this family.
	 * @remarks Implementations should typically emit telemetry (either indirectly by throwing a well-known error with
	 * logged properties or directly using some logger) when a format version is requested that is not supported.
	 * This ensures that applications can diagnose compatibility issues.
	 */
	resolve(
		formatVersion: FormatVersion,
	): IJsonCodec<
		TDecoded,
		JsonCompatibleReadOnly,
		JsonCompatibleReadOnly,
		TEncodeContext,
		TDecodeContext
	>;

	/**
	 * @returns an iterable of all format versions supported by this family.
	 */
	getSupportedFormats(): Iterable<FormatVersion>;
}

/**
 * A version stamp for encoded data.
 * @remarks
 * Strings are used for formats that are not yet officially supported.
 * When such formats become officially supported/stable, they will be switched to using a number.
 * Undefined is tolerated to enable the scenario where data was not initially versioned.
 * @alpha
 */
export type FormatVersion = number | string | undefined;

/**
 * A unique name given to this codec family.
 * @remarks
 * This is not persisted: it is only used to specify version overrides and in errors.
 * @alpha
 */
export type CodecName = string;

/**
 * A format version which is dependent on some parent format version.
 */
export interface DependentFormatVersion<
	TParentVersion extends FormatVersion = FormatVersion,
	TChildVersion extends FormatVersion = FormatVersion,
> {
	/**
	 * Looks up the child format version for a given parent format version.
	 * @param parent - The parent format version.
	 * @returns The corresponding child format version.
	 */
	lookup(parent: TParentVersion): TChildVersion;
}

export class UniqueDependentFormatVersion<TChildVersion extends FormatVersion>
	implements DependentFormatVersion<FormatVersion, TChildVersion>
{
	public constructor(private readonly child: TChildVersion) {}
	public lookup(_parent: FormatVersion): TChildVersion {
		return this.child;
	}
}

export class MappedDependentFormatVersion<
	TParentVersion extends FormatVersion = FormatVersion,
	TChildVersion extends FormatVersion = FormatVersion,
> implements DependentFormatVersion<TParentVersion, TChildVersion>
{
	public constructor(private readonly map: ReadonlyMap<TParentVersion, TChildVersion>) {}
	public lookup(parent: TParentVersion): TChildVersion {
		return this.map.get(parent) ?? fail(0xc73 /* Unknown parent version */);
	}
}

export const DependentFormatVersion = {
	fromUnique: <TChildVersion extends FormatVersion>(
		child: TChildVersion,
	): UniqueDependentFormatVersion<TChildVersion> => new UniqueDependentFormatVersion(child),
	fromMap: <TParentVersion extends FormatVersion, TChildVersion extends FormatVersion>(
		map: ReadonlyMap<TParentVersion, TChildVersion>,
	): MappedDependentFormatVersion<TParentVersion, TChildVersion> =>
		new MappedDependentFormatVersion(map),
	fromPairs: <TParentVersion extends FormatVersion, TChildVersion extends FormatVersion>(
		pairs: Iterable<[TParentVersion, TChildVersion]>,
	): MappedDependentFormatVersion<TParentVersion, TChildVersion> =>
		new MappedDependentFormatVersion(new Map(pairs)),
};

/**
 * Creates a codec family from a registry of codecs.
 */
export function makeCodecFamily<TDecoded, TEncodeContext, TDecodeContext = TEncodeContext>(
	registry: Iterable<
		[
			formatVersion: FormatVersion,
			codec: IJsonCodec<
				TDecoded,
				JsonCompatibleReadOnly,
				JsonCompatibleReadOnly,
				TEncodeContext,
				TDecodeContext
			>,
		]
	>,
): ICodecFamily<TDecoded, TEncodeContext, TDecodeContext> {
	const codecs: Map<
		FormatVersion,
		IJsonCodec<
			TDecoded,
			JsonCompatibleReadOnly,
			JsonCompatibleReadOnly,
			TEncodeContext,
			TDecodeContext
		>
	> = new Map();
	for (const [formatVersion, codec] of registry) {
		if (codecs.has(formatVersion)) {
			fail(0xabf /* Duplicate codecs specified. */);
		}
		codecs.set(formatVersion, codec);
	}

	return {
		resolve(
			formatVersion: FormatVersion,
		): IJsonCodec<
			TDecoded,
			JsonCompatibleReadOnly,
			JsonCompatibleReadOnly,
			TEncodeContext,
			TDecodeContext
		> {
			const codec = codecs.get(formatVersion);
			assert(codec !== undefined, 0x5e6 /* Requested codec for unsupported format. */);
			return codec;
		},
		getSupportedFormats(): Iterable<FormatVersion> {
			return codecs.keys();
		},
	};
}

/**
 * Codec for objects which carry no information.
 */
export const unitCodec: IJsonCodec<
	0,
	JsonCompatibleReadOnly,
	JsonCompatibleReadOnly,
	unknown
> = {
	encode: () => 0,
	decode: () => 0,
};

/**
 * Wraps a codec with JSON schema validation for its encoded type.
 * @returns An {@link IJsonCodec} which validates the data it encodes and decodes matches the provided schema.
 * @remarks
 * Eventually all codecs should use the same pattern implemented by VersionDispatchingCodecBuilder, resulting in that having the only use of this API.
 */
export function withSchemaValidation<
	TInMemoryFormat,
	EncodedSchema extends TSchema,
	TEncodedFormat,
	TValidate,
	TEncodeContext,
	TDecodeContext = TEncodeContext,
>(
	schema: EncodedSchema,
	codec: IJsonCodec<
		TInMemoryFormat,
		TEncodedFormat,
		TValidate,
		TEncodeContext,
		TDecodeContext
	>,
	validator?: JsonValidator | FormatValidator,
): IJsonCodec<TInMemoryFormat, TEncodedFormat, TValidate, TEncodeContext, TDecodeContext> {
	if (!validator) {
		return codec;
	}
	const compiledFormat = extractJsonValidator(validator).compile(schema);
	return {
		encode: (obj: TInMemoryFormat, context: TEncodeContext): TEncodedFormat => {
			const encoded = codec.encode(obj, context);
			if (!compiledFormat.check(encoded)) {
				fail(0xac0 /* Encoded data should validate */);
			}
			return encoded;
		},
		decode: (encoded: TValidate, context: TDecodeContext): TInMemoryFormat => {
			if (!compiledFormat.check(encoded)) {
				fail(0xac1 /* Data being decoded should validate */);
			}
			return codec.decode(encoded, context);
		},
		encodedSchema: schema,
	};
}

/**
 * Versions of Fluid Framework client packages, usable as a {@link @fluidframework/runtime-definitions#MinimumVersionForCollab}.
 * @remarks
 * Versions with no notable impact may be omitted, and added later if needed.
 *
 * @privateRemarks
 * Each entry should document:
 * - The user-facing impact of opting into it (e.g. encoding efficiency improvements).
 * - Any new data formats introduced in that version.
 * - Whether those features/formats are enabled by default or require {@link MinimumVersionForCollab | minVersionForCollab} to be set accordingly.
 * @alpha
 */
export const FluidClientVersion = {
	/**
	 * Fluid Framework Client 2.0 and newer.
	 */
	v2_0: "2.0.0",

	/**
	 * Fluid Framework Client 2.43 and newer.
	 * @remarks
	 * New formats introduced in 2.43:
	 * - SchemaFormatVersion.v2 - written when minVersionForCollab \>= 2.43
	 * - MessageFormatVersion.v4 - written when minVersionForCollab \>= 2.43
	 * - EditManagerFormatVersion.v4 - written when minVersionForCollab \>= 2.43
	 * - sequence-field/formatV3 - written when minVersionForCollab \>= 2.43
	 */
	v2_43: "2.43.0",

	/**
	 * Fluid Framework Client 2.52 and newer.
	 * @remarks
	 * New formats introduced in 2.52:
	 * - DetachedFieldIndexFormatVersion.v2 - written when minVersionForCollab \>= 2.52
	 */
	v2_52: "2.52.0",

	/**
	 * Fluid Framework Client 2.73 and newer.
	 * @remarks
	 * New formats introduced in 2.73:
	 * - FieldBatchFormatVersion.v2 - written when minVersionForCollab \>= 2.73
	 */
	v2_73: "2.73.0",

	/**
	 * Fluid Framework Client 2.74 and newer.
	 * @remarks
	 * New formats introduced in 2.74:
	 * - SharedTreeSummaryFormatVersion.v2 - written by default
	 * - DetachedFieldIndexSummaryFormatVersion.v2 - written by default
	 * - SchemaSummaryFormatVersion.v2 - written by default
	 * - EditManagerSummaryFormatVersion.v2 - written by default
	 * - ForestSummaryFormatVersion.v2 - written by default
	 * - ForestFormatVersion.v2 - written when minVersionForCollab \>= 2.74
	 * - ForestSummaryFormatVersion.v3 - written when minVersionForCollab \>= 2.74
	 */
	v2_74: "2.74.0",

	/**
	 * Fluid Framework Client 2.80 and newer.
	 * @remarks
	 * New formats introduced in 2.80:
	 * - MessageFormatVersion.v6 - written when minVersionForCollab \>= 2.80
	 * - EditManagerFormatVersion.v6 - written when minVersionForCollab \>= 2.80
	 * - SharedTreeChangeFormatVersion.v5 - written when minVersionForCollab \>= 2.80
	 * - ModularChangeFormatVersion.v5 - written when minVersionForCollab \>= 2.80
	 */
	v2_80: "2.80.0",
} as const satisfies Record<string, MinimumVersionForCollab>;

/**
 * An up to date version which includes all stable features.
 * @remarks
 * Use for cases when data is not persisted and thus would only ever be read by the the same version of the code which read this value.
 *
 * The pkgVersion from this package (tree) can not be used here as it is not guaranteed to be a valid MinimumVersionForCollab
 * and would also unexpectedly disable features in prereleases and on CI if it didn't fail validation.
 * See {@link @fluidframework/runtime-utils/internal#cleanedPackageVersion} for more details on why cleanedPackageVersion is preferred over pkgVersion.
 *
 * @privateRemarks
 * It is safe to use CleanedPackageVersion from runtime-utils here since features are enabled in minor versions,
 * and this package (tree) depends on runtime-utils with a `~` semver range
 * ensuring that the version of runtime-utils this was imported from will match the version of this (tree) package at least up to the minor version.
 * Reusing this from runtime-utils avoids duplicating the cleanup logic here as well as the cost or recomputing it.
 * If in the future for some reason this becomes not okay, runtime-utils could instead export a function that performs that cleanup logic which could be reused here.
 */
export const currentVersion: MinimumVersionForCollab = runtimeUtilsCleanedPackageVersion;

/**
 * TODO:
 * This needs to be documented.
 * Its documentation should cover at least the following:
 * - Is this used for anything other than testing.
 * - What should be included as children. For example should it include versioned codecs which dispatch base on the min version for collaboration? If so, what version of them should be used?
 * - What risks does having this mitigate?
 */
export interface CodecTree<TFormatVersion extends FormatVersion = FormatVersion> {
	readonly name: string;
	readonly version: TFormatVersion;
	readonly children?: readonly CodecTree[];
}

export function jsonableCodecTree(tree: CodecTree): JsonCompatibleReadOnly {
	return {
		name: tree.name,
		version: tree.version ?? "null",
		children: tree.children?.map(jsonableCodecTree),
	};
}
