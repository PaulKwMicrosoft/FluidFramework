/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import { assert } from "@fluidframework/core-utils/internal";
import type { IIdCompressor, StableId } from "@fluidframework/id-compressor";
import { isFinalId, isStableId } from "@fluidframework/id-compressor/internal";

import type { CodecAndSchema, IJsonCodec } from "../../codec/index.js";
import type { EncodedRevisionTag, RevisionTagCodec, RevisionTag } from "../rebase/index.js";

import { makeDetachedFieldIndexCodecFromMajorCodec } from "./detachedFieldIndexCodecCommon.js";
import { DetachedFieldIndexFormatVersion } from "./detachedFieldIndexFormatCommon.js";
import { StableOrFinalRevisionTag } from "./detachedFieldIndexFormatV2.js";
import type { DetachedFieldSummaryData, Major } from "./detachedFieldIndexTypes.js";

class MajorCodec implements IJsonCodec<Major> {
	public constructor(
		private readonly revisionTagCodec: RevisionTagCodec,
		private readonly idCompressor: IIdCompressor,
	) {}

	public encode(major: Major): EncodedRevisionTag | StableId {
		assert(major !== undefined, 0xbfb /* Unexpected undefined revision */);
		const id = this.revisionTagCodec.encode(major);

		if (id !== "root" && !isFinalId(id)) {
			/**
			 * This code path handles the case where the major revision is not finalized.
			 * This can happen the SharedTree is being attached to an already attached container.
			 */
			assert(major !== "root", 0xbfc /* Major revision cannot be 'root' */);
			const long = this.idCompressor.decompress(major);
			return long;
		}
		return id;
	}

	public decode(major: EncodedRevisionTag | StableId): RevisionTag {
		assert(
			major === "root" ||
				(typeof major === "string" && isStableId(major)) ||
				(typeof major === "number" && isFinalId(major)),
			0xbfd /* Expected root, stable, or final compressed id */,
		);
		if (typeof major === "string" && isStableId(major)) {
			return this.idCompressor.recompress(major);
		}
		return this.revisionTagCodec.decode(major, {
			originatorId: this.revisionTagCodec.localSessionId,
			idCompressor: this.idCompressor,
			revision: undefined,
			// DetachedFieldIndex codecs are only used by the summarizer.
			isSummary: true,
		});
	}
}

export function makeDetachedNodeToFieldCodecV2(
	revisionTagCodec: RevisionTagCodec,
	idCompressor: IIdCompressor,
): CodecAndSchema<DetachedFieldSummaryData> {
	const majorCodec = new MajorCodec(revisionTagCodec, idCompressor);
	return makeDetachedFieldIndexCodecFromMajorCodec(
		majorCodec,
		DetachedFieldIndexFormatVersion.v2,
		StableOrFinalRevisionTag,
	);
}
