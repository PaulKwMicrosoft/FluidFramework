/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import type { IIdCompressor } from "@fluidframework/id-compressor";
import { lowestMinVersionForCollab } from "@fluidframework/runtime-utils/internal";

import {
	VersionDispatchingCodecBuilder,
	FluidClientVersion,
	type ICodecOptions,
} from "../../codec/index.js";
import type { RevisionTagCodec } from "../rebase/index.js";

import { makeDetachedNodeToFieldCodecV1 } from "./detachedFieldIndexCodecV1.js";
import { makeDetachedNodeToFieldCodecV2 } from "./detachedFieldIndexCodecV2.js";
import { DetachedFieldIndexFormatVersion } from "./detachedFieldIndexFormatCommon.js";

type BuildData = ICodecOptions & {
	readonly revisionTagCodec: RevisionTagCodec;
	readonly idCompressor: IIdCompressor;
};

export const detachedFieldIndexCodecBuilder = VersionDispatchingCodecBuilder.build(
	"DetachedFieldIndex",
	[
		{
			minVersionForCollab: lowestMinVersionForCollab,
			formatVersion: DetachedFieldIndexFormatVersion.v1,
			codec: (buildData: BuildData) =>
				makeDetachedNodeToFieldCodecV1(buildData.revisionTagCodec, buildData.idCompressor),
		},
		{
			minVersionForCollab: FluidClientVersion.v2_52,
			formatVersion: DetachedFieldIndexFormatVersion.v2,
			codec: (buildData: BuildData) =>
				makeDetachedNodeToFieldCodecV2(buildData.revisionTagCodec, buildData.idCompressor),
		},
	],
);
