/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import { assert } from "@fluidframework/core-utils/internal";

import type { FieldKey } from "../../core/index.js";
import { FieldKinds } from "../../feature-libraries/index.js";
import { brand } from "../../util/index.js";
import {
	createField,
	type UnhydratedFlexTreeField,
	normalizeAllowedTypes,
	type FlexContent,
} from "../core/index.js";
import { getUnhydratedContext } from "../createContext.js";
import {
	unhydratedFlexTreeFromInsertableNode,
	type InsertableContent,
} from "../unhydratedFlexTreeFromInsertable.js";

import type { MapNodeSchema } from "./map/index.js";
import type { RecordNodeSchema } from "./record/index.js";

/**
 * Utilities shared by multiple node kinds.
 */

/**
 * Converts record-like data to a FlexContent representation for map/record schema.
 */
export function recordLikeDataToFlexContent(
	fieldsIterator: Iterable<readonly [string, InsertableContent]>,
	schema: MapNodeSchema | RecordNodeSchema,
): FlexContent {
	const allowedChildTypes = normalizeAllowedTypes(schema.info);
	const context = getUnhydratedContext(schema).flexContext;

	const transformedFields = new Map<FieldKey, UnhydratedFlexTreeField>();
	for (const item of fieldsIterator) {
		const [key, value] = item;
		assert(!transformedFields.has(brand(key)), 0x84c /* Keys should not be duplicated */);

		// Omit undefined values - an entry with an undefined value is equivalent to one that has been removed or omitted
		if (value !== undefined) {
			const child = unhydratedFlexTreeFromInsertableNode(
				value,
				allowedChildTypes.evaluateSet(),
			);
			const field = createField(context, FieldKinds.optional.identifier, brand(key), [child]);
			transformedFields.set(brand(key), field);
		}
	}

	return [
		{
			type: brand(schema.identifier),
		},
		transformedFields,
	];
}
