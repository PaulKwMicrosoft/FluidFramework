# Restricted external-authority SharedTree prototype

This source-aligned prototype starts at Fluid 2.111.0 release commit
`7c3fc51d5d204a16299014921e93d522590a4af2`. It is **not** the user's
`2.74.0-370705` Detach/Attach build. This revision additionally ports the public
detached-root foundation at `1b49fc989e3d844cb7fc7c50d3df59d27c5ac702`, with
2.111 conflict resolutions and higher-level reinsertion support described below.
Normal mode retains its existing wire format and editing API behavior.

## Opt in

```ts
import {
    configuredSharedTreeAlpha,
    getSharedTreeAuthority,
} from "@fluidframework/tree/alpha";

const AuthorityTree = configuredSharedTreeAlpha({
    minVersionForCollab: "2.80.0",
    externalAuthority: {
        documentEpoch: "document-incarnation",
        authorityId: "trusted-bridge",
        authorityEpoch: "authority-incarnation",
    },
});
```

All clients must use this configuration. Authority trees deliberately use a
different DDS type, ending in `/external-authority-v2`. This is a new experimental
protocol, not wire-compatible with an unmodified tree. The Fluid ordering service
is unchanged. IDs and epochs provide fencing; **they do not authenticate writers**.
Every writer in this prototype is trusted and can access the controller.
Version 2 adds an explicit authoring-base revision to authority advances and
supports atomic prefix settlement plus correction. Its bootstrap and message
envelopes also use version 2. Use fresh containers: r2/r3/r4 version-1 documents
are not an in-place upgrade target, even if an application supplies matching labels.

## Controller

`getSharedTreeAuthority(tree)` exposes:

* `capture()` — a consistent immutable approved checkpoint, ordered stable
  `editIds`, `exportApproved()` and `exportSequenced()` snapshots. The latter is
  **A+P**, never A+P+L. Snapshots are real checkout forks with history diffs applied
  to their forests, schemas and removed-root indexes. They do not follow live edits.
* `createDraft(capture)` — a private fork at **A**, edited with ordinary
  `draft.viewWith(configuration)` and typed tree operations. It does not submit
  ordinary Fluid operations.
* `createDraft(capture, { afterPrefix: k })` — a private fork at **captured A plus
  exactly the first k captured P revisions**. It excludes the remaining captured
  P, later sequenced work, and L. Publishing this draft must use the same capture
  object and `approvePrefix: k`.
* `publishAdvance({ batchId, nextCheckpoint, capture, approvePrefix?, draft? })`
  — publishes one authority message. The promise reports `"applied"`,
  `"duplicate"` or `"stale"` only after normal sequenced self-echo.
* `onStateChanged(listener)` — notification after sequenced processing; returns
  an unsubscribe function.

An unchanged `approvePrefix`, an A-based external draft, and a prefix-based
correction are supported. A plain A-based draft combined with positive approval
is still rejected: it was authored on the wrong history. Publishing seals the
draft for further publication. Complete any
open draft transaction before publishing. Dispose drafts/captures when no longer
needed. Snapshots use SharedTree's existing `VerboseTree` format; the authority
controller does not perform package serialization or application-level merging.

Example unchanged-prefix settlement:

```ts
const authority = getSharedTreeAuthority(tree);
const cut = authority.capture();
const outcome = await authority.publishAdvance({
    batchId: "unique-external-batch",
    nextCheckpoint: "unique-approved-checkpoint",
    capture: cut,
    approvePrefix: cut.editIds.length,
});
cut.dispose();
```

Example accepted-prefix settlement with an authoritative correction:

```ts
const cut = authority.capture();
const k = cut.editIds.length; // Or an explicitly accepted leading prefix.
const correction = authority.createDraft(cut, { afterPrefix: k });
const correctedView = correction.viewWith(configuration);
// Apply typed authoritative normalization to correctedView, whose base is A + P[0:k].
const outcome = await authority.publishAdvance({
    batchId: "unique-normalized-acceptance",
    nextCheckpoint: "unique-approved-checkpoint",
    capture: cut,
    approvePrefix: k,
    draft: correction,
});
correction.dispose();
cut.dispose();
```

The accepted prefix is **not replaced**. Let B be its actual history head and C
be the draft's newly authored corrections. The new approved history is B followed
by C, with all accepted revisions preserved and fresh revision identities for C.
The remaining P suffix rebases over C, then L rebases over that new sequenced
history. The transition is emitted once through the checkout's rebase event.
Even an empty/no-net correction does not settle any edits outside the selected
prefix. No authoring context is reconstructed from `VerboseTree` or JSON.

The wire advance carries B's stable revision as `authoringBase`, in addition to
the approved checkpoint and exact prefix IDs. Sequenced processing validates
that these resolve to the same actual history before appending corrections.
Later ordinary edits do not invalidate a cut; a competing authority advance
does. A capture of an earlier pre-attach A is also rejected if initialization
changed A while the checkpoint remained `"initial"`. Malformed wire contexts
fail closed through the existing SharedTree error/breaker mechanism.

Attach/initialize the tree and approve its initialization before authoring
external drafts. Schema evolution after the first authority advance is rejected.
For an external draft, capture A, create the draft, edit it, then publish it using
the same capture. An intervening authority advance makes that publication stale.
If external acceptance has already occurred, reconciliation is required; do not
silently recapture or reauthor the accepted attempt. Ordinary optimistic edits
may continue concurrently.

## What actually changes

* `shared-tree-core/editManager.ts` retains original Fluid-reference checkpoints
  **T**, plus separate approved **A**, sequenced provisional **P** and local **L**
  history roles. Historical sequence mappings are not rewritten when A advances.
* Peer reconstruction rebases a sender's pending branch onto its original T
  checkpoint, not a new interpretation of the old reference.
* An external draft extends A, or its explicitly accepted prefix. Existing rebasers
  transform the remaining P over the new A, then
  L over that new sequenced trunk. Live checkout observers receive the resulting
  transition through the existing rebase event, not a silent `setHead`.
* `sharedTreeCore.ts` wraps existing change codecs in one versioned authority
  envelope. Draft changes retain revision/session/compressor context and are
  enriched using their actual draft checkout. Fluid acknowledgment still retires
  ordinary retransmission; authority approval retires P separately.
* `externalAuthorityController.ts` provides capture, ordinary draft editing and
  publication without exposing changeset internals or a second application queue.
* Authority-mode undo resolves the original stable revision in the **current
  semantic history** before inversion. Inverting the old retained authoring
  commit instead would restore an obsolete pre-authority value. This opt-in
  behavior is propagated to forks; normal-mode undo is unchanged.

## Deliberate limits

* **No runtime summaries.** Attach/bootstrap summaries use existing machinery;
  runtime summaries after sequenced authority-mode work fail explicitly. Do not
  enable production summarization or claim durable reopen/replay support.
  Pre-attach seed edits become the approved baseline with P empty. Bootstrap
  summaries persist all three configured authority labels; loading checks them
  before loading tree state. Wrong/missing labels or loading an authority summary
  with an ordinary factory fails explicitly. Older experimental summaries without
  this metadata are deliberately unsupported, rather than silently reinterpreted.
  Matching-label bootstrap load is tested using a separately deserialized
  IdCompressor. This does not establish later authority-history recovery.
* All history, removed-root retention and authority deduplication records are
  retained without a bound. This is for bounded experiments, not production GC.
* Reconnect/resubmit of ordinary work and an authority publication have dedicated
  real-client tests. Persisted pending-state replay and summary reconstruction are
  not thereby proved.
* No non-prefix subset acceptance, revision-discarding transformed/coalesced
  replacement, rejection rollback,
  arbitrary historical base authoring, authority election, or cryptographic
  authorization. Duplicate batch IDs with different content are protocol errors.
* No shared branches or schema evolution. Required-field vacancy and required-field
  reinsertion remain unsupported. Same-object sequence/optional reinsertion is an
  additional explicit opt-in in this revision, not enabled by authority mode alone.
* Existing move and removal/undo identity are tested across authority rebases.
  That is not a substitute for general Detach/Attach.
* Conflicting-write undo/redo is tested across repeated authority advances.
  Accepted-prefix corrections are later authoritative edits, not rewritten
  versions of accepted edits and not entries in the user's undo stack. Undo of
  an accepted revision uses ordinary selective-undo semantics through later
  corrections; it is not a grouped undo of the acceptance plus normalization.
  The conflicting-field case is compared against an ordinary SharedTree history.
  An accepted detach transaction can be undone/redone while retaining later
  normalized node content and per-client identity. This does not establish undo
  semantics for future settlement that discards or replaces revisions.

## Optional detached-root editing

Add `enableDetachedRootEditing: true` to the factory configuration on **every**
participant. The resulting authority DDS type ends in
`/detached-roots-v1/external-authority-v2`, distinct from the authority-only type.
Use a fresh experimental container; do not reinterpret an existing association.

Removed hydrated roots can be supplied to ordinary array `insertAt*` methods
or assigned to optional fields. They retain identity on the originating and
remote clients. Fields under removed nodes can be edited before reinsertion.
This uses detached-root renames/attachments in real changesets, not JSON copies
or delete-undo emulation.

Only roots from the same live checkout are accepted. Duplicate roots in one
insertion, fresh/detached mixtures, and required-field reinsertion fail explicitly.
Reusing removed children inside newly constructed enclosing objects is not
implemented by this port. This is therefore **not full parity** with every
capability of the older experimental package.

The port also fixes the public branch's v3 encoder rejecting detached-root edits
without a field-owned detach location. Such root edits are encoded separately
by v3; older codecs continue rejecting unrepresentable global root edits.

`src/test/shared-tree/detachedReinsertion.spec.ts` checks independent clients,
concurrent reattachments and edits, removed-node edits, stable object identity,
and combined authority/P/L processing. The combined traces retain original P
identities, rebase pending detach/attach over external history, approve the same
P edits, undo against the new approved history, and decode delayed ordinary
operations in their original sender context.

## Validation

From the Fluid workspace, using its existing pnpm toolchain:

```powershell
$env:JS_DEVMAIN_USE_SYSTEM_TOOLS = '1'
pnpm --filter @fluidframework/tree run build:esnext
pnpm --filter @fluidframework/tree run build:test:esm
pnpm --filter @fluidframework/tree run test:mocha:esm -- --grep 'external authority'
```

The suite is `src/test/shared-tree/externalAuthority.spec.ts`. It uses actual
independent SharedTree clients and compressors and compares tree content,
observable atomic transitions and hydrated object identity. It includes the
decisive order reversal (Fluid P writes 1, external A writes 2, rebased P still
wins with 1), old-reference sender predecessors, local L, immutable cuts,
prefix/dedup/stale handling, undo, reconnect/resubmit, mixed runtime batches,
explicit summary rejection and unsupported editing boundaries.

`src/test/shared-tree/atomicAuthoritySettlement.spec.ts` additionally covers
prefix-based normalization, later P/L, original sender contexts, no-net
obligations, removed roots, corrective detach/reattach, undo/redo ancestry,
duplicates, reconnect, stale publication, invalid prefix/capture/base combinations
and protocol-version fencing. These are real DDS instances using existing mock
ordering infrastructure, **not AFR or OCS executions**.
