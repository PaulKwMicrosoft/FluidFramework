/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ImplicitFieldSchema, ITree, TreeView, TreeViewConfiguration, VerboseTree } from "../simple-tree/index.js";
/**
 * An immutable, internally consistent A and A+P cut. It never includes local unsequenced work.
 * @alpha
 */
export interface SharedTreeAuthorityCapture {
    readonly checkpoint: string;
    readonly editIds: readonly string[];
    exportApproved(): VerboseTree | undefined;
    exportSequenced(): VerboseTree | undefined;
    dispose(): void;
}
/**
 * A private, ordinary editable fork of the capture's approved history.
 * Edits do not submit Fluid operations until published as one authority advance.
 * @alpha
 */
export interface SharedTreeAuthorityDraft {
    viewWith<TRoot extends ImplicitFieldSchema>(configuration: TreeViewConfiguration<TRoot>): TreeView<TRoot>;
    dispose(): void;
}
/**
 * Exactly one unchanged prefix approval OR an externally authored draft is supported.
 * Approval and transformed replacement together are deliberately unsupported.
 * @alpha @input
 */
export interface SharedTreeAuthorityPublication {
    readonly batchId: string;
    readonly nextCheckpoint: string;
    readonly capture: SharedTreeAuthorityCapture;
    readonly approvePrefix?: number;
    readonly draft?: SharedTreeAuthorityDraft;
}
/**
 * Restricted v1 authority controller. All clients/writers must be trusted.
 * History is retained without bound; runtime summaries are explicitly unsupported.
 * @alpha
 */
export interface SharedTreeAuthorityController {
    capture(): SharedTreeAuthorityCapture;
    createDraft(capture: SharedTreeAuthorityCapture): SharedTreeAuthorityDraft;
    publishAdvance(publication: SharedTreeAuthorityPublication): Promise<"applied" | "duplicate" | "stale">;
    onStateChanged(listener: () => void): () => void;
}
/**
 * Gets the restricted experimental controller of an explicitly opted-in tree.
 * This is not an authorization boundary: every Fluid writer is trusted.
 * @alpha
 */
export declare function getSharedTreeAuthority(tree: ITree): SharedTreeAuthorityController;
//# sourceMappingURL=externalAuthorityController.d.ts.map