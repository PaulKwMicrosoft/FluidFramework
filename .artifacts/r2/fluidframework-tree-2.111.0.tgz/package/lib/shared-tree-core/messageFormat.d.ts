/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type Values } from "../util/index.js";
/**
 * The format version for the message.
 */
export declare const MessageFormatVersion: {
    readonly undefined: import("../util/brand.js").Brand<0, "MessageFormatVersion">;
    readonly v1: import("../util/brand.js").Brand<1, "MessageFormatVersion">;
    readonly v2: import("../util/brand.js").Brand<2, "MessageFormatVersion">;
    readonly v3: import("../util/brand.js").Brand<3, "MessageFormatVersion">;
    readonly v4: import("../util/brand.js").Brand<4, "MessageFormatVersion">;
    readonly v5: import("../util/brand.js").Brand<5, "MessageFormatVersion">;
    readonly v6: import("../util/brand.js").Brand<6, "MessageFormatVersion">;
    readonly vSharedBranches: import("../util/brand.js").Brand<"shared-branches|v0.1", "MessageFormatVersion">;
};
export type MessageFormatVersion = Values<typeof MessageFormatVersion>;
export declare const supportedMessageFormatVersions: ReadonlySet<MessageFormatVersion>;
//# sourceMappingURL=messageFormat.d.ts.map