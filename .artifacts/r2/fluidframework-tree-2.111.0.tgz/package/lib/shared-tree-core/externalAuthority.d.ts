/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { GraphCommit, RevisionTag } from "../core/index.js";
/**
 * Opt-in experimental authority protocol. All writers are trusted in this prototype.
 * Identity/epoch checks are fencing, not authentication.
 * @alpha @input
 */
export interface ExternalAuthorityConfiguration {
    readonly documentEpoch: string;
    readonly authorityId: string;
    readonly authorityEpoch: string;
}
export interface AuthorityEnvelope {
    readonly externalAuthorityVersion: 1;
    readonly configuration: ExternalAuthorityConfiguration;
    readonly kind: "ordinary" | "advance";
    readonly content: unknown;
}
export interface EncodedAdvance {
    readonly batchId: string;
    readonly expected: string;
    readonly next: string;
    readonly approvedPrefix: readonly string[];
    readonly commits: readonly unknown[];
}
export declare function readAuthorityEnvelope(content: unknown, expected: ExternalAuthorityConfiguration): AuthorityEnvelope;
export declare function readEncodedAdvance(content: unknown): EncodedAdvance;
/** Internal, decoded representation. Revision tags never escape as public cut identities. */
export interface ExternalAuthorityAdvance<TChange> {
    readonly batchId: string;
    readonly expected: string;
    readonly next: string;
    readonly approvedPrefix: readonly RevisionTag[];
    readonly commits: readonly GraphCommit<TChange>[];
}
export type ExternalAuthorityOutcome = "applied" | "duplicate" | "stale";
export interface ExternalAuthorityState<TChange> {
    readonly checkpoint: string;
    readonly approved: GraphCommit<TChange>;
    readonly sequenced: GraphCommit<TChange>;
    readonly provisional: readonly GraphCommit<TChange>[];
}
//# sourceMappingURL=externalAuthority.d.ts.map