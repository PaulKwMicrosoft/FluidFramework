/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import * as Type from "@sinclair/typebox";
import { type EncodedRevisionTag } from "../core/index.js";
import type { JsonCompatibleReadOnly } from "../util/index.js";
import { MessageFormatVersion } from "./messageFormat.js";
/**
 * The format of messages that SharedTree sends and receives.
 */
export interface Message {
    /**
     * The revision tag for the change in this message
     */
    readonly revision: EncodedRevisionTag;
    /**
     * The stable ID that identifies the originator of the message.
     */
    readonly originatorId: SessionId;
    /**
     * The changeset to be applied.
     */
    readonly changeset: JsonCompatibleReadOnly;
    /**
     * The version of the message. This controls how the message is encoded.
     *
     * This was not set historically and was added before making any breaking changes to the format.
     * For that reason, absence of a 'version' field is synonymous with version 1.
     */
    readonly version?: typeof MessageFormatVersion.v1 | typeof MessageFormatVersion.v2 | typeof MessageFormatVersion.v3 | typeof MessageFormatVersion.v4 | typeof MessageFormatVersion.v6;
}
export declare const Message: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
    originatorId: Type.TUnsafe<SessionId>;
    changeset: ChangeSchema;
    version: Type.TOptional<Type.TUnion<[Type.TLiteral<import("../util/brand.js").Brand<1, "MessageFormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<2, "MessageFormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<3, "MessageFormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<4, "MessageFormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<6, "MessageFormatVersion">>]>>;
}>;
//# sourceMappingURL=messageFormatV1ToV4.d.ts.map