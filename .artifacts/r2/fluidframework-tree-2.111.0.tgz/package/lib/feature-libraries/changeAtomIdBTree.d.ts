/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type ChangesetLocalId, type RevisionTag } from "../core/index.js";
import { type TupleBTree } from "../util/index.js";
/**
 * A BTree which uses ChangeAtomId flattened into a tuple as the key.
 * @remarks
 * Read values with {@link getFromChangeAtomIdMap} and write values with {@link setInChangeAtomIdMap}.
 */
export type ChangeAtomIdBTree<V> = TupleBTree<readonly [RevisionTag | undefined, ChangesetLocalId], V>;
/** Creates a new {@link ChangeAtomIdBTree} */
export declare function newChangeAtomIdBTree<V>(entries?: [readonly [RevisionTag | undefined, ChangesetLocalId], V][]): ChangeAtomIdBTree<V>;
export declare function getFromChangeAtomIdMap<T>(map: ChangeAtomIdBTree<T>, id: ChangeAtomId): T | undefined;
export declare function setInChangeAtomIdMap<T>(map: ChangeAtomIdBTree<T>, id: ChangeAtomId, value: T): void;
//# sourceMappingURL=changeAtomIdBTree.d.ts.map