/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { NormalizedFieldUpPath, NormalizedUpPath } from "../../core/index.js";
import type { IDefaultEditBuilder, OptionalFieldEditBuilder, SequenceFieldEditBuilder, ValueFieldEditBuilder } from "./defaultEditBuilder.js";
/**
 * An IDefaultEditBuilder implementation based on another IDefaultEditBuilder that uses a different content type for insertions.
 */
export declare class MappedEditBuilder<TBase, TAdapted> implements IDefaultEditBuilder<TAdapted> {
    private readonly baseBuilder;
    private readonly mapDelegate;
    constructor(baseBuilder: IDefaultEditBuilder<TBase>, mapDelegate: (input: TAdapted) => TBase);
    valueField(field: NormalizedFieldUpPath): ValueFieldEditBuilder<TAdapted>;
    optionalField(field: NormalizedFieldUpPath): OptionalFieldEditBuilder<TAdapted>;
    sequenceField(field: NormalizedFieldUpPath): SequenceFieldEditBuilder<TAdapted>;
    move(sourceField: NormalizedFieldUpPath, sourceIndex: number, count: number, destinationField: NormalizedFieldUpPath, destinationIndex: number): void;
    addNodeExistsConstraint(path: NormalizedUpPath): void;
    addNodeExistsConstraintOnRevert(path: NormalizedUpPath): void;
    addNoChangeConstraint(): void;
    addNoChangeConstraintOnRevert(): void;
}
//# sourceMappingURL=mappedEditBuilder.d.ts.map