/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { CodecWriteOptions, ICodecFamily } from "../../codec/index.js";
import { type ChangeEncodingContext, type ChangeFamily, type ChangeFamilyEditor, type ChangeRebaser, type DeltaDetachedNodeId, type DeltaRoot, type FieldUpPath, type NormalizedFieldUpPath, type NormalizedUpPath, type RevisionTag, type TaggedChange, type TreeChunk, type UpPath } from "../../core/index.js";
import { type ModularChangeset } from "../modular-schema/index.js";
export type DefaultChangeset = ModularChangeset;
/**
 * Implementation of {@link ChangeFamily} based on the default set of supported field kinds.
 *
 * @sealed
 */
export declare class DefaultChangeFamily implements ChangeFamily<DefaultEditBuilder, DefaultChangeset> {
    private readonly modularFamily;
    constructor(codecs: ICodecFamily<ModularChangeset, ChangeEncodingContext>, codecOptions: CodecWriteOptions);
    get rebaser(): ChangeRebaser<DefaultChangeset>;
    get codecs(): ICodecFamily<DefaultChangeset, ChangeEncodingContext>;
    buildEditor(mintRevisionTag: () => RevisionTag, changeReceiver: (change: TaggedChange<DefaultChangeset>) => void): DefaultEditBuilder;
}
/**
 * @param change - The change to convert into a delta.
 */
export declare function intoDelta(taggedChange: TaggedChange<ModularChangeset>): DeltaRoot;
/**
 * Returns the set of removed roots that should be in memory for the given change to be applied.
 * A removed root is relevant if any of the following is true:
 * - It is being inserted
 * - It is being restored
 * - It is being edited
 * - The ID it is associated with is being changed
 *
 * May be conservative by returning more removed roots than strictly necessary.
 *
 * Will never return IDs for non-root trees, even if they are removed.
 *
 * @param change - The change to be applied.
 */
export declare function relevantRemovedRoots(change: ModularChangeset): Iterable<DeltaDetachedNodeId>;
/**
 * Default editor for transactional tree data changes.
 * @privateRemarks
 * When taking into account not just the content of the tree,
 * but also how the merge identities (and thus anchors, flex-tree and simple-tree nodes) of nodes before and after the edits correspond,
 * some edits are currently impossible to express.
 * Examples of these non-expressible edits include:
 *
 * - Changing the type of a node while keeping its merge identity.
 * - Changing the value of a leaf while keeping its merge identity.
 * - Swapping subtrees between two value fields.
 * - Replacing a node in the middle of a tree while reusing some of the old nodes decedents that were under value fields.
 *
 * At some point it will likely be worth supporting at least some of these, possibly using a mechanism that could support all of them if desired.
 * If/when such a mechanism becomes available, an evaluation should be done to determine if any existing editing operations should be changed to leverage it
 * (Possibly by adding opt ins at the view schema layer).
 */
export interface IDefaultEditBuilder<TContent = TreeChunk> {
    /**
     * @param field - the value field which is being edited under the parent node
     * @returns An object with methods to edit the given field of the given parent.
     * The returned object can be used (i.e., have its methods called) multiple times but its lifetime
     * is bounded by the lifetime of this edit builder.
     */
    valueField(field: NormalizedFieldUpPath): ValueFieldEditBuilder<TContent>;
    /**
     * @param field - the optional field which is being edited under the parent node
     * @returns An object with methods to edit the given field of the given parent.
     * The returned object can be used (i.e., have its methods called) multiple times but its lifetime
     * is bounded by the lifetime of this edit builder.
     */
    optionalField(field: NormalizedFieldUpPath): OptionalFieldEditBuilder<TContent>;
    /**
     * @param field - the sequence field which is being edited under the parent node
     *
     * @returns An object with methods to edit the given field of the given parent.
     * The returned object can be used (i.e., have its methods called) multiple times but its lifetime
     * is bounded by the lifetime of this edit builder.
     */
    sequenceField(field: NormalizedFieldUpPath): SequenceFieldEditBuilder<TContent>;
    /**
     * Moves a subsequence from one sequence field to another sequence field.
     *
     * Note that the `destinationIndex` is interpreted based on the state of the sequence *before* the move operation.
     * For example, `move(field, 0, 1, field, 2)` changes `[A, B, C]` to `[B, A, C]`.
     */
    move(sourceField: NormalizedFieldUpPath, sourceIndex: number, count: number, destinationField: NormalizedFieldUpPath, destinationIndex: number): void;
    /**
     * Add a constraint that, for this change to apply, the node at the given path must exist immediately before the change is applied.
     * @param path - The path to the node that must exist.
     */
    addNodeExistsConstraint(path: NormalizedUpPath): void;
    /**
     * Add a constraint that, for the revert of this change to apply, the node at the given path must exist immediately before the revert is applied.
     * @param path - The path to the node that must exist when reverting a change.
     */
    addNodeExistsConstraintOnRevert(path: NormalizedUpPath): void;
    /**
     * Add a constraint that, for this change to apply, the document must be in the same state immediately before this change is applied as it was before this change was authored.
     */
    addNoChangeConstraint(): void;
    /**
     * Add a constraint that, for the revert of this change to apply, the document must be in the same state immediately before the revert is applied as it was after this change was applied.
     */
    addNoChangeConstraintOnRevert(): void;
}
/**
 * Implementation of {@link IDefaultEditBuilder} based on the default set of supported field kinds.
 * @sealed
 */
export declare class DefaultEditBuilder implements ChangeFamilyEditor, IDefaultEditBuilder {
    private readonly mintRevisionTag;
    private readonly modularBuilder;
    constructor(family: ChangeFamily<ChangeFamilyEditor, DefaultChangeset>, mintRevisionTag: () => RevisionTag, changeReceiver: (change: TaggedChange<DefaultChangeset>) => void, codecOptions: CodecWriteOptions);
    enterTransaction(): void;
    exitTransaction(): void;
    addNodeExistsConstraint(path: UpPath): void;
    addNodeExistsConstraintOnRevert(path: UpPath): void;
    addNoChangeConstraint(): void;
    addNoChangeConstraintOnRevert(): void;
    valueField(field: FieldUpPath): ValueFieldEditBuilder<TreeChunk>;
    optionalField(field: FieldUpPath): OptionalFieldEditBuilder<TreeChunk>;
    move(sourceField: FieldUpPath, sourceIndex: number, count: number, destinationField: FieldUpPath, destIndex: number): void;
    sequenceField(field: FieldUpPath): SequenceFieldEditBuilder<TreeChunk>;
}
export interface ValueFieldEditBuilder<TContent> {
    /**
     * Issues a change which replaces the current newContent of the field with `newContent`.
     * @param newContent - the new content for the field.
     */
    set(newContent: TContent): void;
}
export interface OptionalFieldEditBuilder<TContent> {
    /**
     * Issues a change which replaces the current newContent of the field with `newContent`.
     * @param newContent - the new content for the field.
     * @param wasEmpty - whether the field is empty when creating this change.
     */
    set(newContent: TContent | undefined, wasEmpty: boolean): void;
}
/**
 * Edit builder for the sequence field kind.
 */
export interface SequenceFieldEditBuilder<TContent, TRemoved = void> {
    /**
     * Issues a change which inserts the `newContent` at the given `index`.
     * @param index - the index at which to insert the `newContent`.
     * @param newContent - the new content to be inserted in the field. Cursor can be in either Field or Node mode.
     */
    insert(index: number, newContent: TContent): void;
    /**
     * Issues a change which removes `count` elements starting at the given `index`.
     * @param index - The index of the first removed element.
     * @param count - The number of elements to remove.
     */
    remove(index: number, count: number): TRemoved;
}
//# sourceMappingURL=defaultEditBuilder.d.ts.map