/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type MoveEffectTable } from "./moveEffectTable.js";
import type { Mark } from "./types.js";
export declare class MarkQueue {
    private readonly list;
    private readonly moveEffects;
    private readonly stack;
    private index;
    constructor(list: readonly Mark[], moveEffects: MoveEffectTable);
    isEmpty(): boolean;
    dequeue(): Mark;
    tryDequeue(): Mark | undefined;
    /**
     * Dequeues the first `length` sized portion of the next mark,
     * or the entire next mark if `length` is longer than the mark's length.
     * @param length - The length to dequeue, measured in the input context.
     */
    dequeueUpTo(length: number): Mark;
    peek(): Mark | undefined;
}
//# sourceMappingURL=markQueue.d.ts.map