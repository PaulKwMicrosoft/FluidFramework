/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ChangeAtomId, RevisionTag, TaggedChange } from "../../core/index.js";
import { type RangeQueryResult } from "../../util/index.js";
import { type CrossFieldManager, CrossFieldTarget, type NodeId } from "../modular-schema/index.js";
import type { MoveMarkEffect } from "./helperTypes.js";
import type { CellMark, Detach, Mark, MarkEffect, MoveId, MoveIn, MoveOut } from "./types.js";
export type MoveEffectTable = CrossFieldManager<MoveEffect>;
/**
 * Changes to be applied to a move mark.
 */
export interface MoveEffect {
    /**
     * Node changes which should be applied to this mark.
     * If this mark already has node changes, `modifyAfter` should be composed as later changes.
     */
    modifyAfter?: NodeId;
    /**
     * Only used during rebasing.
     * An effect from changeset being rebased which should be moved to the same position as this mark.
     */
    movedEffect?: Detach;
    /**
     * Rebased changes for a node which has been moved to the position of this mark.
     */
    rebasedChanges?: NodeId;
    /**
     * The ID of the other outer endpoint.
     * Used when this is the outer endpoint in a move chain which is being composed with another move chain.
     */
    endpoint?: ChangeAtomId;
    /**
     * The ID of the truncated endpoint.
     * Used when this mark is the outer endpoint of a chain being composed with a redundant move chain.
     */
    truncatedEndpoint?: ChangeAtomId;
    /**
     * The ID of the truncated endpoint.
     * Used when this mark is the inner endpoint of a redundant move chain.
     */
    truncatedEndpointForInner?: ChangeAtomId;
}
export declare enum MoveEnd {
    Source = 0,
    Dest = 1
}
export interface MovePartition {
    id: MoveId;
    count?: number;
    replaceWith?: Mark[];
    modifyAfter?: TaggedChange<NodeId>;
}
export declare function setMoveEffect(moveEffects: MoveEffectTable, target: CrossFieldTarget, revision: RevisionTag | undefined, id: MoveId, count: number, effect: MoveEffect, invalidate?: boolean): void;
export declare function getMoveEffect(moveEffects: MoveEffectTable, target: CrossFieldTarget, revision: RevisionTag | undefined, id: MoveId, count: number, addDependency?: boolean): RangeQueryResult<MoveEffect | undefined>;
export type MoveMark = CellMark<MoveMarkEffect>;
export declare function isMoveMark(effect: MarkEffect): effect is MoveMarkEffect;
export declare function isMoveOut(effect: MarkEffect): effect is MoveOut;
export declare function isMoveIn(effect: MarkEffect): effect is MoveIn;
export declare function getMoveIn(effect: MarkEffect): MoveIn | undefined;
export declare function splitMarkForMoveEffects(mark: Mark, effects: MoveEffectTable): Mark[];
export declare function getCrossFieldTargetFromMove(mark: MoveMarkEffect): CrossFieldTarget;
//# sourceMappingURL=moveEffectTable.d.ts.map