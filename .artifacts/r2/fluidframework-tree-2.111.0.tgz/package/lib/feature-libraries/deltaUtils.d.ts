/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, type DeltaDetachedNodeId, type DeltaRoot } from "../core/index.js";
export declare function nodeIdFromChangeAtom(changeAtom: ChangeAtomId): DeltaDetachedNodeId;
/**
 * Converts a `Delta.Root` whose tree content is represented with by `TIn` instances
 * into a `Delta.Root`whose tree content is represented with by `TOut` instances.
 *
 * This function is useful for converting `Delta`s that represent tree content with cursors
 * into `Delta`s that represent tree content with a deep-comparable representation of the content.
 * See {@link assertDeltaEqual}.
 * @param root - The delta to convert. Not mutated.
 * @param func - The functions used to map tree content.
 */
export declare function mapRootChanges<TIn, TOut>(root: DeltaRoot<TIn>, func: (tree: TIn) => TOut): DeltaRoot<TOut>;
//# sourceMappingURL=deltaUtils.d.ts.map