/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
declare const EncodedNoChangeConstraint: Type.TObject<{
    violated: Type.TBoolean;
}>;
export type EncodedNoChangeConstraint = Static<typeof EncodedNoChangeConstraint>;
export declare const EncodedModularChangesetV2: Type.TObject<{
    maxId: Type.TOptional<Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>>;
    revisions: Type.TReadonly<Type.TOptional<Type.TArray<Type.TObject<{
        revision: Type.TReadonly<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        rollbackOf: Type.TReadonly<Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>>;
    }>>>>;
    builds: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        trees: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    changes: Type.TArray<Type.TObject<{
        fieldKey: Type.TUnsafe<import("../../core/index.js").FieldKey>;
        fieldKind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
        change: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    refreshers: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        trees: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    violations: Type.TOptional<Type.TNumber>;
    noChangeConstraint: Type.TOptional<Type.TObject<{
        violated: Type.TBoolean;
    }>>;
}>;
export type EncodedModularChangesetV2 = Static<typeof EncodedModularChangesetV2>;
export {};
//# sourceMappingURL=modularChangeFormatV2.d.ts.map