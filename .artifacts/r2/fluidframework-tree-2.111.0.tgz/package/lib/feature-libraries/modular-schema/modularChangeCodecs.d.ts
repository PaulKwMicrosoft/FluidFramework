/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ICodecFamily, type ICodecOptions, type JsonCodecPart } from "../../codec/index.js";
import type { ChangeEncodingContext, RevisionTag, RevisionTagSchema } from "../../core/index.js";
import { type Values } from "../../util/index.js";
import type { FieldBatchCodec } from "../chunked-forest/index.js";
import { TreeCompressionStrategy } from "../treeCompressionUtils.js";
import type { FieldKindConfiguration } from "./fieldKindConfiguration.js";
import type { ModularChangeset } from "./modularChangeTypes.js";
export declare function makeModularChangeCodecFamily(fieldKindConfigurations: ReadonlyMap<ModularChangeFormatVersion, FieldKindConfiguration>, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, codecOptions: ICodecOptions, chunkCompressionStrategy?: TreeCompressionStrategy): ICodecFamily<ModularChangeset, ChangeEncodingContext>;
/**
 * The format version for `ModularChangeset`.
 */
export declare const ModularChangeFormatVersion: {
    readonly v3: import("../../util/brand.js").Brand<3, "ModularChangeFormatVersion">;
    readonly v4: import("../../util/brand.js").Brand<4, "ModularChangeFormatVersion">;
    readonly v5: import("../../util/brand.js").Brand<5, "ModularChangeFormatVersion">;
};
export type ModularChangeFormatVersion = Values<typeof ModularChangeFormatVersion>;
//# sourceMappingURL=modularChangeCodecs.d.ts.map