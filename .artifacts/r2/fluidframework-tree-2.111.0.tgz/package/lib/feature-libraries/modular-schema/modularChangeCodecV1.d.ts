/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { TAnySchema } from "@sinclair/typebox";
import { type ICodecOptions, type IJsonCodec, type JsonCodecPart, type SchemaValidationFunction } from "../../codec/index.js";
import type { ChangeEncodingContext, FieldKindIdentifier, RevisionInfo, RevisionTag, RevisionTagSchema } from "../../core/index.js";
import { type IdAllocator, type JsonCompatibleReadOnly, type Mutable } from "../../util/index.js";
import { type ChangeAtomIdBTree } from "../changeAtomIdBTree.js";
import { type FieldBatchCodec, type TreeChunk } from "../chunked-forest/index.js";
import { TreeCompressionStrategy } from "../treeCompressionUtils.js";
import type { FieldChangeEncodingContext } from "./fieldChangeHandler.js";
import type { FieldKindConfiguration } from "./fieldKindConfiguration.js";
import { type EncodedBuilds, type EncodedFieldChangeMap, EncodedModularChangesetV1, type EncodedNodeChangeset, type EncodedRevisionInfo } from "./modularChangeFormatV1.js";
import { type FieldChangeset, type FieldChangeMap, type ModularChangeset, type NodeChangeset, type NodeId } from "./modularChangeTypes.js";
type ModularChangeCodec = IJsonCodec<ModularChangeset, EncodedModularChangesetV1, EncodedModularChangesetV1, ChangeEncodingContext>;
type FieldCodec = IJsonCodec<FieldChangeset, JsonCompatibleReadOnly, JsonCompatibleReadOnly, FieldChangeEncodingContext>;
type FieldChangesetCodecs = Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>;
export declare function getFieldChangesetCodec(fieldKind: FieldKindIdentifier, fieldChangesetCodecs: FieldChangesetCodecs): {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
};
export declare function encodeFieldChangesForJson(change: FieldChangeMap, context: ChangeEncodingContext, nodeChanges: ChangeAtomIdBTree<NodeChangeset>, fieldChangesetCodecs: FieldChangesetCodecs): EncodedFieldChangeMap;
export declare function encodeFieldChangesForJsonI(change: FieldChangeMap, context: FieldChangeEncodingContext, fieldChangesetCodecs: FieldChangesetCodecs): EncodedFieldChangeMap;
export declare function encodeNodeChangesForJson(change: NodeChangeset, context: FieldChangeEncodingContext, fieldChangesetCodecs: FieldChangesetCodecs): EncodedNodeChangeset;
export declare function decodeFieldChangesFromJson(encodedChange: EncodedFieldChangeMap, parentId: NodeId | undefined, decoded: ModularChangeset, context: ChangeEncodingContext, idAllocator: IdAllocator, fieldKinds: FieldKindConfiguration, fieldChangesetCodecs: FieldChangesetCodecs): FieldChangeMap;
export declare function decodeNodeChangesetFromJson(encodedChange: EncodedNodeChangeset, id: NodeId, decoded: ModularChangeset, context: ChangeEncodingContext, idAllocator: IdAllocator, fieldKinds: FieldKindConfiguration, fieldChangesetCodecs: FieldChangesetCodecs): NodeChangeset;
export declare function encodeDetachedNodes(detachedNodes: ChangeAtomIdBTree<TreeChunk> | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): EncodedBuilds | undefined;
export declare function decodeDetachedNodes(encoded: EncodedBuilds | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): ChangeAtomIdBTree<TreeChunk> | undefined;
export declare function encodeRevisionInfos(revisions: readonly RevisionInfo[], context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>): EncodedRevisionInfo[] | undefined;
export declare function decodeRevisionInfos(revisions: readonly EncodedRevisionInfo[] | undefined, context: ChangeEncodingContext, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>): RevisionInfo[] | undefined;
export declare function encodeChange(change: ModularChangeset, context: ChangeEncodingContext, fieldChangesetCodecs: Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): EncodedModularChangesetV1;
export declare function decodeChange(encodedChange: EncodedModularChangesetV1, context: ChangeEncodingContext, fieldKinds: FieldKindConfiguration, fieldChangesetCodecs: Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, chunkCompressionStrategy: TreeCompressionStrategy): Mutable<ModularChangeset>;
export declare function getFieldChangesetCodecs(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, codecOptions: ICodecOptions): Map<FieldKindIdentifier, {
    compiledSchema?: SchemaValidationFunction<TAnySchema>;
    codec: FieldCodec;
}>;
export declare function makeModularChangeCodecV1(fieldKinds: FieldKindConfiguration, revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>, fieldsCodec: FieldBatchCodec, codecOptions: ICodecOptions, chunkCompressionStrategy?: TreeCompressionStrategy): ModularChangeCodec;
export {};
//# sourceMappingURL=modularChangeCodecV1.d.ts.map