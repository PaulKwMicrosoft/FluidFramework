/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
import type { Static, TSchema } from "@sinclair/typebox";
export declare const EncodedRegisterId: Type.TUnion<[Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>, Type.TNull]>;
export type EncodedRegisterId = Static<typeof EncodedRegisterId>;
export declare const EncodedOptionalChangeset: <Schema extends Type.TSchema>(tNodeChange: Schema) => Type.TObject<{
    m: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>, Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>]>>>;
    c: Type.TOptional<Type.TArray<Type.TTuple<[Type.TUnion<[Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>, Type.TNull]>, Schema]>>>;
    r: Type.TOptional<Type.TObject<{
        e: Type.TBoolean;
        s: Type.TOptional<Type.TUnion<[Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>, Type.TNull]>>;
        d: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    }>>;
}>;
export type EncodedOptionalChangeset<Schema extends TSchema> = Static<ReturnType<typeof EncodedOptionalChangeset<Schema>>>;
declare const EncodedReplace: Type.TObject<{
    e: Type.TBoolean;
    s: Type.TOptional<Type.TUnion<[Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>, Type.TNull]>>;
    d: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
}>;
export type EncodedReplace = Static<typeof EncodedReplace>;
export {};
//# sourceMappingURL=optionalFieldChangeFormatV2.d.ts.map