/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import { type ChangeAtomId, Multiplicity, type RevisionTag } from "../../core/index.js";
import { optionalIdentifier } from "../fieldKindIdentifiers.js";
import { type FieldChangeHandler, type FieldChangeRebaser, type FieldEditor, type ToDelta, type FieldChangeDelta, FlexFieldKind } from "../modular-schema/index.js";
import type { OptionalChangeset, RegisterId } from "./optionalFieldChangeTypes.js";
export interface IRegisterMap<T> {
    set(id: RegisterId, childChange: T): void;
    get(id: RegisterId): T | undefined;
    delete(id: RegisterId): boolean;
    keys(): Iterable<RegisterId>;
    values(): Iterable<T>;
    entries(): Iterable<[RegisterId, T]>;
    readonly size: number;
}
export declare class RegisterMap<T> implements IRegisterMap<T> {
    private readonly nestedMapData;
    clone(): RegisterMap<T>;
    set(id: RegisterId, childChange: T): void;
    get(id: RegisterId): T | undefined;
    has(id: RegisterId): boolean;
    delete(id: RegisterId): boolean;
    keys(): Iterable<RegisterId>;
    values(): Iterable<T>;
    entries(): Iterable<[RegisterId, T]>;
    get size(): number;
}
export declare const optionalChangeRebaser: FieldChangeRebaser<OptionalChangeset>;
export declare function taggedRegister(id: RegisterId, revision: RevisionTag | undefined): RegisterId;
export interface OptionalFieldEditor extends FieldEditor<OptionalChangeset> {
    /**
     * Creates a change which will replace the content already in the field (if any at the time the change applies)
     * with new content.
     * The content in the field will be moved to the `ids.detach` register.
     * The content in the `ids.detach` register will be moved to into the field.
     * @param wasEmpty - whether the field is empty when creating this change
     * @param ids - the "fill" and "detach" ids associated with the change.
     */
    set(wasEmpty: boolean, ids: {
        fill: ChangeAtomId;
        detach: ChangeAtomId;
    }): OptionalChangeset;
    /**
     * Creates a change which clears the field's contents (if any).
     * @param wasEmpty - whether the field is empty when creating this change
     * @param detachId - the ID of the register that existing field content (if any) will be moved to.
     */
    clear(wasEmpty: boolean, detachId: ChangeAtomId): OptionalChangeset;
}
export declare const optionalFieldEditor: OptionalFieldEditor;
export declare function optionalFieldIntoDelta(change: OptionalChangeset, deltaFromChild: ToDelta): FieldChangeDelta;
export declare const optionalChangeHandler: FieldChangeHandler<OptionalChangeset, OptionalFieldEditor>;
interface Optional extends FlexFieldKind<OptionalFieldEditor, typeof optionalIdentifier, Multiplicity.Optional> {
}
/**
 * 0 or 1 items.
 */
export declare const optional: Optional;
export {};
//# sourceMappingURL=optionalField.d.ts.map