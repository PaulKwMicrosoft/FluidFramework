/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { JsonCodecPart } from "../codec/index.js";
import type { ChangeAtomId, ChangeEncodingContext, RevisionTag, RevisionTagSchema } from "../core/index.js";
import { EncodedChangeAtomId } from "./modular-schema/index.js";
export declare function makeChangeAtomIdCodec(revisionTagCodec: JsonCodecPart<RevisionTag, typeof RevisionTagSchema, ChangeEncodingContext>): JsonCodecPart<ChangeAtomId, typeof EncodedChangeAtomId, ChangeEncodingContext>;
//# sourceMappingURL=changeAtomIdCodec.d.ts.map