/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
export { areEqualChangeAtomIds, areEqualChangeAtomIdOpts, makeChangeAtomId, asChangeAtomId, mintCommit, type GraphCommit, CommitKind, type CommitMetadata, type LocalChangeMetadata, type RemoteChangeMetadata, type ChangeMetadata, type LabelTree, type TransactionLabels, type RevisionTag, RevisionTagSchema, type EncodedRevisionTag, type EncodedChangeAtomId, type EncodedStableId, type ChangesetLocalId, type ChangeAtomId, type ChangeAtomIdMap, SessionIdSchema, taggedAtomId, taggedOptAtomId, offsetChangeAtomId, StableIdSchema, subtractChangeAtomIds, type ChangeAtomIdRangeMap, newChangeAtomIdRangeMap, comparePartialRevisions, compareChangesetLocalIds, comparePartialChangesetLocalIds, } from "./types.js";
export { RevisionTagCodec } from "./revisionTagCodec.js";
export { type ChangeRebaser, type FinalChange, FinalChangeStatus, makeAnonChange, tagChange, mapTaggedChange, tagRollbackInverse, type TaggedChange, type RevisionMetadataSource, type RevisionInfo, type RevisionReplacer, } from "./changeRebaser.js";
export { findAncestor, findCommonAncestor, rebaseBranch, type BranchRebaseResult, rebaseChange, rebaseChangeOverChanges, revisionMetadataSourceFromInfo, type RebaseStats, type RebaseStatsWithDuration, replaceChange, isAncestor, diffHistories, } from "./utils.js";
//# sourceMappingURL=index.d.ts.map