/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Bundles a collection of Fluid Framework client libraries for easy use when paired with a corresponding service client
 * package (e.g. `@fluidframework/azure-client`, `@fluidframework/tinylicious-client`, or `@fluidframework/odsp-client (BETA)`).
 *
 * @packageDocumentation
 */
export type { ConnectionState as ConnectionStateType, // TODO: deduplicate ConnectionState types
ICriticalContainerError, } from "@fluidframework/container-definitions";
export { AttachState } from "@fluidframework/container-definitions";
export { ConnectionState } from "@fluidframework/container-loader";
export type { ContainerAttachProps, ContainerSchema, IConnection, IFluidContainer, IFluidContainerEvents, IMember, InitialObjects, IServiceAudience, IServiceAudienceEvents, MemberChangedListener, Myself, } from "@fluidframework/fluid-static";
export { getPresence, getPresenceAlpha } from "@fluidframework/fluid-static/internal";
export type { SharedObjectKind } from "@fluidframework/shared-object-base";
export type { IErrorBase, IEventProvider, IDisposable, IEvent, IEventThisPlaceHolder, IErrorEvent, ErasedType, IFluidHandle, IFluidLoadable, ITelemetryBaseProperties, IEventTransformer, IProvideFluidLoadable, IFluidHandleErased, TransformedEvent, TelemetryBaseEventPropertyType, Tagged, ReplaceIEventThisPlaceHolder, FluidObject, // Linked in doc comment
FluidObjectProviderKeys, // Used by FluidObject
Listeners, IsListener, Listenable, Off, } from "@fluidframework/core-interfaces";
export type { ErasedBaseType, FluidIterable, FluidIterableIterator, FluidMap, FluidReadonlyMap, } from "@fluidframework/core-interfaces/internal";
export { onAssertionFailure } from "@fluidframework/core-utils/internal";
export type { isFluidHandle } from "@fluidframework/runtime-utils";
export * from "@fluidframework/tree/alpha";
import type { SharedObjectKind } from "@fluidframework/shared-object-base";
import type { ITree } from "@fluidframework/tree";
import { type SharedTreeOptions } from "@fluidframework/tree/internal";
/**
 * A hierarchical data structure for collaboratively editing strongly typed JSON-like trees
 * of objects, arrays, and other data types.
 * @privateRemarks
 * Here we reexport SharedTree, but with the `@legacy` types (`ISharedObjectKind`) removed, just keeping the `SharedObjectKind`.
 * Doing this requires creating this new typed export rather than relying on a reexport directly from the tree package.
 * The tree package itself does not do this because it's API needs to be usable from the encapsulated API which requires `ISharedObjectKind`.
 * This package however is not intended for use by users of the encapsulated API, and therefore it can discard that interface.
 * @public
 */
export declare const SharedTree: SharedObjectKind<ITree>;
/**
 * {@link SharedTree} but allowing a non-default configuration.
 * @remarks
 * This is useful for debugging and testing.
 * For example, it can be used to opt into extra validation or see if opting out of some optimizations fixes an issue.
 *
 * With great care, and knowledge of the support and stability of the options exposed here,
 * this can also be used to opt into some features early or for performance tuning.
 *
 * @example
 * ```typescript
 * import {
 * 	TreeCompressionStrategy,
 * 	configuredSharedTree,
 * 	FormatValidatorBasic,
 * 	ForestTypeReference,
 * } from "fluid-framework/alpha";
 * const SharedTree = configuredSharedTree({
 * 	forest: ForestTypeReference,
 * 	jsonValidator: FormatValidatorBasic,
 * 	treeEncodeType: TreeCompressionStrategy.Uncompressed,
 * });
 * ```
 * @alpha
 */
export declare function configuredSharedTree(options: SharedTreeOptions): SharedObjectKind<ITree>;
export type { IDirectory, IDirectoryEvents, IDirectoryValueChanged, ISharedDirectory, ISharedDirectoryEvents, ISharedMap, ISharedMapEvents, IValueChanged, } from "@fluidframework/map/internal";
export { SharedDirectory, SharedMap } from "@fluidframework/map/internal";
export type { DeserializeCallback, InteriorSequencePlace, IInterval, IntervalStickiness, ISequenceDeltaRange, ISerializedInterval, ISharedSegmentSequenceEvents, ISharedString, SequencePlace, SharedStringSegment, Side, ISharedSegmentSequence, ISequenceIntervalCollection, ISequenceIntervalCollectionEvents, SequenceIntervalIndex, } from "@fluidframework/sequence/internal";
export type { IntervalType, SequenceDeltaEvent, SequenceEvent, SequenceInterval, SequenceMaintenanceEvent, } from "@fluidframework/sequence/internal";
export { SharedString } from "@fluidframework/sequence/internal";
export type { ISharedObject, ISharedObjectEvents, ISharedObjectKind, } from "@fluidframework/shared-object-base/internal";
export type { ISequencedDocumentMessage, // Leaked via ISharedObjectEvents
IBranchOrigin, // Required for ISequencedDocumentMessage
ITrace, } from "@fluidframework/driver-definitions/internal";
//# sourceMappingURL=index.d.ts.map