/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import * as Type from "@sinclair/typebox";
import { EditManagerFormatVersion, type EncodedSummarySessionBranch, SequencedCommit } from "./editManagerFormatCommons.js";
export interface EncodedEditManager<TChangeset> {
    readonly trunk: readonly Readonly<SequencedCommit<TChangeset>>[];
    readonly branches: readonly [SessionId, Readonly<EncodedSummarySessionBranch<TChangeset>>][];
    readonly version: typeof EditManagerFormatVersion.v1 | typeof EditManagerFormatVersion.v2 | typeof EditManagerFormatVersion.v3 | typeof EditManagerFormatVersion.v4 | typeof EditManagerFormatVersion.v6 | typeof EditManagerFormatVersion.vDetachedRoots;
}
export declare const EncodedEditManager: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    version: Type.TUnion<[Type.TLiteral<import("../util/brand.js").Brand<1, "editManager.FormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<2, "editManager.FormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<3, "editManager.FormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<4, "editManager.FormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<6, "editManager.FormatVersion">>, Type.TLiteral<import("../util/brand.js").Brand<"detached-roots|v0.1", "editManager.FormatVersion">>]>;
    trunk: Type.TArray<Type.TObject<{
        change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T ? T extends Type.Assert<ChangeSchema, Type.TSchema> ? T extends Type.TNever ? [] : [T] : never : never>;
        revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
        sessionId: Type.TUnsafe<SessionId>;
        sequenceNumber: Type.TUnsafe<import("./editManagerFormatCommons.js").SeqNumber>;
        indexInBatch: Type.TOptional<Type.TNumber>;
    }>>;
    branches: Type.TArray<Type.TTuple<[Type.TUnsafe<SessionId>, Type.TObject<{
        base: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
        commits: Type.TArray<Type.TObject<{
            change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T_1 ? T_1 extends Type.Assert<ChangeSchema, Type.TSchema> ? T_1 extends Type.TNever ? [] : [T_1] : never : never>;
            revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            sessionId: Type.TUnsafe<SessionId>;
        }>>;
    }>]>>;
}>;
//# sourceMappingURL=editManagerFormatV1toV4.d.ts.map