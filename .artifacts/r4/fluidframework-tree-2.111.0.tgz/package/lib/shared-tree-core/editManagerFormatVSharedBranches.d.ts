/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import * as Type from "@sinclair/typebox";
import { EncodedSharedBranch, EditManagerFormatVersion } from "./editManagerFormatCommons.js";
export interface EncodedEditManager<TChangeset> {
    readonly version: typeof EditManagerFormatVersion.vSharedBranches;
    readonly originator: SessionId;
    readonly main: EncodedSharedBranch<TChangeset>;
    readonly branches?: readonly EncodedSharedBranch<TChangeset>[];
}
export declare const EncodedEditManager: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    version: Type.TLiteral<import("../util/brand.js").Brand<"shared-branches|v0.1", "editManager.FormatVersion">>;
    originator: Type.TUnsafe<SessionId>;
    main: Type.TObject<{
        id: Type.TOptional<Type.TNumber>;
        name: Type.TOptional<Type.TString>;
        session: Type.TOptional<Type.TUnsafe<SessionId>>;
        author: Type.TOptional<Type.TString>;
        base: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        trunk: Type.TArray<Type.TObject<{
            change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T ? T extends Type.Assert<ChangeSchema, Type.TSchema> ? T extends Type.TNever ? [] : [T] : never : never>;
            revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            sessionId: Type.TUnsafe<SessionId>;
            sequenceNumber: Type.TUnsafe<import("./editManagerFormatCommons.js").SeqNumber>;
            indexInBatch: Type.TOptional<Type.TNumber>;
        }>>;
        peers: Type.TArray<Type.TTuple<[Type.TUnsafe<SessionId>, Type.TObject<{
            base: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            commits: Type.TArray<Type.TObject<{
                change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T_1 ? T_1 extends Type.Assert<ChangeSchema, Type.TSchema> ? T_1 extends Type.TNever ? [] : [T_1] : never : never>;
                revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
                sessionId: Type.TUnsafe<SessionId>;
            }>>;
        }>]>>;
    }>;
    branches: Type.TOptional<Type.TArray<Type.TObject<{
        id: Type.TOptional<Type.TNumber>;
        name: Type.TOptional<Type.TString>;
        session: Type.TOptional<Type.TUnsafe<SessionId>>;
        author: Type.TOptional<Type.TString>;
        base: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        trunk: Type.TArray<Type.TObject<{
            change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T_2 ? T_2 extends Type.Assert<ChangeSchema, Type.TSchema> ? T_2 extends Type.TNever ? [] : [T_2] : never : never>;
            revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            sessionId: Type.TUnsafe<SessionId>;
            sequenceNumber: Type.TUnsafe<import("./editManagerFormatCommons.js").SeqNumber>;
            indexInBatch: Type.TOptional<Type.TNumber>;
        }>>;
        peers: Type.TArray<Type.TTuple<[Type.TUnsafe<SessionId>, Type.TObject<{
            base: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            commits: Type.TArray<Type.TObject<{
                change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T_3 ? T_3 extends Type.Assert<ChangeSchema, Type.TSchema> ? T_3 extends Type.TNever ? [] : [T_3] : never : never>;
                revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
                sessionId: Type.TUnsafe<SessionId>;
            }>>;
        }>]>>;
    }>>>;
}>;
//# sourceMappingURL=editManagerFormatVSharedBranches.d.ts.map