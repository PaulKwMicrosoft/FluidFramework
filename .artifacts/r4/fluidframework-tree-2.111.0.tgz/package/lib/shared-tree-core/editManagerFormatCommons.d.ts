/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { SessionId } from "@fluidframework/id-compressor";
import * as Type from "@sinclair/typebox";
import type { Static } from "@sinclair/typebox";
import { type EncodedRevisionTag, type RevisionTag } from "../core/index.js";
import { type Brand, type Values } from "../util/index.js";
import type { EncodedBranchId } from "./branch.js";
/**
 * Contains a single change to the `SharedTree` and associated metadata.
 *
 * TODO: if this type is not used in the encoded format, move it out of this file, and stop using it in EncodedEditManager.
 * If this is an encoded format, clarify the difference between it and EncodedCommit.
 */
export interface Commit<TChangeset> {
    readonly revision: RevisionTag;
    readonly change: TChangeset;
    /** An identifier representing the session/user/client that made this commit */
    readonly sessionId: SessionId;
}
export type EncodedCommit<TChangeset> = {
    readonly revision: EncodedRevisionTag;
    readonly change: TChangeset;
    readonly sessionId: SessionId;
};
export type SeqNumber = Brand<number, "edit-manager.SeqNumber">;
declare const SequenceId: Type.TObject<{
    sequenceNumber: Type.TUnsafe<SeqNumber>;
    indexInBatch: Type.TOptional<Type.TNumber>;
}>;
export type SequenceId = Static<typeof SequenceId>;
/**
 * A commit with a sequence number but no parentage; used for serializing the `EditManager` into a summary
 */
export interface SequencedCommit<TChangeset> extends Commit<TChangeset>, SequenceId {
}
export declare const SequencedCommit: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T ? T extends Type.Assert<ChangeSchema, Type.TSchema> ? T extends Type.TNever ? [] : [T] : never : never>;
    revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
    sessionId: Type.TUnsafe<SessionId>;
    sequenceNumber: Type.TUnsafe<SeqNumber>;
    indexInBatch: Type.TOptional<Type.TNumber>;
}>;
/**
 * A branch off of the trunk for use in summaries.
 *
 * TODO: if this type is not used in the encoded format, move it out of this file, and stop using it in EncodedEditManager.
 * If this is an encoded format, use EncodedCommit instead of Commit or clarify that Commit is also an encoded format.
 */
export interface SummarySessionBranch<TChangeset> {
    readonly base: RevisionTag;
    readonly commits: Commit<TChangeset>[];
}
export interface EncodedSummarySessionBranch<TChangeset> {
    readonly base: EncodedRevisionTag;
    readonly commits: Commit<TChangeset>[];
}
export declare const SummarySessionBranch: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    base: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
    commits: Type.TArray<Type.TObject<{
        change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T ? T extends Type.Assert<ChangeSchema, Type.TSchema> ? T extends Type.TNever ? [] : [T] : never : never>;
        revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
        sessionId: Type.TUnsafe<SessionId>;
    }>>;
}>;
export interface EncodedSharedBranch<TChangeset> {
    readonly id?: EncodedBranchId;
    readonly name?: string;
    readonly author?: string;
    readonly session?: SessionId;
    readonly base?: EncodedRevisionTag;
    readonly trunk: readonly Readonly<SequencedCommit<TChangeset>>[];
    readonly peers: readonly [SessionId, Readonly<EncodedSummarySessionBranch<TChangeset>>][];
}
export declare const EncodedSharedBranch: <ChangeSchema extends Type.TSchema>(tChange: ChangeSchema) => Type.TObject<{
    id: Type.TOptional<Type.TNumber>;
    name: Type.TOptional<Type.TString>;
    session: Type.TOptional<Type.TUnsafe<SessionId>>;
    author: Type.TOptional<Type.TString>;
    base: Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
    trunk: Type.TArray<Type.TObject<{
        change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T ? T extends Type.Assert<ChangeSchema, Type.TSchema> ? T extends Type.TNever ? [] : [T] : never : never>;
        revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
        sessionId: Type.TUnsafe<SessionId>;
        sequenceNumber: Type.TUnsafe<SeqNumber>;
        indexInBatch: Type.TOptional<Type.TNumber>;
    }>>;
    peers: Type.TArray<Type.TTuple<[Type.TUnsafe<SessionId>, Type.TObject<{
        base: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
        commits: Type.TArray<Type.TObject<{
            change: Type.TIntersectEvaluated<Type.Assert<ChangeSchema, Type.TSchema> extends infer T_1 ? T_1 extends Type.Assert<ChangeSchema, Type.TSchema> ? T_1 extends Type.TNever ? [] : [T_1] : never : never>;
            revision: Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>;
            sessionId: Type.TUnsafe<SessionId>;
        }>>;
    }>]>>;
}>;
/**
 * The format version for the EditManager.
 */
export declare const EditManagerFormatVersion: {
    readonly v1: Brand<1, "editManager.FormatVersion">;
    readonly v2: Brand<2, "editManager.FormatVersion">;
    readonly v3: Brand<3, "editManager.FormatVersion">;
    readonly v4: Brand<4, "editManager.FormatVersion">;
    readonly v5: Brand<5, "editManager.FormatVersion">;
    readonly v6: Brand<6, "editManager.FormatVersion">;
    readonly vSharedBranches: Brand<"shared-branches|v0.1", "editManager.FormatVersion">;
    readonly vDetachedRoots: Brand<"detached-roots|v0.1", "editManager.FormatVersion">;
};
export type EditManagerFormatVersion = Values<typeof EditManagerFormatVersion>;
export declare const supportedEditManagerFormatVersions: ReadonlySet<EditManagerFormatVersion>;
export declare const editManagerFormatVersions: ReadonlySet<EditManagerFormatVersion>;
export {};
//# sourceMappingURL=editManagerFormatCommons.d.ts.map