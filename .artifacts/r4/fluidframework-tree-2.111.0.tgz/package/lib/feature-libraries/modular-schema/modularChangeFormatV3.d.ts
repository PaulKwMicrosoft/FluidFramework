/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import * as Type from "@sinclair/typebox";
declare const EncodedRenames: Type.TOptional<Type.TArray<Type.TObject<{
    oldId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    newId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    count: Type.TNumber;
}>>>;
export type EncodedRenames = Type.Static<typeof EncodedRenames>;
declare const EncodedRootNodes: Type.TOptional<Type.TArray<Type.TObject<{
    detachId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
    nodeChangeset: Type.TObject<{
        fieldChanges: Type.TOptional<Type.TArray<Type.TObject<{
            fieldKey: Type.TUnsafe<import("../../core/index.js").FieldKey>;
            fieldKind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
            change: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
        }>>>;
        nodeExistsConstraint: Type.TOptional<Type.TObject<{
            violated: Type.TBoolean;
        }>>;
    }>;
}>>>;
export type EncodedRootNodes = Type.Static<typeof EncodedRootNodes>;
export declare const EncodedModularChangesetV3: Type.TObject<{
    maxId: Type.TOptional<Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>>;
    changes: Type.TArray<Type.TObject<{
        fieldKey: Type.TUnsafe<import("../../core/index.js").FieldKey>;
        fieldKind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
        change: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    revisions: Type.TReadonly<Type.TOptional<Type.TArray<Type.TObject<{
        revision: Type.TReadonly<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>;
        rollbackOf: Type.TReadonly<Type.TOptional<Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>>>;
    }>>>>;
    builds: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        trees: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    refreshers: Type.TOptional<Type.TObject<{
        builds: Type.TArray<Type.TUnion<[Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TTuple<[Type.TArray<Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TNumber]>>]>]>>;
        trees: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
    }>>;
    violations: Type.TOptional<Type.TNumber>;
    noChangeConstraint: Type.TOptional<Type.TObject<{
        violated: Type.TBoolean;
    }>>;
    rootNodes: Type.TOptional<Type.TArray<Type.TObject<{
        detachId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        nodeChangeset: Type.TObject<{
            fieldChanges: Type.TOptional<Type.TArray<Type.TObject<{
                fieldKey: Type.TUnsafe<import("../../core/index.js").FieldKey>;
                fieldKind: Type.TUnsafe<import("../../core/index.js").FieldKindIdentifier>;
                change: Type.TUnsafe<import("../../index.js").JsonCompatibleReadOnly>;
            }>>>;
            nodeExistsConstraint: Type.TOptional<Type.TObject<{
                violated: Type.TBoolean;
            }>>;
        }>;
    }>>>;
    nodeRenames: Type.TOptional<Type.TArray<Type.TObject<{
        oldId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        newId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        count: Type.TNumber;
    }>>>;
    intermediateRenames: Type.TOptional<Type.TArray<Type.TObject<{
        oldId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        newId: Type.TUnion<[Type.TTuple<[Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>, Type.TUnion<[Type.TLiteral<"root">, Type.TUnsafe<import("../../util/brand.js").Brand<import("@fluidframework/id-compressor").OpSpaceCompressedId, "EncodedRevisionTag">>]>]>, Type.TUnsafe<import("../../core/index.js").ChangesetLocalId>]>;
        count: Type.TNumber;
    }>>>;
}>;
export type EncodedModularChangesetV3 = Type.Static<typeof EncodedModularChangesetV3>;
export {};
//# sourceMappingURL=modularChangeFormatV3.d.ts.map