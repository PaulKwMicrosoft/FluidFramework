/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */

import { assert, Deferred } from "@fluidframework/core-utils/internal";
import { UsageError } from "@fluidframework/telemetry-utils/internal";
import { disposeSymbol } from "../util/index.js";
import { findCommonAncestor, type GraphCommit } from "../core/index.js";
import type {
	ImplicitFieldSchema,
	ITree,
	TreeNode,
	TreeView,
	TreeViewConfiguration,
	VerboseTree,
} from "../simple-tree/index.js";
import type { ExternalAuthorityOutcome } from "../shared-tree-core/index.js";
import type { ITreePrivate, SharedTreeKernel } from "./sharedTree.js";
import type { TreeCheckout } from "./treeCheckout.js";
import type { SharedTreeChange } from "./sharedTreeChangeTypes.js";
import { hasSchemaChange } from "./sharedTreeChangeFamily.js";
import {
	AuthorityNodeReferences,
	type SharedTreeAuthorityNodeReference,
	type SharedTreeAuthorityNodeResolution,
	type SharedTreeAuthorityReferenceOptions,
	type SharedTreeAuthorityReferenceResult,
} from "./authorityNodeReferences.js";

export type {
	SharedTreeAuthorityNodeReference,
	SharedTreeAuthorityNodeResolution,
	SharedTreeAuthorityReferenceOptions,
	SharedTreeAuthorityReferenceResult,
} from "./authorityNodeReferences.js";

/**
 * An immutable, internally consistent A and A+P cut. It never includes local unsequenced work.
 * @alpha
 */
export interface SharedTreeAuthorityCapture {
	readonly checkpoint: string;
	readonly editIds: readonly string[];
	exportApproved(): VerboseTree | undefined;
	exportSequenced(): VerboseTree | undefined;
	dispose(): void;
}

/**
 * An opt-in capture with process-local counterparts for nodes in its sequenced history.
 * Later births (including local unsequenced and correction-draft births) are outside this capture.
 * @alpha
 */
export interface SharedTreeAuthorityReferenceCapture extends SharedTreeAuthorityCapture {
	reference(node: TreeNode): SharedTreeAuthorityReferenceResult;
	resolve(
		reference: SharedTreeAuthorityNodeReference,
		target: "live" | SharedTreeAuthorityDraft,
	): SharedTreeAuthorityNodeResolution;
}

/**
 * A private, ordinary editable fork of the capture's approved history, optionally
 * including an explicitly selected prefix of its sequenced provisional edits.
 * Edits do not submit Fluid operations until published as one authority advance.
 * @alpha
 */
export interface SharedTreeAuthorityDraft {
	viewWith<TRoot extends ImplicitFieldSchema>(
		configuration: TreeViewConfiguration<TRoot>,
	): TreeView<TRoot>;
	dispose(): void;
}

/**
 * Approves an unchanged captured prefix, optionally followed by an authoritative correction.
 * A correction draft must have been created with afterPrefix equal to approvePrefix.
 * Accepted revisions remain in history; this does not replace them or accept arbitrary subsets.
 * @alpha @input
 */
export interface SharedTreeAuthorityPublication {
	readonly batchId: string;
	readonly nextCheckpoint: string;
	readonly capture: SharedTreeAuthorityCapture;
	readonly approvePrefix?: number;
	readonly draft?: SharedTreeAuthorityDraft;
}

/**
 * Restricted v2 authority controller. All clients/writers must be trusted.
 * History is retained without bound; runtime summaries are explicitly unsupported.
 * @alpha
 */
export interface SharedTreeAuthorityController {
	capture(): SharedTreeAuthorityCapture;
	capture(options: SharedTreeAuthorityReferenceOptions): SharedTreeAuthorityReferenceCapture;
	/**
	 * Forks captured A followed by exactly the first afterPrefix edits (default zero).
	 * Later captured P and all local L are excluded. Publication must approve the same prefix.
	 */
	createDraft(
		capture: SharedTreeAuthorityCapture,
		options?: { readonly afterPrefix: number },
	): SharedTreeAuthorityDraft;
	publishAdvance(
		publication: SharedTreeAuthorityPublication,
	): Promise<"applied" | "duplicate" | "stale">;
	onStateChanged(listener: () => void): () => void;
}

interface CaptureData {
	readonly approved: GraphCommit<SharedTreeChange>;
	readonly commits: readonly GraphCommit<SharedTreeChange>[];
	readonly approvedCheckout: TreeCheckout;
	readonly sequencedCheckout: TreeCheckout;
	readonly references?: AuthorityNodeReferences;
	disposed: boolean;
}

interface DraftData {
	readonly capture: SharedTreeAuthorityCapture;
	readonly afterPrefix: number;
	readonly base: GraphCommit<SharedTreeChange>;
	readonly checkout: TreeCheckout;
	disposed: boolean;
	sealed: boolean;
}

interface PublicationReceipt {
	readonly capture: SharedTreeAuthorityCapture;
	readonly nextCheckpoint: string;
	readonly count: number;
	readonly draft: SharedTreeAuthorityDraft | undefined;
	readonly head: GraphCommit<SharedTreeChange> | undefined;
	readonly completion: Deferred<ExternalAuthorityOutcome>;
	finished: boolean;
}

class Controller implements SharedTreeAuthorityController {
	private readonly captures = new WeakMap<SharedTreeAuthorityCapture, CaptureData>();
	private readonly drafts = new WeakMap<SharedTreeAuthorityDraft, DraftData>();
	private readonly publications = new Map<string, PublicationReceipt>();

	public constructor(private readonly kernel: SharedTreeKernel) {
		kernel.checkout.events.on("dispose", () => {
			for (const publication of this.publications.values()) {
				publication.completion.reject(
					new UsageError("Authority publication checkout has been disposed"),
				);
			}
			this.publications.clear();
		});
	}

	private materialize(
		head: GraphCommit<SharedTreeChange>,
		source = this.kernel.checkout,
	): TreeCheckout {
		const checkout = source.fork();
		const oldBranch = checkout.mainBranch;
		// This checkout has not been exposed to observers. switchBranch applies a real
		// history diff to its cloned forest, schema and detached-root index.
		checkout.switchBranch(oldBranch.fork(head));
		oldBranch.dispose();
		return checkout;
	}

	public capture(): SharedTreeAuthorityCapture;
	public capture(
		options: SharedTreeAuthorityReferenceOptions,
	): SharedTreeAuthorityReferenceCapture;
	public capture(
		options?: SharedTreeAuthorityReferenceOptions,
	): SharedTreeAuthorityCapture | SharedTreeAuthorityReferenceCapture {
		if (
			options !== undefined &&
			(options === null || typeof options !== "object" || options.trackNodeReferences !== true)
		) {
			throw new UsageError(
				"Reference capture requires positive integer limits and explicit opt-in",
			);
		}
		const { maxNodes = 10000, maxDrafts = 16 } = options ?? {};
		if (![maxNodes, maxDrafts].every((value) => Number.isSafeInteger(value) && value > 0)) {
			throw new UsageError("Reference capture requires positive integer limits");
		}
		const state = this.kernel.getExternalAuthorityState();
		const references =
			options === undefined
				? undefined
				: new AuthorityNodeReferences(
						this.kernel.checkout,
						state.sequenced,
						maxDrafts,
						maxNodes,
					);
		let approvedCheckout: TreeCheckout;
		let completed = false;
		try {
			approvedCheckout = this.materialize(
				state.approved,
				references?.sequenced ?? this.kernel.checkout,
			);
			completed = true;
		} finally {
			if (!completed && references !== undefined) {
				references.dispose();
				references.sequenced[disposeSymbol]();
			}
		}
		const data: CaptureData = {
			approved: state.approved,
			commits: state.provisional,
			approvedCheckout,
			sequencedCheckout: references?.sequenced ?? this.materialize(state.sequenced),
			references,
			disposed: false,
		};
		const check = (): void => {
			if (data.disposed) {
				throw new UsageError("Authority capture has been disposed");
			}
		};
		const capture = Object.freeze({
			checkpoint: state.checkpoint,
			editIds: Object.freeze(
				state.provisional.map((commit) => {
					assert(commit.revision !== "root", "A provisional commit must have an identity");
					return this.kernel.getStableRevision(commit.revision);
				}),
			),
			exportApproved: () => {
				check();
				return data.approvedCheckout.exportVerbose();
			},
			exportSequenced: () => {
				check();
				return data.sequencedCheckout.exportVerbose();
			},
			dispose: () => {
				if (!data.disposed) {
					data.references?.dispose();
					data.disposed = true;
					for (const [batchId, publication] of this.publications) {
						if (publication.capture === capture && publication.finished) {
							this.publications.delete(batchId);
						}
					}
					data.approvedCheckout[disposeSymbol]();
					data.sequencedCheckout[disposeSymbol]();
				}
			},
			...(references === undefined
				? {}
				: {
						reference: (node: TreeNode): SharedTreeAuthorityReferenceResult => {
							check();
							return references.reference(node);
						},
						resolve: (
							reference: SharedTreeAuthorityNodeReference,
							target: "live" | SharedTreeAuthorityDraft,
						): SharedTreeAuthorityNodeResolution => {
							check();
							let checkout = this.kernel.checkout;
							if (target !== "live") {
								const draft = this.drafts.get(target);
								if (
									draft?.capture !== capture ||
									draft.disposed ||
									draft.sealed ||
									draft.checkout.disposed
								) {
									throw new UsageError(
										"Expected an active unpublished draft from this exact capture",
									);
								}
								checkout = draft.checkout;
							}
							return references.resolve(reference, checkout);
						},
					}),
		});
		this.captures.set(capture, data);
		return capture;
	}

	private getCapture(capture: SharedTreeAuthorityCapture): CaptureData {
		const data = this.captures.get(capture);
		if (data === undefined || data.disposed) {
			throw new UsageError("Expected a live capture from this controller");
		}
		return data;
	}

	private prefixBase(captured: CaptureData, count: number): GraphCommit<SharedTreeChange> {
		if (!Number.isInteger(count) || count < 0 || count > captured.commits.length) {
			throw new UsageError("Approval must be a prefix of the captured sequenced edits");
		}
		if (count === 0) {
			return captured.approved;
		}
		const base = captured.commits[count - 1];
		assert(base !== undefined, "Validated captured prefix has no head");
		return base;
	}

	public createDraft(
		capture: SharedTreeAuthorityCapture,
		options?: { readonly afterPrefix: number },
	): SharedTreeAuthorityDraft {
		const captured = this.getCapture(capture);
		const afterPrefix = options === undefined ? 0 : options.afterPrefix;
		const base = this.prefixBase(captured, afterPrefix);
		const data: DraftData = {
			capture,
			afterPrefix,
			base,
			checkout:
				captured.references?.createDraft(base) ??
				this.materialize(base, captured.approvedCheckout),
			disposed: false,
			sealed: false,
		};
		const draft: SharedTreeAuthorityDraft = {
			viewWith: <TRoot extends ImplicitFieldSchema>(
				config: TreeViewConfiguration<TRoot>,
			): TreeView<TRoot> => {
				if (
					data.disposed ||
					data.sealed ||
					data.checkout.disposed ||
					(captured.references !== undefined && captured.disposed)
				) {
					throw new UsageError("Authority draft has been disposed or published");
				}
				return data.checkout.viewWith(config) as TreeView<TRoot>;
			},
			dispose: () => {
				if (!data.disposed) {
					data.disposed = true;
					if (!data.checkout.disposed) {
						data.checkout[disposeSymbol]();
					}
				}
			},
		};
		this.drafts.set(draft, data);
		return draft;
	}

	public async publishAdvance(
		publication: SharedTreeAuthorityPublication,
	): Promise<ExternalAuthorityOutcome> {
		// Snapshot input properties once: later mutation of the caller's object cannot change a send.
		const {
			batchId,
			nextCheckpoint,
			capture,
			draft: draftId,
			approvePrefix: count = 0,
		} = publication;
		if (this.kernel.checkout.disposed) {
			throw new UsageError("Authority publication checkout has been disposed");
		}
		const captured = this.getCapture(capture);
		// Do not serve cached successes from an otherwise broken kernel.
		const current = this.kernel.getExternalAuthorityState();
		const previous = this.publications.get(batchId);
		if (previous !== undefined) {
			if (
				previous.capture !== capture ||
				previous.count !== count ||
				previous.nextCheckpoint !== nextCheckpoint ||
				previous.draft !== draftId
			) {
				throw new UsageError(
					"Authority batch identity reused with different publication inputs",
				);
			}
			if (draftId !== undefined) {
				const draft = this.drafts.get(draftId);
				if (draft === undefined || draft.disposed || draft.checkout.disposed) {
					throw new UsageError("Authority publication draft has been disposed");
				}
				if (draft.checkout.mainBranch.getHead() !== previous.head) {
					throw new UsageError("Authority publication draft changed after sealing");
				}
			}
			const outcome = this.kernel.getExternalAuthorityPublicationOutcome(batchId);
			return outcome === undefined
				? previous.completion.promise
				: outcome === "applied"
					? "duplicate"
					: outcome;
		}
		if (this.publications.size >= 128) {
			throw new UsageError("Authority receipt limit exceeded; dispose completed captures");
		}
		const base = this.prefixBase(captured, count);
		if (
			current.checkpoint === capture.checkpoint &&
			current.approved.revision !== captured.approved.revision
		) {
			throw new UsageError("Captured approved history no longer matches its checkpoint");
		}
		if (
			[batchId, nextCheckpoint].some(
				(value) => typeof value !== "string" || value.length === 0,
			) ||
			nextCheckpoint === capture.checkpoint
		) {
			throw new UsageError("An authority advance requires distinct nonempty identifiers");
		}
		this.kernel.checkNewExternalAuthorityPublication(batchId);
		let commits: GraphCommit<SharedTreeChange>[] = [];
		let head: GraphCommit<SharedTreeChange> | undefined;
		if (draftId !== undefined) {
			const draft = this.drafts.get(draftId);
			if (
				draft === undefined ||
				draft.disposed ||
				draft.sealed ||
				draft.checkout.disposed ||
				draft.capture !== capture
			) {
				throw new UsageError("Expected an unpublished draft from this capture");
			}
			if (draft.afterPrefix !== count || draft.base !== base) {
				throw new UsageError("Draft authoring base must match the approved captured prefix");
			}
			if (draft.checkout.transaction.size > 0) {
				throw new UsageError("Finish the draft transaction before publishing");
			}
			const ancestor = findCommonAncestor(base, [
				draft.checkout.mainBranch.getHead(),
				commits,
			]);
			assert(ancestor === base, "Authority draft changed its authoring base");
			if (commits.some((commit) => hasSchemaChange(commit.change))) {
				throw new UsageError("Authority drafts cannot change schema");
			}
			const enriched = draft.checkout.enrich(base, commits);
			commits = commits.map((commit, index) => ({
				...commit,
				change: enriched[index] ?? commit.change,
			}));
			captured.references?.sealDraft(draft.checkout);
			draft.sealed = true;
			head = draft.checkout.mainBranch.getHead();
		}
		const entry: PublicationReceipt = {
			capture,
			nextCheckpoint,
			count,
			draft: draftId,
			head,
			completion: new Deferred<ExternalAuthorityOutcome>(),
			finished: false,
		};
		this.publications.set(batchId, entry);
		this.kernel
			.publishExternalAuthority({
				batchId,
				expected: capture.checkpoint,
				next: nextCheckpoint,
				authoringBase: base.revision,
				approvedPrefix: captured.commits.slice(0, count).map((commit) => commit.revision),
				commits,
			})
			.then(
				(outcome) => {
					entry.finished = true;
					entry.completion.resolve(outcome);
					if (captured.disposed) {
						this.publications.delete(batchId);
					}
				},
				(error: unknown) => {
					entry.finished = true;
					entry.completion.reject(error);
					if (captured.disposed) {
						this.publications.delete(batchId);
					}
				},
			);
		return entry.completion.promise;
	}

	public onStateChanged(listener: () => void): () => void {
		return this.kernel.onExternalAuthorityChanged(listener);
	}
}

const controllers = new WeakMap<SharedTreeKernel, SharedTreeAuthorityController>();

/**
 * Gets the restricted experimental controller of an explicitly opted-in tree.
 * This is not an authorization boundary: every Fluid writer is trusted.
 * @alpha
 */
export function getSharedTreeAuthority(tree: ITree): SharedTreeAuthorityController {
	const kernel = (tree as ITreePrivate).kernel;
	if (kernel?.externalAuthorityEnabled !== true) {
		throw new UsageError("External authority mode is not enabled");
	}
	let controller = controllers.get(kernel);
	if (controller === undefined) {
		controller = new Controller(kernel);
		controllers.set(kernel, controller);
	}
	return controller;
}
