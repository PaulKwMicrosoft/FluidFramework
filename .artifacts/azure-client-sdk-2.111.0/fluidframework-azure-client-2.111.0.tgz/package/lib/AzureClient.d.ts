/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { ContainerSchema, IFluidContainer, CompatibilityMode } from "@fluidframework/fluid-static";
import type { MinimumVersionForCollab } from "@fluidframework/runtime-definitions";
import type { AzureClientProps, AzureContainerServices, AzureContainerVersion, AzureGetVersionsOptions } from "./interfaces.js";
/**
 * AzureClient provides the ability to have a Fluid object backed by the Azure Fluid Relay or,
 * when running with local tenantId, have it be backed by a local Azure Fluid Relay instance.
 * @public
 */
export declare class AzureClient {
    private readonly documentServiceFactory;
    private readonly urlResolver;
    private readonly configProvider;
    private readonly connectionConfig;
    private readonly logger;
    private readonly createContainerRuntimeFactory?;
    /**
     * Creates a new client instance using configuration parameters.
     * @param properties - Properties for initializing a new AzureClient instance
     */
    constructor(properties: AzureClientProps);
    /**
     * Creates a new detached container instance in the Azure Fluid Relay.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * (normally not explicitly specified.)
     * @param containerSchema - Container schema for the new container.
     * @param minVersionForCollab - Minimum Fluid Framework version required for collaboration, as a
     * SemVer string (e.g. `"1.0.0"`, `"2.100.0"`). Prefer the current Fluid Framework version so the container opts into the latest defaults.
     * @returns New detached container instance along with associated services.
     */
    createContainer<const TContainerSchema extends ContainerSchema>(containerSchema: TContainerSchema, minVersionForCollab: MinimumVersionForCollab): Promise<{
        container: IFluidContainer<TContainerSchema>;
        services: AzureContainerServices;
    }>;
    /**
     * Creates a new detached container instance in the Azure Fluid Relay.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * This does not normally need to be specified explicitly.
     * @param containerSchema - Container schema for the new container.
     * @param compatibilityMode - Legacy {@link @fluidframework/fluid-static#CompatibilityMode} value.
     * @returns New detached container instance along with associated services.
     * @deprecated Pass a `MinimumVersionForCollab` SemVer string (e.g. `"2.0.0"`) instead. The legacy
     * values `"1"` and `"2"` correspond to `"1.0.0"` and `"2.0.0"` respectively.
     */
    createContainer<const TContainerSchema extends ContainerSchema>(containerSchema: TContainerSchema, compatibilityMode: CompatibilityMode): Promise<{
        container: IFluidContainer<TContainerSchema>;
        services: AzureContainerServices;
    }>;
    /**
     * Accesses the existing container given its unique ID in the Azure Fluid Relay.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * (normally not explicitly specified.)
     * @param id - Unique ID of the container in Azure Fluid Relay.
     * @param containerSchema - Container schema used to access data objects in the container.
     * @param minVersionForCollab - Minimum framework version required for collaboration, as a
     * SemVer string (e.g. `"1.0.0"`, `"2.100.0"`). Prefer the current Fluid Framework version so the container opts into the latest defaults.
     * @returns Existing container instance along with associated services.
     */
    getContainer<TContainerSchema extends ContainerSchema>(id: string, containerSchema: TContainerSchema, minVersionForCollab: MinimumVersionForCollab): Promise<{
        container: IFluidContainer<TContainerSchema>;
        services: AzureContainerServices;
    }>;
    /**
     * Accesses the existing container given its unique ID in the Azure Fluid Relay.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * (normally not explicitly specified.)
     * @param id - Unique ID of the container in Azure Fluid Relay.
     * @param containerSchema - Container schema used to access data objects in the container.
     * @param compatibilityMode - Legacy {@link @fluidframework/fluid-static#CompatibilityMode} value.
     * @returns Existing container instance along with associated services.
     * @deprecated Pass a `MinimumVersionForCollab` SemVer string (e.g. `"2.0.0"`) instead. The legacy
     * values `"1"` and `"2"` correspond to `"1.0.0"` and `"2.0.0"` respectively.
     */
    getContainer<TContainerSchema extends ContainerSchema>(id: string, containerSchema: TContainerSchema, compatibilityMode: CompatibilityMode): Promise<{
        container: IFluidContainer<TContainerSchema>;
        services: AzureContainerServices;
    }>;
    /**
     * Load a specific version of a container for viewing only.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * (normally not explicitly specified.)
     * @param id - Unique ID of the source container in Azure Fluid Relay.
     * @param containerSchema - Container schema used to access data objects in the container.
     * @param version - Unique version of the source container in Azure Fluid Relay.
     * @param minVersionForCollab - Minimum framework version required for collaboration, as a
     * SemVer string (e.g. `"1.0.0"`, `"2.100.0"`). Prefer the current Fluid Framework version so the container opts into the latest defaults.
     * @returns Loaded container instance at the specified version.
     */
    viewContainerVersion<TContainerSchema extends ContainerSchema>(id: string, containerSchema: TContainerSchema, version: AzureContainerVersion, minVersionForCollab: MinimumVersionForCollab): Promise<{
        container: IFluidContainer<TContainerSchema>;
    }>;
    /**
     * Load a specific version of a container for viewing only.
     * @typeparam TContainerSchema - Used to infer the the type of 'initialObjects' in the returned container.
     * (normally not explicitly specified.)
     * @param id - Unique ID of the source container in Azure Fluid Relay.
     * @param containerSchema - Container schema used to access data objects in the container.
     * @param version - Unique version of the source container in Azure Fluid Relay.
     * @param compatibilityMode - Legacy {@link @fluidframework/fluid-static#CompatibilityMode} value.
     * @returns Loaded container instance at the specified version.
     * @deprecated Pass a `MinimumVersionForCollab` SemVer string (e.g. `"2.0.0"`) instead. The legacy
     * values `"1"` and `"2"` correspond to `"1.0.0"` and `"2.0.0"` respectively.
     */
    viewContainerVersion<TContainerSchema extends ContainerSchema>(id: string, containerSchema: TContainerSchema, version: AzureContainerVersion, compatibilityMode: CompatibilityMode): Promise<{
        container: IFluidContainer<TContainerSchema>;
    }>;
    /**
     * Get the list of versions for specific container.
     * @param id - Unique ID of the source container in Azure Fluid Relay.
     * @param options - "Get" options. If options are not provided, API
     * will assume maxCount of versions to retrieve to be 5.
     * @returns Array of available container versions.
     */
    getContainerVersions(id: string, options?: AzureGetVersionsOptions): Promise<AzureContainerVersion[]>;
    private getContainerServices;
    private getLoaderProps;
    private createFluidContainer;
}
//# sourceMappingURL=AzureClient.d.ts.map