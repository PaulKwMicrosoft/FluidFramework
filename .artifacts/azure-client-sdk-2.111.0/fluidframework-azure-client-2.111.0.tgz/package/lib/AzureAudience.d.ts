/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IClient } from "@fluidframework/driver-definitions";
import type { AzureMember } from "./interfaces.js";
/**
 * Creates Azure-specific audience member.
 *
 * @remarks
 * The provided `audienceMember`'s {@link @fluidframework/protocol-definitions#IClient.user} must be an {@link AzureUser}.
 */
export declare function createAzureAudienceMember(audienceMember: IClient): AzureMember;
//# sourceMappingURL=AzureAudience.d.ts.map