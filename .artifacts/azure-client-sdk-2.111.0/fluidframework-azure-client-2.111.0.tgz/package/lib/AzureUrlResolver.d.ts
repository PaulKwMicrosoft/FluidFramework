/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { IRequest } from "@fluidframework/core-interfaces";
import { type IResolvedUrl, type IUrlResolver } from "@fluidframework/driver-definitions/internal";
/**
 * Implementation of {@link @fluidframework/driver-definitions#IUrlResolver} to resolve documents stored using the
 * Azure Fluid Relay based off of the orderer and storage URLs provide.
 *
 * @remarks The token provider here can be an `InsecureTokenProvider` for basic scenarios or more robust, secure
 * providers that fulfill the {@link @fluidframework/routerlicious-driver#ITokenProvider} interface.
 */
export declare class AzureUrlResolver implements IUrlResolver {
    constructor();
    resolve(request: IRequest): Promise<IResolvedUrl>;
    getAbsoluteUrl(resolvedUrl: IResolvedUrl, relativeUrl: string): Promise<string>;
}
/**
 * Creates a request object that can be passed to {@link @fluidframework/fluid-static#IFluidContainer.attach} to
 * request creation of a new Fluid Container on the Azure service.
 *
 * @param endpointUrl - URI to the Azure Fluid Relay service discovery endpoint.
 * @param tenantId - Unique tenant identifier.
 */
export declare const createAzureCreateNewRequest: (endpointUrl: string, tenantId: string) => IRequest;
//# sourceMappingURL=AzureUrlResolver.d.ts.map