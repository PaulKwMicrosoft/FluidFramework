/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
import type { AzureConnectionConfig, AzureLocalConnectionConfig, AzureRemoteConnectionConfig } from "./interfaces.js";
/**
 * Type guard for validating a given AzureConnectionConfig is a remote connection type (AzureRemoteConnectionConfig)
 */
export declare function isAzureRemoteConnectionConfig(connectionConfig: AzureConnectionConfig): connectionConfig is AzureRemoteConnectionConfig;
/**
 * Type guard for validating a given AzureConnectionConfig is a local connection type (AzureLocalConnectionConfig)
 */
export declare function isAzureLocalConnectionConfig(connectionConfig: AzureConnectionConfig): connectionConfig is AzureLocalConnectionConfig;
//# sourceMappingURL=utils.d.ts.map