/*!
 * Copyright (c) Microsoft Corporation and contributors. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * A simple and powerful way to consume collaborative Fluid data with the Azure Fluid Relay.
 *
 * @packageDocumentation
 */
export { AzureClient } from "./AzureClient.js";
export type { AzureClientProps, AzureClientPropsInternal, AzureConnectionConfig, AzureConnectionConfigType, AzureContainerServices, AzureContainerVersion, AzureGetVersionsOptions, AzureLocalConnectionConfig, AzureMember, AzureRemoteConnectionConfig, AzureUser, IAzureAudience, } from "./interfaces.js";
export type { ITokenProvider, ITokenResponse } from "@fluidframework/routerlicious-driver";
export type { IUser } from "@fluidframework/driver-definitions";
export type { ITelemetryBaseEvent, ITelemetryBaseLogger, } from "@fluidframework/core-interfaces";
export type { CompatibilityMode } from "@fluidframework/fluid-static";
//# sourceMappingURL=index.d.ts.map